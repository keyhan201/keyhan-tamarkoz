import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// ساخت اپ اندروید (Capacitor) → پوشه‌ی www. ساخت افزونه (vite.config.js → dist) جداست و دست نمی‌خورد.
export default defineConfig({
  plugins: [react()],
  base: './',
  build: { outDir: 'www', emptyOutDir: true, modulePreload: { polyfill: false } },
});
