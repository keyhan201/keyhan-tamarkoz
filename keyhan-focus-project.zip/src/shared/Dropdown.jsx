import { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react';

/**
 * منوی بازشونده‌ی دسترس‌پذیر (الگوی select-only combobox).
 * کیبورد: ↓ ↑ Home End Enter Space Esc Tab. گزینه‌ها می‌توانند group داشته باشند.
 * options: [{ value, label, group?, hint? }]
 * renderOption(opt, { selected, active }) و renderValue(opt) برای نمایش سفارشی (مثلاً نمونه‌ی رنگ).
 * onHighlight(value): فقط با حرکت کیبورد صدا زده می‌شود (مثلاً برای پیش‌نمایش صدا).
 */
export default function Dropdown({ label, value, options, onChange, onHighlight, renderOption, renderValue, disabled = false, className = '' }) {
  const uid = useId().replace(/:/g, '');
  const listId = `dd-list-${uid}`;
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const [up, setUp] = useState(false);
  const root = useRef(null);
  const list = useRef(null);
  const selectedIndex = Math.max(0, options.findIndex((o) => o.value === value));
  const current = options[selectedIndex];

  const openMenu = useCallback(() => {
    const r = root.current && root.current.getBoundingClientRect();
    if (r) {
      const below = window.innerHeight - r.bottom;
      setUp(below < 240 && r.top > below); // اگر پایین جا نیست، رو به بالا باز شود
    }
    setActive(selectedIndex);
    setOpen(true);
  }, [selectedIndex]);

  const close = useCallback(() => setOpen(false), []);

  useEffect(() => {
    if (!open) return undefined;
    const away = (e) => root.current && !root.current.contains(e.target) && close();
    document.addEventListener('pointerdown', away);
    return () => document.removeEventListener('pointerdown', away);
  }, [open, close]);

  useEffect(() => {
    if (!open || !list.current) return;
    const el = list.current.querySelector(`[data-index="${active}"]`);
    if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
  }, [open, active]);

  const move = (i) => {
    const next = Math.min(options.length - 1, Math.max(0, i));
    setActive(next);
    if (onHighlight && options[next]) onHighlight(options[next].value);
  };
  const choose = (i) => {
    const o = options[i];
    if (o) onChange(o.value);
    close();
    if (root.current) root.current.querySelector('button.dd-trigger').focus();
  };

  const onKeyDown = (e) => {
    if (!open) {
      if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(e.key)) { e.preventDefault(); openMenu(); }
      return;
    }
    switch (e.key) {
      case 'ArrowDown': e.preventDefault(); move(active + 1); break;
      case 'ArrowUp': e.preventDefault(); move(active - 1); break;
      case 'Home': e.preventDefault(); move(0); break;
      case 'End': e.preventDefault(); move(options.length - 1); break;
      case 'Enter':
      case ' ': e.preventDefault(); choose(active); break;
      case 'Escape': e.preventDefault(); e.stopPropagation(); close(); break;
      case 'Tab': close(); break;
      default:
    }
  };

  const items = useMemo(() => {
    const out = [];
    let lastGroup = null;
    options.forEach((o, i) => {
      if (o.group && o.group !== lastGroup) out.push({ heading: o.group, key: `g-${o.group}` });
      lastGroup = o.group || lastGroup;
      out.push({ o, i, key: `o-${String(o.value)}` });
    });
    return out;
  }, [options]);

  return (
    <div className={`dd ${className}`} ref={root}>
      <button
        type="button"
        className="dd-trigger"
        role="combobox"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={listId}
        aria-label={label}
        disabled={disabled}
        aria-activedescendant={open ? `${listId}-${active}` : undefined}
        onClick={() => (open ? close() : openMenu())}
        onKeyDown={onKeyDown}
      >
        <span className="dd-value">{renderValue && current ? renderValue(current) : current && current.label}</span>
        <span className="dd-caret" aria-hidden="true">▾</span>
      </button>
      {open && (
        <ul id={listId} ref={list} role="listbox" aria-label={label} className={'dd-list' + (up ? ' up' : '')}>
          {items.map((it) =>
            it.heading ? (
              <li key={it.key} role="presentation" className="dd-group">{it.heading}</li>
            ) : (
              <li
                key={it.key}
                id={`${listId}-${it.i}`}
                data-index={it.i}
                role="option"
                aria-selected={it.o.value === value}
                className={'dd-opt' + (it.i === active ? ' active' : '') + (it.o.value === value ? ' selected' : '')}
                onMouseEnter={() => setActive(it.i)}
                onClick={() => choose(it.i)}
              >
                {renderOption ? renderOption(it.o, { selected: it.o.value === value, active: it.i === active }) : it.o.label}
              </li>
            ),
          )}
        </ul>
      )}
    </div>
  );
}
