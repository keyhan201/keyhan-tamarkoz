export default function Mark({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" strokeWidth="1.6" opacity=".4" />
      <circle cx="12" cy="3.5" r="2.4" fill="var(--star)" />
    </svg>
  );
}
