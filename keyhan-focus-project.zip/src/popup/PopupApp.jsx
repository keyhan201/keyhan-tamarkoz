import { useState } from 'react';
import { useSettings } from '../hooks/useStoredValue.js';
import { useQuote } from '../hooks/useQuote.js';
import { categoryFor } from '../core/quotes.js';
import { useTimer } from '../hooks/useTimer.js';
import { cancelTimer, pauseTimer, resumeTimer, startTimer } from '../core/timerService.js';
import { DEFAULT_SETTINGS } from '../core/constants.js';
import { normalizeCustomMinutes } from '../core/durations.js';
import { toFa } from '../core/format.js';
import Icon from '../shared/Icon.jsx';
import Mark from '../shared/Mark.jsx';
import OrbitTimer from './components/OrbitTimer.jsx';
import DurationSheet from './components/DurationSheet.jsx';

const openPage = (hash) => {
  if (typeof chrome !== 'undefined' && chrome.tabs) {
    chrome.tabs.create({ url: chrome.runtime.getURL(`dashboard.html#${hash}`) });
  } else {
    window.open(`dashboard.html#${hash}`, '_blank');
  }
};

export default function PopupApp() {
  const { timer, ready, remainingMs, progress, now, interruptible } = useTimer();
  const [settings, patchSettings] = useSettings();
  const [sheetOpen, setSheetOpen] = useState(false);
  const [focusAdd, setFocusAdd] = useState(false);

  const quote = useQuote(ready && settings.showQuotes, ready ? categoryFor(timer, now) : 'start', timer.sessionId || (timer.lastResult && timer.lastResult.sessionId) || '');

  if (!ready) return <div className="popup" />;

  const minutes = Number.isFinite(settings.defaultMinutes) ? settings.defaultMinutes : 25;
  const idle = timer.status === 'idle';
  const running = timer.status === 'running';
  const shownMs = idle ? minutes * 60000 : remainingMs;

  const recent = timer.lastResult && now - timer.lastResult.at < 60 * 60 * 1000;
  const status = running
    ? 'در حال تمرکز'
    : timer.status === 'paused'
      ? 'متوقف شد'
      : recent
        ? `تمرکز تمام شد؛ ${toFa(timer.lastResult.minutes)} دقیقه ثبت شد`
        : 'آماده‌ی تمرکز';

  const begin = () => {
    setSheetOpen(false);
    startTimer(minutes);
  };

  return (
    <div className="popup">
      <header className="bar">
        <div className="brand">
          <Mark size={22} />
          <span>کیهان تمرکز</span>
        </div>
        <div className="tools">
          <button className="icon-btn" onClick={() => openPage('stats')} aria-label="آمار تمرکز" title="آمار تمرکز">
            <Icon name="stats" />
          </button>
          <button className="icon-btn" onClick={() => openPage('settings')} aria-label="تنظیمات" title="تنظیمات">
            <Icon name="sliders" />
          </button>
        </div>
      </header>

      <main className="stage">
        <p className="status">{status}</p>
        <OrbitTimer remainingMs={shownMs} progress={progress} active={running} />

        <div className="chip-slot">
          {idle && (
            <>
              <button className="chip" onClick={() => { setFocusAdd(false); setSheetOpen(true); }}>
                {toFa(minutes)} دقیقه
              </button>
              <button className="chip-add" onClick={() => { setFocusAdd(true); setSheetOpen(true); }} aria-label="افزودن زمان دلخواه" title="افزودن زمان دلخواه">
                <Icon name="plus" size={14} />
              </button>
            </>
          )}
        </div>

        <div className="controls">
          {idle ? (
            <button className="go" onClick={begin} aria-label="شروع">
              <Icon name="play" size={26} />
            </button>
          ) : (
            // فقط تا پایان ۱۰ ثانیه‌ی اول؛ بعد از آن کنترلی در DOM نیست
            interruptible && (
              <>
                <button className="go" onClick={() => (running ? pauseTimer() : resumeTimer())} aria-label={running ? 'توقف موقت' : 'ادامه'}>
                  <Icon name={running ? 'pause' : 'play'} size={26} />
                </button>
                <button className="ghost" onClick={() => cancelTimer()} aria-label="انصراف از جلسه" title="انصراف">
                  <Icon name="stop" size={18} />
                </button>
              </>
            )
          )}
        </div>

        {settings.showQuotes && <p className="quote" aria-live="polite">{quote ? quote.text : '\u00a0'}</p>}
      </main>

      {sheetOpen && (
        <DurationSheet
          minutes={minutes}
          saved={settings.customMinutes}
          focusInput={focusAdd}
          onSaveList={(list) => {
            // اگر زمان انتخاب‌شده همین الان حذف شد، به پیش‌فرض برمی‌گردیم تا مقدار «یتیم» نماند
            const removedSelected = normalizeCustomMinutes(settings.customMinutes).includes(minutes) && !list.includes(minutes);
            patchSettings(removedSelected ? { customMinutes: list, defaultMinutes: DEFAULT_SETTINGS.defaultMinutes } : { customMinutes: list });
          }}
          onChange={(m) => patchSettings({ defaultMinutes: m })}
          onStart={begin}
          onClose={() => setSheetOpen(false)}
        />
      )}
    </div>
  );
}
