import React from 'react';
import { createRoot } from 'react-dom/client';
import { initTheme } from '../core/themes.js';
import '@fontsource-variable/vazirmatn';
import '../styles/base.css';
import '../styles/themes.css';
import './popup.css';
import PopupApp from './PopupApp.jsx';

// تم ذخیره‌شده پیش از اولین رندر اعمال می‌شود تا رنگ اشتباهی چشمک نزند
initTheme().finally(() =>
  createRoot(document.getElementById('root')).render(<PopupApp />),
);
