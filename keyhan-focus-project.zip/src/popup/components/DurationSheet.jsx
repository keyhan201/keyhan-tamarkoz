import { useEffect, useRef, useState } from 'react';
import { MAX_MINUTES, MIN_MINUTES, PRESETS } from '../../core/constants.js';
import { addCustomMinute, normalizeCustomMinutes, parseMinutes, removeCustomMinute } from '../../core/durations.js';
import { toFa } from '../../core/format.js';
import Icon from '../../shared/Icon.jsx';

export default function DurationSheet({ minutes, saved, onChange, onSaveList, onStart, onClose, focusInput = false }) {
  const [custom, setCustom] = useState('');
  const [error, setError] = useState('');
  const inputRef = useRef(null);
  const list = normalizeCustomMinutes(saved);
  const typedBad = custom.trim() !== '' && parseMinutes(custom) === null;
  const invalid = typedBad || Boolean(error);

  useEffect(() => {
    if (focusInput && inputRef.current) inputRef.current.focus();
  }, [focusInput]);

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const pick = (m) => {
    setCustom('');
    setError('');
    onChange(m);
  };

  const typed = (raw) => {
    setCustom(raw);
    setError('');
    const n = parseMinutes(raw);
    if (n) onChange(n);
  };

  const add = () => {
    const res = addCustomMinute(list, custom);
    if (!res.ok) {
      if (res.duplicate) pick(res.duplicate); // همان زمان را فقط انتخاب می‌کنیم
      else setError(res.error);
      return;
    }
    onSaveList(res.list);
    pick(res.minutes);
  };

  const remove = (m) => {
    onSaveList(removeCustomMinute(list, m));
    setError('');
  };

  const hint = typedBad
    ? `عددی صحیح بین ${toFa(MIN_MINUTES)} تا ${toFa(MAX_MINUTES)} وارد کنید.`
    : error || '\u00a0';
  const isSelected = (m) => custom === '' && m === minutes;

  return (
    <>
      <div className="scrim" onClick={onClose} />
      <section className="sheet" role="dialog" aria-modal="true" aria-label="مدت تمرکز">
        <div className="sheet-head">
          <h2>مدت تمرکز</h2>
          <button className="icon-btn" onClick={onClose} aria-label="بستن">
            <Icon name="close" size={18} />
          </button>
        </div>

        <div className="presets" role="group" aria-label="زمان‌های آماده">
          {PRESETS.map((m) => (
            <button key={m} className={'preset' + (isSelected(m) ? ' on' : '')} aria-pressed={isSelected(m)} onClick={() => pick(m)}>
              {toFa(m)} دقیقه
            </button>
          ))}
          {list.map((m) => (
            <span key={m} className={'preset saved' + (isSelected(m) ? ' on' : '')}>
              <button className="saved-pick" aria-pressed={isSelected(m)} onClick={() => pick(m)}>
                {toFa(m)} دقیقه
              </button>
              <button className="saved-del" onClick={() => remove(m)} aria-label={`حذف زمان ${toFa(m)} دقیقه`} title="حذف">
                <Icon name="close" size={12} />
              </button>
            </span>
          ))}
        </div>

        <label className="custom-label" htmlFor="custom">افزودن زمان دلخواه</label>
        <div className={'field' + (invalid ? ' bad' : '')}>
          <input
            id="custom"
            ref={inputRef}
            inputMode="numeric"
            autoComplete="off"
            maxLength={4}
            value={custom}
            aria-invalid={invalid}
            aria-describedby="custom-hint"
            onChange={(e) => typed(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                if (custom.trim() === '') onStart();
                else add();
              }
            }}
          />
          <span>دقیقه</span>
          <button className="add-time" onClick={add} disabled={custom.trim() === '' || typedBad} aria-label="افزودن به زمان‌های ذخیره‌شده" title="ذخیره در فهرست">
            <Icon name="plus" size={16} />
          </button>
        </div>
        <p id="custom-hint" className="hint" role={invalid ? 'alert' : undefined}>{hint}</p>

        <button className="primary" disabled={typedBad} onClick={onStart}>
          شروع تمرکز
        </button>
      </section>
    </>
  );
}
