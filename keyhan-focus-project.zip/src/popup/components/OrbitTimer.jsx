import { clock } from '../../core/format.js';

const SIZE = 280;
const C = SIZE / 2;
const R = 118;
const LEN = 2 * Math.PI * R;

/** حلقه‌ی مدار: پیشرفت به‌صورت کمان و یک «سیاره‌ی» کوچک روی سر آن. */
export default function OrbitTimer({ remainingMs, progress, active }) {
  const p = Number.isFinite(progress) ? Math.min(1, Math.max(0, progress)) : 0;
  const a = -Math.PI / 2 + p * 2 * Math.PI;
  const x = C + R * Math.cos(a);
  const y = C + R * Math.sin(a);

  return (
    <div className="orbit" role="timer" aria-live="off">
      <svg viewBox={`0 0 ${SIZE} ${SIZE}`} aria-hidden="true">
        <circle cx={C} cy={C} r={R} className="orbit-track" />
        <circle cx={C} cy={C} r={R - 24} className="orbit-inner" />
        <circle
          cx={C}
          cy={C}
          r={R}
          className="orbit-arc"
          strokeDasharray={`${LEN * p} ${LEN}`}
          transform={`rotate(-90 ${C} ${C})`}
        />
        <circle cx={x} cy={y} r="13" className={active ? 'planet-halo pulse' : 'planet-halo'} />
        <circle cx={x} cy={y} r="6" className="planet" />
      </svg>
      <div className="readout">{clock(remainingMs)}</div>
    </div>
  );
}
