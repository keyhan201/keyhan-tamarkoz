// سند offscreen: فقط برای پخش صدا وقتی هیچ صفحه‌ای از افزونه باز نیست (service worker صدا ندارد).
// سند offscreen به chrome.storage دسترسی ندارد؛ پس service worker داده‌ی صدای کاربر را همراه پیام می‌فرستد.
import { playCustom, playSound } from '../core/sounds.js';

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.target !== 'offscreen' || msg.type !== 'kt-play') return;
  (async () => {
    if (msg.soundId === 'custom' && (await playCustom(msg.custom))) return;
    await playSound(msg.soundId === 'custom' ? 'ding' : msg.soundId); // صدای کاربر نامعتبر/غیرقابل‌پخش → دینگ
  })();
});
