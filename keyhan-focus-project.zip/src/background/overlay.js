// اعلان بصری پایان تایمر. این تابع با chrome.scripting.executeScript داخل صفحه‌ی تب فعال اجرا می‌شود،
// پس باید کاملاً مستقل باشد: هیچ import یا متغیر بیرونی نباید در آن استفاده شود.
// ظاهر در Shadow DOM بسته می‌شود تا CSS سایت روی آن اثر نگذارد و CSS ما به سایت نشت نکند.
export function showEndOverlay(opts) {
  const HOST_ID = 'kt-end-overlay-host';
  const old = document.getElementById(HOST_ID);
  if (old) {
    if (old.dataset.session === opts.sessionId) return 'duplicate';
    old.remove();
  }

  const c = opts.colors;
  const host = document.createElement('div');
  host.id = HOST_ID;
  host.dataset.session = opts.sessionId;
  host.style.cssText =
    'all: initial; position: fixed; inset: 0; display: grid; place-items: center; z-index: 2147483647; pointer-events: none;';
  const root = host.attachShadow({ mode: 'closed' });

  const style = document.createElement('style');
  style.textContent = `
    :host { all: initial; }
    .card {
      pointer-events: auto;
      box-sizing: border-box;
      width: min(300px, calc(100vw - 32px));
      padding: 22px 22px 18px;
      direction: rtl;
      text-align: center;
      font-family: Vazirmatn, Tahoma, 'Segoe UI', sans-serif;
      line-height: 1.7;
      color: ${c.ink};
      background: ${c.surface};
      border: 1px solid ${c.line};
      border-radius: 20px;
      box-shadow: 0 18px 50px rgba(0, 0, 0, 0.38);
      animation: pop 0.18s ease-out;
    }
    .dot { width: 10px; height: 10px; margin: 0 auto 10px; border-radius: 50%; background: ${c.accent}; box-shadow: 0 0 0 6px ${c.accentSoft}; }
    h2 { margin: 0; font-size: 22px; font-weight: 700; }
    p { margin: 4px 0 16px; font-size: 14px; color: ${c.muted}; }
    button {
      font: inherit; font-weight: 600; cursor: pointer;
      min-width: 96px; height: 38px; padding: 0 22px;
      border: 0; border-radius: 12px;
      background: ${c.accent}; color: ${c.onAccent};
    }
    button:focus-visible { outline: 2px solid ${c.accent}; outline-offset: 3px; }
    @keyframes pop { from { opacity: 0; transform: scale(0.96); } }
    @media (prefers-reduced-motion: reduce) { .card { animation: none; } }
  `;

  const card = document.createElement('div');
  card.className = 'card';
  card.setAttribute('role', 'alertdialog');
  card.setAttribute('aria-label', opts.title);
  const dot = document.createElement('div');
  dot.className = 'dot';
  const h = document.createElement('h2');
  h.textContent = opts.title;
  const p = document.createElement('p');
  p.textContent = opts.body;
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.textContent = opts.button;
  card.append(dot, h, p, btn);
  root.append(style, card);

  const close = () => {
    document.removeEventListener('keydown', onKey, true);
    host.remove();
  };
  const onKey = (e) => {
    if (e.key === 'Escape') close();
  };
  btn.addEventListener('click', close);
  document.addEventListener('keydown', onKey, true);
  (document.body || document.documentElement).appendChild(host);
  return 'shown';
}
