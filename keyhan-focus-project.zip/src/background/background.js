// Service worker: زنگ پایان جلسه، نشان (badge) روی آیکون و اعلان.
import { completeTimer, getSettings, getTimer } from '../core/timerService.js';
import { toFa } from '../core/format.js';
import { resolveTheme } from '../core/themes.js';
import { NOTICE_MAX_DELAY_MS, SOUND_MAX_DELAY_MS } from '../core/constants.js';
import { showEndOverlay } from './overlay.js';
import { getItem, setItem } from '../core/storage.js';
import { getCustomSound } from '../core/customSound.js';

const FINISH = 'kt-finish';
const TICK = 'kt-tick';

async function updateBadge(timer, settings) {
  if (!settings.badge || timer.status === 'idle') {
    await chrome.action.setBadgeText({ text: '' });
    return;
  }
  const remaining = timer.status === 'running' ? timer.endsAt - Date.now() : timer.remainingSeconds * 1000;
  await chrome.action.setBadgeText({ text: String(Math.max(1, Math.ceil(remaining / 60000))) });
  const colors = resolveTheme(settings).badge;
  await chrome.action.setBadgeBackgroundColor({
    color: timer.status === 'running' ? colors.running : colors.paused,
  });
  if (chrome.action.setBadgeTextColor) await chrome.action.setBadgeTextColor({ color: colors.text });
}

function notify(session, settings) {
  if (!settings.notifications) return;
  const minutes = Math.round(session.plannedMs / 60000);
  chrome.notifications.create(`kt-done-${session.id}`, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'کیهان تمرکز',
    message: `تمرکز ${toFa(minutes)} دقیقه‌ای تمام شد.`,
    priority: 2,
  });
}

async function sync() {
  const settings = await getSettings();
  let timer = await getTimer();

  if (timer.status === 'running' && Date.now() >= timer.endsAt) {
    const session = await completeTimer();
    if (session) notify(session, settings);
    timer = await getTimer();
  }

  await chrome.alarms.clear(FINISH);
  await chrome.alarms.clear(TICK);
  if (timer.status === 'running') {
    chrome.alarms.create(FINISH, { when: timer.endsAt });
    chrome.alarms.create(TICK, { periodInMinutes: 1 });
  }
  await updateBadge(timer, settings);
}

// ---- صدای پایان زمان کار -------------------------------------------------
// service worker صدا ندارد؛ برای پخش از یک سند offscreen استفاده می‌شود تا به بازبودن پاپ‌آپ وابسته نباشیم.
const OFFSCREEN_URL = 'offscreen.html';
const SOUND_PLAYED_KEY = 'soundPlayedFor';
let creatingOffscreen = null;

async function ensureOffscreen() {
  const url = chrome.runtime.getURL(OFFSCREEN_URL);
  const existing = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [url] });
  if (existing.length) return;
  if (!creatingOffscreen) {
    creatingOffscreen = chrome.offscreen
      .createDocument({
        url: OFFSCREEN_URL,
        reasons: ['AUDIO_PLAYBACK'],
        justification: 'پخش صدای کوتاه پایان زمان کار',
      })
      .finally(() => {
        creatingOffscreen = null;
      });
  }
  await creatingOffscreen;
}

/**
 * اگر آخرین جلسه با صدا تمام شده (تصمیم‌اش هنگام ثبت جلسه گرفته شده)، دقیقاً یک بار پخش می‌شود.
 * شناسه‌ی آخرین جلسه‌ی صداخورده در storage می‌ماند تا هیچ رویداد تکراری یا راه‌اندازی دوباره‌ی
 * service worker دوباره صدا پخش نکند.
 */
function maybePlayEndSound(result) {
  if (!result || !result.sound || !result.sessionId) return;
  const run = async () => {
    if (Date.now() - result.at > SOUND_MAX_DELAY_MS) return; // دیرهنگام: ناگهانی پخش نکن
    if ((await getItem(SOUND_PLAYED_KEY, null)) === result.sessionId) return;
    await setItem(SOUND_PLAYED_KEY, result.sessionId);
    try {
      await ensureOffscreen();
      const msg = { target: 'offscreen', type: 'kt-play', soundId: result.sound };
      if (result.sound === 'custom') {
        const custom = await getCustomSound(); // اعتبارسنجی‌شده؛ اگر حذف شده باشد دینگ پخش می‌شود
        if (custom) msg.custom = custom;
        else msg.soundId = 'ding';
      }
      await chrome.runtime.sendMessage(msg);
    } catch {
      /* پخش صدا هرگز نباید همگام‌سازی را متوقف کند */
    }
  };
  const locks = navigator.locks;
  return locks && locks.request ? locks.request('kt-sound', run) : run();
}

// ---- اعلان بصری پایان تایمر ----------------------------------------------
// داخل تب فعالِ پنجره‌ی آخرِ فعال تزریق می‌شود؛ اگر ممکن نبود (صفحه‌ی Chrome، فروشگاه، pdf داخلی، بدون تب…)
// بی‌صدا رها می‌شود و برای بعد صف نمی‌ماند.
const NOTICE_SHOWN_KEY = 'noticeShownFor';

async function showEndNotice(result) {
  const settings = await getSettings();
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab || tab.id == null || !/^https?:\/\//i.test(tab.url || '')) return;
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: showEndOverlay,
      args: [
        {
          sessionId: result.sessionId,
          title: 'دیگه کار بسه',
          body: 'زمان تمرکزت تموم شد',
          button: 'باشه',
          colors: resolveTheme(settings).overlay,
        },
      ],
    });
  } catch {
    /* صفحه‌ی محدود یا تب بسته‌شده: بدون خطا صرف‌نظر می‌کنیم */
  }
}

function maybeShowEndNotice(result) {
  if (!result || !result.notice || !result.sessionId) return;
  const run = async () => {
    if (Date.now() - result.at > NOTICE_MAX_DELAY_MS) return;
    if ((await getItem(NOTICE_SHOWN_KEY, null)) === result.sessionId) return;
    await setItem(NOTICE_SHOWN_KEY, result.sessionId); // هر جلسه حداکثر یک بار، حتی اگر تزریق شکست بخورد
    await showEndNotice(result);
  };
  const locks = navigator.locks;
  return locks && locks.request ? locks.request('kt-notice', run) : run();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.timer) {
    const next = changes.timer.newValue;
    const prev = changes.timer.oldValue;
    // فقط وقتی تایمر از «در حال اجرا» به پایان رسیده (جلسه‌ی تازه ثبت شده)
    if (prev && prev.status === 'running' && next && next.status === 'idle') {
      maybePlayEndSound(next.lastResult);
      maybeShowEndNotice(next.lastResult);
    }
  }
  if (changes.timer || changes.settings) sync();
});
chrome.alarms.onAlarm.addListener(() => sync());
chrome.runtime.onStartup.addListener(sync);
chrome.runtime.onInstalled.addListener(sync);
