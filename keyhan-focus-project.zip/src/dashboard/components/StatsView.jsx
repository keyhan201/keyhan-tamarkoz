import { useCallback, useState } from 'react';
import { KEYS } from '../../core/constants.js';
import { useStoredValue } from '../../hooks/useStoredValue.js';
import Icon from '../../shared/Icon.jsx';
import CompareTab from './stats/CompareTab.jsx';
import InsightsTab from './stats/InsightsTab.jsx';
import DailyTab from './stats/DailyTab.jsx';
import ManualSessionDialog from './stats/ManualSessionDialog.jsx';

const EMPTY = [];
const TABS = [
  { id: 'daily', label: 'روزانه' },
  { id: 'compare', label: 'مقایسه' },
  { id: 'insights', label: 'رکوردها و تقویم' },
];

/** آمار تمرکز: تب «روزانه» (فهرست جلسه‌ها) و تب «مقایسه» (نمودارها). فقط از جلسه‌های تایمر و دستی ساخته می‌شود. */
export default function StatsView() {
  const [sessions, , ready] = useStoredValue(KEYS.sessions, EMPTY);
  const [tab, setTab] = useState('daily');
  const [dialog, setDialog] = useState(null); // null | { session? }
  const close = useCallback(() => setDialog(null), []);

  if (!ready) return null;

  const onKey = (e) => {
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    const i = TABS.findIndex((t) => t.id === tab);
    setTab(TABS[(i + 1) % TABS.length].id);
  };

  return (
    <div className="page">
      <header className="page-head">
        <h1>آمار تمرکز</h1>
        <button className="btn solid" onClick={() => setDialog({})}><Icon name="plus" size={17} /> افزودن جلسه</button>
      </header>

      <div className="tabs" role="tablist" aria-label="بخش‌های آمار" onKeyDown={onKey}>
        {TABS.map((t) => (
          <button key={t.id} role="tab" id={`tab-${t.id}`} aria-selected={t.id === tab} aria-controls={`panel-${t.id}`} tabIndex={t.id === tab ? 0 : -1} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      <div role="tabpanel" id={`panel-${tab}`} aria-labelledby={`tab-${tab}`}>
        {tab === 'daily' ? <DailyTab sessions={sessions} onEdit={(session) => setDialog({ session })} /> : tab === 'compare' ? <CompareTab sessions={sessions} /> : <InsightsTab sessions={sessions} />}
      </div>

      {dialog && <ManualSessionDialog session={dialog.session} onClose={close} />}
    </div>
  );
}
