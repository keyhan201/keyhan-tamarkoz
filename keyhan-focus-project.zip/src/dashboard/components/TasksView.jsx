import { useState } from 'react';
import { KEYS } from '../../core/constants.js';
import { addTask, clearDone, removeTask, toggleTask } from '../../core/tasks.js';
import { formatFullDay, toFa } from '../../core/format.js';
import { useStoredValue } from '../../hooks/useStoredValue.js';
import Icon from '../../shared/Icon.jsx';

const EMPTY = [];

export default function TasksView() {
  const [tasks, setTasks, ready] = useStoredValue(KEYS.tasks, EMPTY);
  const [text, setText] = useState('');

  if (!ready) return null;

  const submit = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    setTasks((list) => addTask(list, text));
    setText('');
  };

  const open = tasks.filter((t) => !t.done);
  const done = tasks.filter((t) => t.done);

  const row = (t) => (
    <li key={t.id} className={t.done ? 'task done' : 'task'}>
      <button
        className="tick-box"
        role="checkbox"
        aria-checked={t.done}
        aria-label={t.text}
        onClick={() => setTasks((l) => toggleTask(l, t.id))}
      >
        {t.done && <Icon name="check" size={14} />}
      </button>
      <span className="task-text">{t.text}</span>
      <button className="icon-btn" onClick={() => setTasks((l) => removeTask(l, t.id))} aria-label="حذف کار" title="حذف">
        <Icon name="trash" size={17} />
      </button>
    </li>
  );

  return (
    <div className="page narrow">
      <header className="page-head">
        <h1>کارهای روزانه</h1>
        <span className="date">{formatFullDay(Date.now())}</span>
      </header>

      <form className="add" onSubmit={submit}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="یک کار تازه بنویسید" aria-label="کار تازه" maxLength={200} />
        <button type="submit" className="add-btn" aria-label="افزودن کار" disabled={!text.trim()}>
          <Icon name="plus" size={20} />
        </button>
      </form>

      {tasks.length === 0 ? (
        <p className="empty">فهرست خالی است. اولین کار امروز را بنویسید.</p>
      ) : (
        <>
          <ul className="tasks">
            {open.map(row)}
            {done.map(row)}
          </ul>
          <footer className="tasks-foot">
            <span>{open.length ? `${toFa(open.length)} کار باقی مانده` : 'همه‌ی کارها انجام شد'}</span>
            {done.length > 0 && (
              <button className="link" onClick={() => setTasks(clearDone)}>
                پاک کردن انجام‌شده‌ها
              </button>
            )}
          </footer>
        </>
      )}
    </div>
  );
}
