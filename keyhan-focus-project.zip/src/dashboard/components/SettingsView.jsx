import { useEffect, useRef, useState } from 'react';
import { KEYS, MAX_MINUTES, MIN_MINUTES } from '../../core/constants.js';
import { fromFa, toFa } from '../../core/format.js';
import { MAX_BACKUP_BYTES, parseBackup, restoreBackup } from '../../core/backup.js';
import { getItem, setItem } from '../../core/storage.js';
import { useSettings } from '../../hooks/useStoredValue.js';
import { dailySummaryJson, sessionsToCsv } from '../../core/exportStats.js';
import { downloadText } from '../../shared/download.js';
import ThemeSettings from './settings/ThemeSettings.jsx';
import SoundSettings from './settings/SoundSettings.jsx';
import Icon from '../../shared/Icon.jsx';

function Switch({ checked, onChange, label }) {
  return (
    <button role="switch" aria-checked={checked} aria-label={label} className="switch" onClick={() => onChange(!checked)}>
      <span />
    </button>
  );
}

function Row({ title, hint, children }) {
  return (
    <div className="row">
      <div>
        <div className="row-title">{title}</div>
        {hint && <div className="row-hint">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

export default function SettingsView() {
  const [s, patch, ready] = useSettings();
  const [minutes, setMinutes] = useState('');
  const [confirm, setConfirm] = useState(false);
  const [restore, setRestore] = useState(null); // null | { step: 'confirm' | 'done' | 'error', ... }
  const fileInput = useRef(null);

  useEffect(() => {
    setMinutes(toFa(s.defaultMinutes));
  }, [s.defaultMinutes]);

  if (!ready) return null;

  const commitMinutes = () => {
    const n = parseInt(fromFa(minutes), 10);
    if (Number.isInteger(n) && n >= MIN_MINUTES && n <= MAX_MINUTES) patch({ defaultMinutes: n });
    else setMinutes(toFa(s.defaultMinutes));
  };

  const exportData = async () => {
    const data = {
      exportedAt: new Date().toISOString(),
      sessions: await getItem(KEYS.sessions, []),
      tasks: await getItem(KEYS.tasks, []),
      settings: s,
    };
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'keyhan-tamarkoz-backup.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const pickBackup = async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = ''; // انتخاب دوباره‌ی همان فایل هم کار کند
    if (!file) return;
    if (file.size > MAX_BACKUP_BYTES) {
      setRestore({ step: 'error', message: 'حجم فایل بیش از حد مجاز است.' });
      return;
    }
    const res = parseBackup(await file.text());
    setRestore(res.ok ? { step: 'confirm', data: res.data, summary: res.summary } : { step: 'error', message: res.error });
  };

  const applyRestore = async () => {
    const { data, summary } = restore;
    try {
      await restoreBackup(data);
      setRestore({ step: 'done', summary });
    } catch {
      setRestore({ step: 'error', message: 'بازیابی انجام نشد. دوباره تلاش کنید.' });
    }
  };

  const summaryText = (m) =>
    `${toFa(m.sessions)} جلسه، ${toFa(m.tasks)} کار${m.settings ? ' و تنظیمات' : ''}` +
    (m.skipped ? ` (${toFa(m.skipped)} مورد نامعتبر نادیده گرفته شد)` : '');

  return (
    <div className="page narrow">
      <header className="page-head">
        <h1>تنظیمات</h1>
      </header>

      <h2 className="sub first">ظاهر</h2>
      <div className="rows">
        <ThemeSettings s={s} patch={patch} Row={Row} />
      </div>

      <h2 className="sub">عمومی</h2>
      <div className="rows">
        <Row title="مدت پیش‌فرض تایمر" hint={`عددی بین ${toFa(MIN_MINUTES)} تا ${toFa(MAX_MINUTES)} دقیقه`}>
          <div className="mini-field">
            <input
              inputMode="numeric"
              value={minutes}
              onChange={(e) => setMinutes(e.target.value)}
              onBlur={commitMinutes}
              onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
              aria-label="مدت پیش‌فرض به دقیقه"
            />
            <span>دقیقه</span>
          </div>
        </Row>
        <Row title="نمایش دقیقه‌های باقی‌مانده روی آیکون" hint="هنگام اجرای تایمر، عدد روی آیکون افزونه دیده می‌شود.">
          <Switch checked={s.badge} onChange={(v) => patch({ badge: v })} label="نمایش دقیقه روی آیکون" />
        </Row>
        <Row title="جمله‌های انگیزشی" hint="یک جمله‌ی کوتاه زیر تایمر در پنجره‌ی افزونه نشان داده می‌شود.">
          <Switch checked={s.showQuotes} onChange={(v) => patch({ showQuotes: v })} label="نمایش جمله‌های انگیزشی" />
        </Row>
        <Row title="بخش کارهای روزانه" hint="پنهان‌کردن این بخش کارهای ذخیره‌شده را پاک نمی‌کند؛ با نمایش دوباره همه برمی‌گردند.">
          <Switch checked={s.tasksEnabled} onChange={(v) => patch({ tasksEnabled: v })} label="نمایش بخش کارهای روزانه" />
        </Row>
      </div>

      <h2 className="sub">اعلان‌ها</h2>
      <div className="rows">
        <Row title="اعلان پایان جلسه" hint="وقتی تایمر تمام شد یک اعلان نشان داده شود.">
          <Switch checked={s.notifications} onChange={(v) => patch({ notifications: v })} label="اعلان پایان جلسه" />
        </Row>
        <SoundSettings s={s} patch={patch} Row={Row} Switch={Switch} />
      </div>

      <h2 className="sub">داده‌ها</h2>
      <div className="rows">
        <Row title="دریافت نسخه‌ی پشتیبان" hint="جلسه‌ها، کارها و تنظیمات در یک فایل JSON ذخیره می‌شوند.">
          <button className="btn" onClick={exportData}>
            <Icon name="download" size={17} /> دریافت فایل
          </button>
        </Row>
        <Row title="خروجی آمار برای تحلیل" hint="جدول جلسه‌ها (CSV برای Excel) یا جمع روزانه (JSON). فقط جلسه‌های معتبر.">
          <div className="confirm">
            <button className="btn" onClick={async () => downloadText('keyhan-tamarkoz-sessions.csv', sessionsToCsv(await getItem(KEYS.sessions, [])), 'text/csv')}>CSV</button>
            <button className="btn" onClick={async () => downloadText('keyhan-tamarkoz-daily.json', dailySummaryJson(await getItem(KEYS.sessions, [])), 'application/json')}>JSON</button>
          </div>
        </Row>
        <Row title="بازیابی از فایل پشتیبان" hint="فایل JSON دریافت‌شده از همین افزونه را انتخاب کنید.">
          <input ref={fileInput} type="file" accept=".json,application/json" hidden onChange={pickBackup} />
          <button className="btn" onClick={() => fileInput.current && fileInput.current.click()}>انتخاب فایل</button>
        </Row>
        {restore && restore.step === 'confirm' && (
          <div role="status">
            <Row title="بازیابی انجام شود؟" hint={`این فایل شامل ${summaryText(restore.summary)} است. جلسه‌ها و کارهای فعلی با محتوای فایل جایگزین می‌شوند.`}>
              <div className="confirm">
                <button className="btn danger" onClick={applyRestore}>بله، بازیابی شود</button>
                <button className="btn" onClick={() => setRestore(null)}>انصراف</button>
              </div>
            </Row>
          </div>
        )}
        {restore && restore.step === 'done' && (
          <div role="status">
            <Row title="بازیابی انجام شد" hint={`${summaryText(restore.summary)} بازیابی شد.`}>
              <button className="btn" onClick={() => setRestore(null)}>بستن</button>
            </Row>
          </div>
        )}
        {restore && restore.step === 'error' && (
          <div role="alert">
            <Row title="بازیابی انجام نشد" hint={restore.message}>
              <button className="btn" onClick={() => setRestore(null)}>بستن</button>
            </Row>
          </div>
        )}
        <Row title="حذف همه‌ی جلسه‌ها" hint="آمار تمرکز برای همیشه پاک می‌شود. کارهای روزانه تغییری نمی‌کنند.">
          {confirm ? (
            <div className="confirm">
              <button
                className="btn danger"
                onClick={async () => {
                  await setItem(KEYS.sessions, []);
                  setConfirm(false);
                }}
              >
                بله، حذف شود
              </button>
              <button className="btn" onClick={() => setConfirm(false)}>انصراف</button>
            </div>
          ) : (
            <button className="btn danger" onClick={() => setConfirm(true)}>حذف جلسه‌ها</button>
          )}
        </Row>
      </div>
    </div>
  );
}
