import { useMemo, useState } from 'react';
import { addDays, buildComparison, sessionsOfDay, startOfDay } from '../../../core/dailyStats.js';
import { formatFullDay, formatTime } from '../../../core/format.js';
import { endOf, isManual } from '../../../core/sessionRules.js';
import { deleteSession } from '../../../core/timerService.js';
import Icon from '../../../shared/Icon.jsx';

/** نمای روزانه: فقط یک روز در هر لحظه؛ فهرست جلسه‌ها فقط ساعت شروع و پایان را نشان می‌دهد. */
export default function DailyTab({ sessions, onEdit }) {
  const [picked, setPicked] = useState(() => startOfDay(Date.now()));
  const [confirmId, setConfirmId] = useState(null);

  const today = startOfDay(Date.now());
  const day = Math.min(picked, today); // روز آینده هرگز نمایش داده نمی‌شود
  const isToday = day === today;

  const cmp = useMemo(() => buildComparison(sessions, day), [sessions, day]);
  const list = useMemo(() => sessionsOfDay(sessions, day).sort((a, b) => b.startedAt - a.startedAt), [sessions, day]);

  return (
    <div className="daily">
      <div className="day-nav" role="group" aria-label="انتخاب روز">
        {/* در صفحه‌ی راست‌چین «قبلی» سمت راست و «بعدی» سمت چپ تاریخ است */}
        <button className="icon-btn" onClick={() => setPicked(addDays(day, -1))} aria-label="روز قبلی" title="روز قبلی"><span className="chev">›</span></button>
        <h2 aria-live="polite">{formatFullDay(day)}</h2>
        <button className="icon-btn" disabled={isToday} onClick={() => setPicked(addDays(day, 1))} aria-label="روز بعدی" title="روز بعدی"><span className="chev">‹</span></button>
      </div>

      <table className="cmp-table">
        <thead>
          <tr><th scope="col">معیار</th><th scope="col">{isToday ? 'امروز' : 'این روز'}</th><th scope="col">روز قبل</th><th scope="col">تغییر</th></tr>
        </thead>
        <tbody>
          {cmp.rows.map((r) => (
            <tr key={r.id}><th scope="row">{r.title}</th><td>{r.current}</td><td>{r.previous}</td><td>{r.change}</td></tr>
          ))}
        </tbody>
      </table>

      <h2 className="sub">جلسه‌ها</h2>
      {list.length === 0 ? (
        <p className="day-empty">در این روز جلسه‌ای ثبت نشده است.</p>
      ) : (
        <ul className="sessions day-sessions">
          {list.map((s) => (
            <li key={s.id}>
              <span className="s-range">{formatTime(s.startedAt)} تا {formatTime(endOf(s))}</span>
              {confirmId === s.id ? (
                <span className="s-actions confirm">
                  <span>حذف شود؟</span>
                  <button className="btn danger small" onClick={() => { setConfirmId(null); deleteSession(s.id); }}>بله</button>
                  <button className="btn small" onClick={() => setConfirmId(null)}>خیر</button>
                </span>
              ) : (
                <span className="s-actions">
                  {isManual(s) && (
                    <button className="icon-btn" onClick={() => onEdit(s)} aria-label="ویرایش این جلسه" title="ویرایش"><Icon name="edit" size={17} /></button>
                  )}
                  <button className="icon-btn" onClick={() => setConfirmId(s.id)} aria-label="حذف این جلسه" title="حذف"><Icon name="trash" size={17} /></button>
                </span>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
