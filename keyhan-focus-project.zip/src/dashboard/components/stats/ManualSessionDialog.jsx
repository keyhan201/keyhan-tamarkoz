import { useEffect, useMemo, useRef, useState } from 'react';
import { duration, formatTime, toFa } from '../../../core/format.js';
import { JALALI_MONTHS, jalaliMonthLength, jalaliToDate, toJalali } from '../../../core/jalali.js';
import { addManualSession, parseClock, updateManualSession } from '../../../core/sessions.js';

const clockOf = (ts) => {
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
};

/** فرم افزودن/ویرایش جلسه‌ی دستی: تاریخ شمسی، ساعت شروع و پایان؛ مدت خودکار حساب می‌شود. */
export default function ManualSessionDialog({ session, onClose }) {
  const editing = Boolean(session);
  const nowJ = toJalali(new Date());
  const initial = editing ? toJalali(new Date(session.startedAt)) : nowJ;

  const [date, setDate] = useState(initial);
  const [start, setStart] = useState(editing ? clockOf(session.startedAt) : '');
  const [end, setEnd] = useState(editing ? clockOf(session.endedAt) : '');
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const first = useRef(null);

  useEffect(() => {
    first.current?.focus();
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const yesterday = toJalali(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() - 1));
  const sameDay = (a, b) => a.jy === b.jy && a.jm === b.jm && a.jd === b.jd;
  const years = useMemo(() => {
    const set = new Set([nowJ.jy, nowJ.jy - 1, nowJ.jy - 2, nowJ.jy - 3, initial.jy]);
    return [...set].sort((a, b) => b - a);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const days = Array.from({ length: jalaliMonthLength(date.jy, date.jm) }, (_, i) => i + 1);

  const setPart = (k, v) => {
    const next = { ...date, [k]: Number(v) };
    next.jd = Math.min(next.jd, jalaliMonthLength(next.jy, next.jm));
    setDate(next);
    setErr(null);
  };

  const s = parseClock(start);
  const e = parseClock(end);
  const previewMs = s !== null && e !== null && e > s ? (e - s) * 60000 : null;

  const submit = async (ev) => {
    ev.preventDefault();
    if (busy) return;
    setBusy(true);
    const input = { ...date, start, end };
    const res = editing ? await updateManualSession(session.id, input) : await addManualSession(input);
    setBusy(false);
    if (res.ok) onClose();
    else setErr(res);
  };

  const fieldErr = (f) => (err && err.field === f ? err.error : null);

  return (
    <div className="modal-scrim" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form className="modal" role="dialog" aria-modal="true" aria-labelledby="dlg-title" onSubmit={submit} noValidate>
        <h2 id="dlg-title">{editing ? 'ویرایش جلسه' : 'افزودن جلسه'}</h2>

        <fieldset className="fld">
          <legend>تاریخ</legend>
          <div className="quick">
            <button type="button" className={'chip' + (sameDay(date, nowJ) ? ' on' : '')} onClick={() => { setDate(nowJ); setErr(null); }}>امروز</button>
            <button type="button" className={'chip' + (sameDay(date, yesterday) ? ' on' : '')} onClick={() => { setDate(yesterday); setErr(null); }}>دیروز</button>
          </div>
          <div className="date-row">
            <select ref={first} aria-label="روز" value={date.jd} onChange={(e) => setPart('jd', e.target.value)}>
              {days.map((d) => <option key={d} value={d}>{toFa(d)}</option>)}
            </select>
            <select aria-label="ماه" value={date.jm} onChange={(e) => setPart('jm', e.target.value)}>
              {JALALI_MONTHS.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
            </select>
            <select aria-label="سال" value={date.jy} onChange={(e) => setPart('jy', e.target.value)}>
              {years.map((y) => <option key={y} value={y}>{toFa(y)}</option>)}
            </select>
          </div>
          {fieldErr('date') && <p className="field-err" role="alert">{fieldErr('date')}</p>}
        </fieldset>

        <div className="time-row">
          <label className="fld">
            <span>ساعت شروع</span>
            <input type="time" dir="ltr" value={start} onChange={(e) => { setStart(e.target.value); setErr(null); }} />
            {fieldErr('start') && <p className="field-err" role="alert">{fieldErr('start')}</p>}
          </label>
          <label className="fld">
            <span>ساعت پایان</span>
            <input type="time" dir="ltr" value={end} onChange={(e) => { setEnd(e.target.value); setErr(null); }} />
            {fieldErr('end') && <p className="field-err" role="alert">{fieldErr('end')}</p>}
          </label>
        </div>

        <p className="preview" aria-live="polite">
          {previewMs ? `مدت جلسه: ${duration(previewMs)}` : 'مدت جلسه از اختلاف ساعت شروع و پایان حساب می‌شود.'}
        </p>
        {err && !['date', 'start', 'end'].includes(err.field) && <p className="field-err" role="alert">{err.error}</p>}

        <div className="modal-actions">
          <button type="submit" className="btn solid" disabled={busy}>{editing ? 'ذخیره‌ی تغییرات' : 'ذخیره'}</button>
          <button type="button" className="btn" onClick={onClose}>انصراف</button>
        </div>
      </form>
    </div>
  );
}
