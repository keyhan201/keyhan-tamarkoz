import { useMemo, useState } from 'react';
import {
  METRICS, RANGES, buildSeries, changeText, chartRows, clampAnchor, hasData, metricText, periodOf, shiftAnchor,
} from '../../../core/compare.js';
import { startOfDay } from '../../../core/dailyStats.js';
import { useThemeColors } from '../../../hooks/useThemeColors.js';
import ChartView, { CHART_TYPES } from './ChartView.jsx';

function Segmented({ label, items, value, onChange }) {
  return (
    <div className="seg" role="radiogroup" aria-label={label}>
      {items.map((it) => (
        <button key={it.id} role="radio" aria-checked={it.id === value} onClick={() => onChange(it.id)}>{it.label}</button>
      ))}
    </div>
  );
}

export default function CompareTab({ sessions }) {
  const colors = useThemeColors();
  const [range, setRange] = useState('week');
  const [metricId, setMetricId] = useState('total');
  const [type, setType] = useState('column');
  const today = startOfDay(Date.now());
  const [anchor, setAnchor] = useState(today);

  const series = useMemo(() => buildSeries(sessions, range, anchor, today), [sessions, range, anchor, today]);
  const { rows, unit } = useMemo(() => chartRows(series, metricId), [series, metricId]);
  const metric = METRICS.find((m) => m.id === metricId);
  const rangeInfo = RANGES.find((r) => r.id === range);

  const nextAnchor = shiftAnchor(range, series.anchor, 1);
  const canNext = periodOf(range, nextAnchor, today).buckets[0].start <= today;

  const empty = !hasData(series.cur);

  const pickRange = (r) => { setRange(r); setAnchor(today); };
  const cur = metricText(metricId, { ...series.cur.all, future: false });
  const prev = metricText(metricId, { ...series.prev.all, future: false });

  return (
    <div className="compare-tab">
      <div className="ctl">
        <Segmented label="بازه‌ی زمانی" items={RANGES} value={range} onChange={pickRange} />
        <div className="period-nav" role="group" aria-label="جابه‌جایی بازه">
          {/* در صفحه‌ی راست‌چین «قبلی» سمت راست و «بعدی» سمت چپ است */}
          <button className="icon-btn" onClick={() => setAnchor(shiftAnchor(range, series.anchor, -1))} aria-label="بازه‌ی قبلی" title="بازه‌ی قبلی"><span className="chev">›</span></button>
          <div className="period-label" aria-live="polite"><b>{series.cur.label}</b><small>{rangeInfo.hint}</small></div>
          <button className="icon-btn" disabled={!canNext} onClick={() => setAnchor(clampAnchor(nextAnchor, today))} aria-label="بازه‌ی بعدی" title="بازه‌ی بعدی"><span className="chev">‹</span></button>
        </div>
      </div>

      <div className="ctl metric-control">
        <span className="ctl-label">معیار</span>
        <Segmented label="معیار مقایسه" items={METRICS.map((m) => ({ id: m.id, label: m.short }))} value={metricId} onChange={setMetricId} />
      </div>

      <div className="ctl">
        <span className="ctl-label">نوع نمودار</span>
        <div className="chart-types" role="radiogroup" aria-label="نوع نمودار">
          {CHART_TYPES.map((t) => (
            <button key={t.id} role="radio" aria-checked={t.id === type} onClick={() => setType(t.id)}>{t.label}</button>
          ))}
        </div>
      </div>

      <section className="chart-card" aria-label="نمودار">
        <header className="chart-head">
          <h2>{metric.label}</h2>
          <span>واحد: {unit.name} · {series.cur.label}</span>
        </header>
        {empty && <p className="chart-empty">در این بازه جلسه‌ای ثبت نشده است.</p>}
        <ChartView type={type} metricId={metricId} rows={rows} unit={unit} colors={colors} />
      </section>

      <dl className="figures">
        <div><dt>این بازه</dt><dd>{cur}</dd></div>
        <div><dt>بازه‌ی قبل ({series.prev.label})</dt><dd>{prev}</dd></div>
        <div><dt>تغییر</dt><dd>{changeText(metricId, series)}</dd></div>
      </dl>

      <details className="data-details">
        <summary>جدول داده‌ها</summary>
        <div className="table-wrap">
          <table>
            <thead><tr><th>دسته</th><th>این بازه</th><th>بازه‌ی قبل</th></tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.i}><td>{r.full}</td><td>{r.curText}</td><td>{r.prevText}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
    </div>
  );
}
