import { useState } from 'react';
import {
  Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import { METRICS } from '../../../core/compare.js';
import { toFa } from '../../../core/format.js';

export const CHART_TYPES = [
  { id: 'column', label: 'ستونی' },
  { id: 'bar', label: 'میله‌ای' },
];

const fmt = (v) => toFa(String(v).replace('.', '٫'));
const MARGIN = { top: 12, right: 4, left: 4, bottom: 4 };

function Tip({ active, payload, colors, short }) {
  if (!active || !payload || !payload.length) return null;
  const row = payload[0].payload;
  if (!row || !row.full) return null;
  return (
    <div className="chart-tip" dir="rtl">
      <strong>{row.full}</strong>
      <div className="tip-line"><i style={{ background: colors.accent }} /><span>{short}</span><b>{row.curText}</b></div>
    </div>
  );
}

/**
 * داده‌ی هفتگی همیشه شنبه تا جمعه است؛ برچسب و مقدار هر روز در همان ردیف می‌مانند.
 * ستون‌ها از راست به چپ و میله‌ها از بالا به پایین، با برچسب در سمت راست، رسم می‌شوند.
 */
export default function ChartView({ type, metricId, rows, unit, colors }) {
  const [width, setWidth] = useState(0);
  const compact = width > 0 && width < 420;
  const metric = METRICS.find((m) => m.id === metricId);
  const n = rows.length;
  const step = n > 20 ? 3 : n > 10 ? 2 : 1;
  const tick = { fill: colors.mute, fontSize: 12 };
  const tip = <Tip colors={colors} short={metric.short} />;

  if (type === 'bar') {
    return (
      <ResponsiveContainer width="100%" height={Math.max(280, n * 24 + 48)}>
        <BarChart layout="vertical" data={rows} margin={MARGIN}>
          <CartesianGrid horizontal={false} stroke={colors.line} />
          <XAxis type="number" reversed tick={tick} tickLine={false} axisLine={{ stroke: colors.line }} tickFormatter={fmt}
            allowDecimals={unit.digits > 0} domain={[0, (max) => Math.max(max, 1)]} />
          <YAxis type="category" dataKey="label" reversed={false} orientation="right" width={72} interval={0} tick={tick} tickLine={false} axisLine={false} />
          <Tooltip content={tip} cursor={{ fill: colors.accentDim }} />
          <Bar dataKey="cur" fill={colors.accent} radius={[4, 0, 0, 4]} barSize={14} isAnimationActive={false} />
        </BarChart>
      </ResponsiveContainer>
    );
  }

  if (type !== 'column') return null;
  return (
    <ResponsiveContainer width="100%" height={320} onResize={(w) => setWidth(w)}>
      <BarChart data={rows} margin={MARGIN} barGap={2}>
        <CartesianGrid vertical={false} stroke={colors.line} />
        <XAxis dataKey="label" reversed interval={step - 1} tick={{ ...tick, fontSize: compact ? 10 : 12 }}
          angle={compact ? -70 : 0} textAnchor={compact ? 'end' : 'middle'} height={compact ? 70 : 30}
          tickMargin={8} tickLine={false} axisLine={{ stroke: colors.line }} />
        <YAxis orientation="right" width={44} tick={tick} tickLine={false} axisLine={false} tickFormatter={fmt}
          allowDecimals={unit.digits > 0} domain={[0, (max) => Math.max(max, 1)]} />
        <Tooltip content={tip} cursor={{ fill: colors.accentDim }} />
        <Bar dataKey="cur" fill={colors.accent} radius={[4, 4, 0, 0]} maxBarSize={36} isAnimationActive={false} />
      </BarChart>
    </ResponsiveContainer>
  );
}
