import { useMemo, useState } from 'react';
import { buildInsights, compareMonth, jalaliMonthOf, monthGrid, shiftMonth } from '../../../core/insights.js';
import { duration, formatFullDay, formatTime, toFa } from '../../../core/format.js';
import { JALALI_MONTHS, WEEK_DAYS } from '../../../core/jalali.js';
import { startOfDay } from '../../../core/dailyStats.js';
import { endOf } from '../../../core/sessionRules.js';

const SHORT = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج']; // شنبه … جمعه
const EMPTY_TEXT = 'هنوز داده‌ی کافی نیست';

function Figure({ title, value, sub }) {
  return (
    <div className="fig">
      <dt>{title}</dt>
      <dd>{value || <span className="fig-empty">{EMPTY_TEXT}</span>}</dd>
      {value && sub ? <small>{sub}</small> : null}
    </div>
  );
}

function DayDetail({ cell }) {
  const d = cell.data;
  return (
    <section className="day-detail" aria-live="polite" aria-label="جزئیات روز">
      <h3>{formatFullDay(cell.ts)}</h3>
      {!d ? (
        <p className="day-empty">در این روز جلسه‌ای ثبت نشده است.</p>
      ) : (
        <>
          <dl className="figures mini">
            <div><dt>جلسه‌ها</dt><dd>{toFa(d.count)}</dd></div>
            <div><dt>مجموع تمرکز واقعی</dt><dd>{duration(d.focusedMs)}</dd></div>
            <div>
              <dt>زمان برنامه‌ریزی‌شده</dt>
              <dd>{d.plannedMs > 0 ? duration(d.plannedMs) : <span className="fig-empty">ثبت نشده</span>}</dd>
              {d.plannedMs > 0 && <small>زمان واقعی همین جلسه‌ها: {duration(d.plannedActualMs)}</small>}
            </div>
          </dl>
          {d.unplanned > 0 && <p className="note">{toFa(d.unplanned)} جلسه زمان برنامه‌ریزی‌شده ندارد و در مقایسه‌ی بالا نیامده است.</p>}
          <ul className="sessions day-sessions">
            {d.sessions.map((s) => (
              <li key={s.id}><span className="s-range">{formatTime(s.startedAt)} تا {formatTime(endOf(s))}</span></li>
            ))}
          </ul>
        </>
      )}
    </section>
  );
}

function Calendar({ dayMap }) {
  const today = startOfDay(Date.now());
  const current = jalaliMonthOf(today);
  const [month, setMonth] = useState(current);
  const [picked, setPicked] = useState(null);
  const grid = useMemo(() => monthGrid(month.jy, month.jm, dayMap), [month, dayMap]);
  const atNow = compareMonth(month, current) >= 0;
  const cells = grid.weeks.flat().filter(Boolean);
  const sel = cells.find((c) => c.ts === picked) || null;
  const go = (delta) => { setMonth((m) => shiftMonth(m, delta)); setPicked(null); };

  return (
    <div className="cal">
      <div className="day-nav" role="group" aria-label="انتخاب ماه">
        <button className="icon-btn" onClick={() => go(-1)} aria-label="ماه قبل" title="ماه قبل"><span className="chev">›</span></button>
        <h2 aria-live="polite">{JALALI_MONTHS[month.jm - 1]} {toFa(month.jy)}</h2>
        <button className="icon-btn" disabled={atNow} onClick={() => go(1)} aria-label="ماه بعد" title="ماه بعد"><span className="chev">‹</span></button>
      </div>
      <div className="cal-grid" role="grid" aria-label="تقویم فعالیت">
        <div className="cal-row head" role="row">
          {WEEK_DAYS.map((n, i) => <span key={n} role="columnheader" title={n} aria-label={n}>{SHORT[i]}</span>)}
        </div>
        {grid.weeks.map((week, wi) => (
          <div className="cal-row" role="row" key={wi}>
            {week.map((c, ci) => {
              if (!c) return <span key={ci} className="cal-cell blank" role="gridcell" />;
              const future = c.ts > today;
              const label = `${formatFullDay(c.ts)}: ${c.data ? `${toFa(c.data.count)} جلسه، ${duration(c.data.focusedMs)}` : 'بدون جلسه'}`;
              return (
                <button
                  key={ci}
                  role="gridcell"
                  className={`cal-cell lvl-${c.level}${c.ts === today ? ' today' : ''}${picked === c.ts ? ' sel' : ''}`}
                  disabled={future}
                  aria-label={label}
                  aria-pressed={picked === c.ts}
                  title={label}
                  onClick={() => setPicked(c.ts === picked ? null : c.ts)}
                >
                  {toFa(c.jd)}
                </button>
              );
            })}
          </div>
        ))}
      </div>
      <p className="legend" aria-hidden="true">کم <i className="cal-cell lvl-1" /><i className="cal-cell lvl-2" /><i className="cal-cell lvl-3" /><i className="cal-cell lvl-4" /> زیاد</p>
      {sel ? <DayDetail cell={sel} /> : <p className="day-empty">برای دیدن جزئیات، روی یک روز بزنید.</p>}
    </div>
  );
}

/** رکوردها، زنجیره، تقویم شمسی (هفته از شنبه) و روزهای پربازده. */
export default function InsightsTab({ sessions }) {
  const ins = useMemo(() => buildInsights(sessions), [sessions]);
  const { longest, mostSessions, mostFocus, streaks, weekdays } = ins;
  const maxTotal = Math.max(0, ...weekdays.rows.map((r) => r.totalMs));
  const dayText = (r) => `${r.weekday} ${formatFullDay(r.ts).split('،').pop().trim()}`.trim();

  return (
    <div className="insights">
      <h2 className="sub first">رکوردها</h2>
      <dl className="figures records">
        <Figure title="طولانی‌ترین جلسه" value={longest && duration(longest.focusedMs)} sub={longest && formatFullDay(longest.ts)} />
        <Figure title="بیشترین جلسه در یک روز" value={mostSessions && `${toFa(mostSessions.count)} جلسه`} sub={mostSessions && formatFullDay(mostSessions.ts)} />
        <Figure title="بیشترین تمرکز در یک روز" value={mostFocus && duration(mostFocus.focusedMs)} sub={mostFocus && formatFullDay(mostFocus.ts)} />
        <Figure title="زنجیره‌ی فعلی" value={ins.hasData ? `${toFa(streaks.current)} روز` : null} sub="روزهای متوالی دارای تمرکز" />
        <Figure
          title="بهترین زنجیره"
          value={ins.hasData ? `${toFa(streaks.best)} روز` : null}
          sub={streaks.best > 1 ? `${formatFullDay(streaks.bestFrom).split('،').pop().trim()} تا ${formatFullDay(streaks.bestTo).split('،').pop().trim()}` : null}
        />
      </dl>

      <h2 className="sub">تقویم فعالیت</h2>
      {ins.hasData ? <Calendar dayMap={ins.dayMap} /> : <p className="day-empty">{EMPTY_TEXT}. بعد از اولین جلسه، تقویم اینجا پر می‌شود.</p>}

      <h2 className="sub">روزهای پربازده</h2>
      {ins.hasData ? (
        <ul className="weekday-bars" aria-label="مجموع تمرکز به تفکیک روز هفته">
          {weekdays.rows.map((r) => (
            <li key={r.index} className={r.index === weekdays.topIndex ? 'top' : ''}>
              <span className="wd-name">{r.name}</span>
              <span className="wd-bar" aria-hidden="true"><i style={{ width: `${maxTotal ? Math.max(r.totalMs ? 4 : 0, (r.totalMs / maxTotal) * 100) : 0}%` }} /></span>
              <span className="wd-val">{r.totalMs ? `${duration(r.totalMs)}` : '—'}</span>
              <small className="wd-sub">{r.activeDays ? `میانگین ${duration(r.avgMs)} در ${toFa(r.activeDays)} روز` : ''}</small>
            </li>
          ))}
        </ul>
      ) : (
        <p className="day-empty">{EMPTY_TEXT}.</p>
      )}
    </div>
  );
}
