import { useMemo, useRef, useState } from 'react';
import Dropdown from '../../../shared/Dropdown.jsx';
import Icon from '../../../shared/Icon.jsx';
import { KEYS } from '../../../core/constants.js';
import { SOUNDS, CUSTOM_SOUND_ID, playCustom, playSound, soundIdOf } from '../../../core/sounds.js';
import {
  MAX_SOUND_BYTES, MAX_SOUND_SECONDS, bytesToBase64, checkDuration, removeCustomSound, saveCustomSound, supportedFormats, validStoredSound, validateSoundFile,
} from '../../../core/customSound.js';
import { toFa } from '../../../core/format.js';
import { useStoredValue } from '../../../hooks/useStoredValue.js';

const kb = (b) => `${toFa(Math.max(1, Math.round(b / 1024)))} کیلوبایت`;
const secs = (s) => `${toFa(Math.round(s * 10) / 10)} ثانیه`.replace('.', '٫');

/** رمزگشایی واقعی برای اطمینان از قابل‌پخش بودن و گرفتن مدت دقیق (به‌جای اعتماد به metadata). */
async function decodeDuration(bytes) {
  const AC = globalThis.AudioContext || globalThis.webkitAudioContext;
  if (!AC) throw new Error('no-audio');
  const ctx = new AC();
  try {
    const buf = await ctx.decodeAudioData(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
    return buf.duration;
  } finally {
    ctx.close().catch(() => {});
  }
}

export default function SoundSettings({ s, patch, Row, Switch }) {
  const [stored] = useStoredValue(KEYS.customSound, null);
  const custom = validStoredSound(stored);
  const formats = useMemo(() => supportedFormats(), []);
  const fileRef = useRef(null);
  const timer = useRef(0);
  const [pending, setPending] = useState(null); // { name, mime, bytes, duration, label }
  const [msg, setMsg] = useState(null); // { kind: 'err' | 'ok', text }
  const [busy, setBusy] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);

  // انتخاب «صدای من» وقتی فایلی نیست، به‌صورت دینگ نمایش و پخش می‌شود
  const raw = soundIdOf(s.soundId);
  const soundId = raw === CUSTOM_SOUND_ID && !custom ? 'ding' : raw;

  const play = (id) => (id === CUSTOM_SOUND_ID ? playCustom(custom) : playSound(id));
  const previewSoon = (id) => { clearTimeout(timer.current); timer.current = setTimeout(() => play(id), 160); };

  const options = [
    ...SOUNDS.map((x) => ({ value: x.id, label: x.label, group: 'صداهای داخلی' })),
    ...(custom ? [{ value: CUSTOM_SOUND_ID, label: `صدای من: ${custom.name}`, group: 'صدای شما' }] : []),
  ];

  const pick = async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    setMsg(null); setPending(null); setBusy(true);
    try {
      if (file.size > MAX_SOUND_BYTES) { setMsg({ kind: 'err', text: validateSoundFile({ size: file.size, name: file.name }, new Uint8Array(12)).error }); return; }
      const bytes = new Uint8Array(await file.arrayBuffer());
      const v = validateSoundFile({ size: file.size, name: file.name }, bytes, formats);
      if (!v.ok) { setMsg({ kind: 'err', text: v.error }); return; }
      let duration;
      try {
        duration = await decodeDuration(bytes);
      } catch {
        setMsg({ kind: 'err', text: 'این فایل در مرورگر پخش نمی‌شود یا خراب است. فایل دیگری انتخاب کنید.' });
        return;
      }
      const d = checkDuration(duration);
      if (!d.ok) { setMsg({ kind: 'err', text: d.error }); return; }
      setPending({ name: v.name, mime: v.format.mime, bytes, duration, label: v.format.label });
    } finally {
      setBusy(false);
    }
  };

  const previewPending = async () => {
    const ok = await playCustom({ name: pending.name, mime: pending.mime, data: bytesToBase64(pending.bytes), duration: pending.duration });
    if (!ok) setMsg({ kind: 'err', text: 'پخش فایل ممکن نشد. فایل دیگری انتخاب کنید.' });
  };

  const commit = async () => {
    setBusy(true);
    const r = await saveCustomSound({ name: pending.name, mime: pending.mime, bytes: pending.bytes, duration: pending.duration });
    setBusy(false);
    if (!r.ok) { setMsg({ kind: 'err', text: r.error }); return; }
    patch({ soundId: CUSTOM_SOUND_ID });
    setPending(null);
    setMsg({ kind: 'ok', text: 'صدای شما ذخیره و انتخاب شد.' });
  };

  const del = async () => {
    await removeCustomSound();
    if (s.soundId === CUSTOM_SOUND_ID) patch({ soundId: 'ding' });
    setConfirmDel(false);
    setMsg({ kind: 'ok', text: 'صدای شما حذف شد و صدای «دینگ» انتخاب شد.' });
  };

  return (
    <>
      <Row title="صدای پایان زمان کار" hint="فقط هنگام اتمام موفق زمان کار پخش می‌شود، نه هنگام توقف یا انصراف.">
        <Switch checked={s.soundEnabled} onChange={(v) => patch({ soundEnabled: v })} label="صدای پایان زمان کار" />
      </Row>
      <Row title="صدای هشدار" hint="با کلیدهای جهت‌دار روی گزینه‌ها بروید تا صدا پخش شود؛ با Enter انتخاب می‌شود.">
        <div className="sound-pick">
          <Dropdown
            label="صدای هشدار"
            value={soundId}
            options={options}
            disabled={!s.soundEnabled}
            onChange={(v) => patch({ soundId: v })}
            onHighlight={previewSoon}
            renderOption={(o) => (
              <>
                <span className="dd-opt-main">{o.label}</span>
                <span
                  className="dd-play"
                  role="presentation"
                  title="پیش‌نمایش"
                  onMouseDown={(e) => { e.preventDefault(); e.stopPropagation(); play(o.value); }}
                ><Icon name="play" size={12} /></span>
              </>
            )}
          />
          <button className="btn" disabled={!s.soundEnabled} onClick={() => play(soundId)}>پیش‌نمایش</button>
        </div>
      </Row>

      <Row
        title="صدای دلخواه شما"
        hint={`قالب‌های قابل‌استفاده در این مرورگر: ${formats.map((f) => f.label).join('، ')}. حداکثر ${kb(MAX_SOUND_BYTES)} و ${toFa(MAX_SOUND_SECONDS)} ثانیه.`}
      >
        <input ref={fileRef} type="file" hidden accept={formats.map((f) => f.probe).join(',') + ',.mp3,.wav,.ogg,.m4a,.webm'} onChange={pick} />
        <div className="confirm">
          <button className="btn" disabled={busy} onClick={() => fileRef.current && fileRef.current.click()}>
            <Icon name="download" size={17} /> {custom ? 'جایگزینی' : 'انتخاب فایل'}
          </button>
          {custom && !confirmDel && <button className="btn danger" onClick={() => setConfirmDel(true)}>حذف</button>}
        </div>
      </Row>

      {custom && !pending && (
        <p className="note" role="status">فایل فعلی: {custom.name} ({secs(custom.duration)}، {kb(custom.size)})</p>
      )}
      {confirmDel && (
        <div className="panel" role="alert">
          <p className="note">صدای شما حذف شود؟ می‌توانید دوباره به صدای داخلی برگردید.</p>
          <div className="confirm">
            <button className="btn danger" onClick={del}>بله، حذف شود</button>
            <button className="btn" onClick={() => setConfirmDel(false)}>انصراف</button>
          </div>
        </div>
      )}
      {pending && (
        <div className="panel" role="group" aria-label="پیش‌نمایش فایل انتخاب‌شده">
          <p className="note">{pending.name} · {pending.label} · {secs(pending.duration)} · {kb(pending.bytes.length)}</p>
          <div className="confirm">
            <button className="btn" onClick={previewPending}><Icon name="play" size={14} /> پخش</button>
            <button className="btn solid" disabled={busy} onClick={commit}>ذخیره و استفاده</button>
            <button className="btn" onClick={() => setPending(null)}>انصراف</button>
          </div>
        </div>
      )}
      {msg && <p className={msg.kind === 'err' ? 'err' : 'okmsg'} role={msg.kind === 'err' ? 'alert' : 'status'}>{msg.text}</p>}
    </>
  );
}
