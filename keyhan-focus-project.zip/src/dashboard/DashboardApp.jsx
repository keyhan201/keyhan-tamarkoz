import { useEffect, useState } from 'react';
import Icon from '../shared/Icon.jsx';
import Mark from '../shared/Mark.jsx';
import { useSettings } from '../hooks/useStoredValue.js';
import StatsView from './components/StatsView.jsx';
import TasksView from './components/TasksView.jsx';
import SettingsView from './components/SettingsView.jsx';

const TABS = [
  { id: 'stats', label: 'آمار تمرکز', icon: 'stats', View: StatsView },
  { id: 'tasks', label: 'کارهای روزانه', icon: 'list', View: TasksView },
  { id: 'settings', label: 'تنظیمات', icon: 'sliders', View: SettingsView },
];

const readHash = () => window.location.hash.slice(1);

export default function DashboardApp() {
  const [hash, setTab] = useState(readHash);
  const [settings] = useSettings();
  // بخش کارها اختیاری است: فقط پنهان می‌شود، داده‌ها دست‌نخورده می‌مانند
  const tabs = TABS.filter((t) => t.id !== 'tasks' || settings.tasksEnabled);
  const tab = tabs.some((t) => t.id === hash) ? hash : 'stats';

  useEffect(() => {
    const on = () => setTab(readHash());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);

  const { View } = tabs.find((t) => t.id === tab);

  return (
    <div className="shell">
      <aside className="side">
        <div className="side-brand">
          <Mark size={26} />
          <span>کیهان تمرکز</span>
        </div>
        <nav aria-label="بخش‌ها">
          {tabs.map((t) => (
            <a key={t.id} href={`#${t.id}`} className="nav" aria-current={t.id === tab ? 'page' : undefined}>
              <Icon name={t.icon} size={18} />
              {t.label}
            </a>
          ))}
        </nav>
        <p className="side-note">داده‌ها فقط روی همین مرورگر ذخیره می‌شوند.</p>
      </aside>
      <main className="content">
        <View />
      </main>
    </div>
  );
}
