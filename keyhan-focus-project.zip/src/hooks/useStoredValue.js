import { useCallback, useEffect, useRef, useState } from 'react';
import { getItem, setItem, subscribe } from '../core/storage.js';
import { DEFAULT_SETTINGS, KEYS } from '../core/constants.js';

/** مقدار ذخیره‌شده را می‌خواند و با تغییر در هر صفحه‌ی دیگر هم‌گام می‌شود. */
export function useStoredValue(key, fallback) {
  const [value, setValue] = useState(fallback);
  const [ready, setReady] = useState(false);
  const ref = useRef(fallback);

  useEffect(() => {
    let alive = true;
    getItem(key, fallback).then((v) => {
      if (!alive) return;
      ref.current = v;
      setValue(v);
      setReady(true);
    });
    const off = subscribe(key, (v) => {
      ref.current = v === undefined ? fallback : v;
      setValue(ref.current);
    });
    return () => {
      alive = false;
      off();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const update = useCallback(
    (next) => {
      const v = typeof next === 'function' ? next(ref.current) : next;
      ref.current = v;
      setValue(v);
      return setItem(key, v);
    },
    [key],
  );

  return [value, update, ready];
}

const NO_SETTINGS = {};
export function useSettings() {
  const [stored, update, ready] = useStoredValue(KEYS.settings, NO_SETTINGS);
  const patch = useCallback((p) => update((s) => ({ ...s, ...p })), [update]);
  return [{ ...DEFAULT_SETTINGS, ...stored }, patch, ready];
}
