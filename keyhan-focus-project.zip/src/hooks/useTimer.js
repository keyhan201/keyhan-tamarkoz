import { useEffect, useMemo, useRef, useState } from 'react';
import { IDLE_TIMER, KEYS } from '../core/constants.js';
import { canInterrupt, completeTimer, normalizeTimer, remainingMsOf } from '../core/timerService.js';
import { useStoredValue } from './useStoredValue.js';

/**
 * منبع زمان همیشه Date.now() و timestamp های ذخیره‌شده است.
 * setInterval/setTimeout فقط کامپوننت را دوباره رندر می‌کنند.
 */
export function useTimer() {
  const [raw, , ready] = useStoredValue(KEYS.timer, IDLE_TIMER);
  const timer = useMemo(() => normalizeTimer(raw), [raw]);
  const [, setTick] = useState(0);
  const finishing = useRef(null);
  const now = Date.now();

  useEffect(() => {
    if (timer.status !== 'running') return undefined;
    const bump = () => setTick((n) => n + 1);
    const id = setInterval(bump, 250);
    // رندر دقیقاً در لحظه‌ی پایان ۱۰ ثانیه و پایان تایمر
    const timeouts = [timer.gracePeriodEndsAt, timer.endsAt]
      .map((at) => at - Date.now())
      .filter((ms) => ms > 0)
      .map((ms) => setTimeout(bump, ms + 2));
    return () => {
      clearInterval(id);
      timeouts.forEach(clearTimeout);
    };
  }, [timer.status, timer.endsAt, timer.gracePeriodEndsAt]);

  // اگر زمان تمام شده و پس‌زمینه هنوز ثبتش نکرده، از اینجا ثبت می‌شود (idempotent)
  useEffect(() => {
    if (timer.status === 'running' && now >= timer.endsAt && finishing.current !== timer.sessionId) {
      finishing.current = timer.sessionId;
      completeTimer();
    }
  });

  const remainingMs = remainingMsOf(timer, now);
  const total = timer.durationSeconds * 1000;
  const progress = timer.status === 'idle' || !total ? 0 : Math.min(1, Math.max(0, 1 - remainingMs / total));

  return { timer, ready, remainingMs, progress, now, interruptible: canInterrupt(timer, now) };
}
