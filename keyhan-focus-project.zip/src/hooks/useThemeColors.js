import { useEffect, useMemo, useState } from 'react';

const read = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();

/** رنگ‌های تم فعلی از متغیرهای CSS؛ با تغییر تم دوباره خوانده می‌شود. */
export function useThemeColors() {
  const [stamp, setStamp] = useState(0);
  useEffect(() => {
    const mo = new MutationObserver(() => setStamp((n) => n + 1));
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme', 'style'] });
    return () => mo.disconnect();
  }, []);

  return useMemo(() => ({
    accent: read('--star'),
    accentDim: read('--star-dim'),
    mute: read('--mute'),
    line: read('--line'),
  }), [stamp]);
}
