import { useEffect, useState } from 'react';
import { KEYS } from '../core/constants.js';
import { pickQuote, pushRecent } from '../core/quotes.js';
import { getItem, setItem } from '../core/storage.js';

/** یک جمله برای هر «تغییر دسته/جلسه» انتخاب می‌شود و ردیف اخیرها در storage می‌ماند. */
export function useQuote(enabled, category, trigger, quotes) {
  const [quote, setQuote] = useState(null);
  useEffect(() => {
    if (!enabled) { setQuote(null); return undefined; }
    let alive = true;
    (async () => {
      try {
        const recent = await getItem(KEYS.recentQuotes, {});
        const safe = recent && typeof recent === 'object' && !Array.isArray(recent) ? recent : {};
        const list = Array.isArray(safe[category]) ? safe[category] : [];
        const q = quotes ? pickQuote(category, list, Math.random, quotes) : pickQuote(category, list);
        if (!alive || !q) return;
        setQuote(q);
        await setItem(KEYS.recentQuotes, { ...safe, [category]: pushRecent(list, q.id) });
      } catch {
        /* جمله‌ی انگیزشی هرگز نباید پاپ‌آپ را خراب کند */
      }
    })();
    return () => { alive = false; };
  }, [enabled, category, trigger, quotes]);
  return quote;
}
