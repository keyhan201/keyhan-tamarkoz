import { useEffect, useRef, useState } from 'react';
import { App as CapApp } from '@capacitor/app';
import { MAX_MINUTES, MIN_MINUTES, PRESETS } from '../core/constants.js';
import { toFa } from '../core/format.js';
import { addCustomMinute, normalizeCustomMinutes, parseMinutes, removeCustomMinute } from '../core/durations.js';
import { cancelTimer, pauseTimer, resumeTimer, startBreak, startTimer } from '../core/timerService.js';
import { categoryFor } from '../core/quotes.js';
import { MOBILE_QUOTES } from '../data/quotesMobile.js';
import { useSettings } from '../hooks/useStoredValue.js';
import { useTimer } from '../hooks/useTimer.js';
import { useQuote } from '../hooks/useQuote.js';
import OrbitTimer from '../popup/components/OrbitTimer.jsx';
import StatsView from '../dashboard/components/StatsView.jsx';
import SettingsRouter from './SettingsPages.jsx';
import { getPermissions, openSetting } from './native.js';

const TABS = [
  { id: 'focus', label: 'تمرکز' },
  { id: 'stats', label: 'آمار' },
  { id: 'settings', label: 'تنظیمات' },
];

/* ---------------- تمرکز ---------------- */
function DurationSheet({ minutes, saved, onChange, onSaveList, onClose }) {
  const [custom, setCustom] = useState('');
  const [error, setError] = useState('');
  const list = normalizeCustomMinutes(saved);
  const typedBad = custom.trim() !== '' && parseMinutes(custom) === null;
  const pick = (m) => { setCustom(''); setError(''); onChange(m); };
  const add = () => {
    const r = addCustomMinute(list, custom);
    if (!r.ok) { if (r.duplicate) pick(r.duplicate); else setError(r.error); return; }
    onSaveList(r.list); pick(r.minutes);
  };
  return (
    <>
      <div className="m-scrim" onClick={onClose} />
      <section className="m-sheet" role="dialog" aria-modal="true" aria-label="مدت تمرکز">
        <h2>مدت تمرکز</h2>
        <div className="m-presets" role="group" aria-label="زمان‌های آماده">
          {PRESETS.map((m) => (
            <button key={m} className={'m-preset' + (custom === '' && m === minutes ? ' on' : '')} onClick={() => { pick(m); onClose(); }}>{toFa(m)} دقیقه</button>
          ))}
          {list.map((m) => (
            <span key={m} className={'m-preset saved' + (custom === '' && m === minutes ? ' on' : '')}>
              <button onClick={() => { pick(m); onClose(); }}>{toFa(m)} دقیقه</button>
              <button className="m-x" aria-label={`حذف زمان ${toFa(m)} دقیقه`} onClick={() => { onSaveList(removeCustomMinute(list, m)); }}>حذف</button>
            </span>
          ))}
        </div>
        <label htmlFor="m-custom">افزودن زمان دلخواه (دقیقه)</label>
        <div className={'m-field' + (typedBad || error ? ' bad' : '')}>
          <input id="m-custom" inputMode="numeric" autoComplete="off" maxLength={4} value={custom}
            onChange={(e) => { setCustom(e.target.value); setError(''); const n = parseMinutes(e.target.value); if (n) onChange(n); }}
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } }} />
          <button className="btn small" disabled={custom.trim() === '' || typedBad} onClick={add}>ذخیره</button>
        </div>
        <p className="m-hint" role={typedBad || error ? 'alert' : undefined}>
          {typedBad ? `عددی صحیح بین ${toFa(MIN_MINUTES)} تا ${toFa(MAX_MINUTES)} وارد کنید.` : error || '\u00a0'}
        </p>
        <button className="btn solid wide" onClick={onClose}>تأیید</button>
      </section>
    </>
  );
}

function FocusScreen() {
  const { timer, ready, remainingMs, progress, now, interruptible } = useTimer();
  const [settings, patch] = useSettings();
  const [sheet, setSheet] = useState(false);
  const [perm, setPerm] = useState(null);
  useEffect(() => { getPermissions().then(setPerm); const h = CapApp.addListener('resume', () => getPermissions().then(setPerm)); return () => { h.then((x) => x.remove()); }; }, []);
  const category = ready ? categoryFor(timer, now) : 'start';
  const quote = useQuote(ready && settings.showQuotes, category, timer.sessionId || (timer.lastResult && timer.lastResult.sessionId) || '', MOBILE_QUOTES);
  if (!ready) return <div className="m-screen" />;

  const minutes = Number.isFinite(settings.defaultMinutes) ? settings.defaultMinutes : 25;
  const breakMin = Number.isInteger(settings.breakMinutes) ? settings.breakMinutes : 5;
  const extendMin = Number.isInteger(settings.extendMinutes) ? settings.extendMinutes : 5;
  const idle = timer.status === 'idle';
  const isBreak = timer.kind === 'break';
  const running = timer.status === 'running';
  const last = timer.lastResult && now - timer.lastResult.at < 60 * 60 * 1000 ? timer.lastResult : null;
  const shownMs = idle ? minutes * 60000 : remainingMs;

  let status = 'آماده‌ی تمرکز';
  if (!idle && isBreak) status = 'در حال استراحت';
  else if (running) status = 'در حال تمرکز';
  else if (timer.status === 'paused') status = 'متوقف شد';
  else if (last && last.kind === 'break') status = 'استراحت تمام شد';
  else if (last) status = `تمرکز تمام شد؛ ${toFa(last.minutes)} دقیقه ثبت شد`;

  const begin = () => startTimer(minutes);
  return (
    <div className="m-screen m-focus">
      <p className="m-status" aria-live="polite">{status}</p>
      <OrbitTimer remainingMs={shownMs} progress={progress} active={running} />

      {idle && (
        <button className="m-chip" onClick={() => setSheet(true)} aria-label="تغییر مدت تمرکز">{toFa(minutes)} دقیقه</button>
      )}

      <div className="m-controls">
        {idle && last && last.kind !== 'break' && (
          <button className="btn wide" onClick={() => startBreak(breakMin)}>استراحت {toFa(breakMin)} دقیقه‌ای</button>
        )}
        {idle && last && last.kind !== 'break' && (
          <button className="btn wide" onClick={() => startTimer(extendMin)}>تمدید {toFa(extendMin)} دقیقه‌ای</button>
        )}
        {idle && <button className="btn solid wide big" onClick={begin}>{last ? 'شروع جلسه‌ی جدید' : 'شروع تمرکز'}</button>}
        {!idle && isBreak && (
          <>
            <button className="btn solid wide" onClick={() => cancelTimer().then(() => startTimer(minutes))}>شروع جلسه‌ی جدید</button>
            <button className="btn wide" onClick={() => cancelTimer()}>رد کردن استراحت</button>
          </>
        )}
        {!idle && !isBreak && interruptible && (
          <>
            <button className="btn solid wide big" onClick={() => (running ? pauseTimer() : resumeTimer())}>{running ? 'توقف موقت' : 'ادامه'}</button>
            <button className="btn wide" onClick={() => cancelTimer()}>انصراف از جلسه</button>
          </>
        )}
        {!idle && !isBreak && !interruptible && <p className="m-hint">بعد از ۱۰ ثانیه‌ی اول، جلسه تا پایان ادامه پیدا می‌کند.</p>}
        {!idle && !isBreak && settings.blockMode && (
          <button className="btn wide danger" onClick={() => patch({ blockMode: false })}>خاموش کردن حالت محدودسازی</button>
        )}
      </div>

      {perm && !perm.notifications && settings.notifications && (
        <div className="m-hint" role="status">
          برای اعلام پایان جلسه به اجازه‌ی اعلان نیاز داریم.{' '}
          <button className="btn small" onClick={() => openSetting('requestNotifications')}>اجازه دادن</button>
        </div>
      )}

      {settings.showQuotes && <p className="m-quote" aria-live="polite">{quote ? quote.text : '\u00a0'}</p>}

      {sheet && (
        <DurationSheet minutes={minutes} saved={settings.customMinutes} onChange={(m) => patch({ defaultMinutes: m })}
          onSaveList={(l) => patch(normalizeCustomMinutes(settings.customMinutes).includes(minutes) && !l.includes(minutes) ? { customMinutes: l, defaultMinutes: DEFAULT_SETTINGS.defaultMinutes } : { customMinutes: l })}
          onClose={() => setSheet(false)} />
      )}
    </div>
  );
}

/* ---------------- پوسته ---------------- */
export default function MobileApp() {
  const [tab, setTab] = useState('focus');
  const [path, setPath] = useState([]); // مسیر داخل تنظیمات، مثلاً ['alerts', 'sound']
  const stateRef = useRef({ tab, path });
  stateRef.current = { tab, path };

  useEffect(() => {
    const h = CapApp.addListener('backButton', () => {
      const { tab: t, path: p } = stateRef.current;
      if (t === 'settings' && p.length) setPath(p.slice(0, -1));
      else if (t !== 'focus') setTab('focus');
      else CapApp.minimizeApp();
    });
    return () => { h.then((x) => x.remove()); };
  }, []);

  const body = tab === 'focus' ? <FocusScreen />
    : tab === 'stats' ? <div className="m-screen"><StatsView /></div>
    : <SettingsRouter path={path} setPath={setPath} />;

  return (
    <div className="m-app">
      <main className="m-main">{body}</main>
      <nav className="m-nav" aria-label="بخش‌ها">
        {TABS.map((t) => (
          <button key={t.id} aria-current={t.id === tab ? 'page' : undefined} onClick={() => { if (t.id === 'settings') setPath([]); setTab(t.id); }}>{t.label}</button>
        ))}
      </nav>
    </div>
  );
}
