import '@fontsource-variable/vazirmatn';
import '../styles/base.css';
import '../styles/themes.css';
import '../dashboard/dashboard.css';
import './app.css';
import { createRoot } from 'react-dom/client';
import { App as CapApp } from '@capacitor/app';
import { useBackend, refreshKeys, subscribe } from '../core/storage.js';
import { initTheme } from '../core/themes.js';
import { KEYS, IDLE_TIMER, DEFAULT_SETTINGS } from '../core/constants.js';
import { getCustomSound } from '../core/customSound.js';
import { backend } from './backend.js';
import { MOBILE_END_QUOTES } from '../data/quotesMobile.js';
import { isNative, onNativeChange, removeNativeSound, saveNativeSound, setEndQuotes, syncNative } from './native.js';
import MobileApp from './MobileApp.jsx';

useBackend(backend);
const refresh = () => refreshKeys([KEYS.timer, KEYS.sessions, KEYS.settings], { timer: IDLE_TIMER, sessions: [], settings: DEFAULT_SETTINGS });

async function boot() {
  await initTheme();
  if (isNative()) {
    setEndQuotes(MOBILE_END_QUOTES.map((q) => q.text));
    const pushSound = async (v) => {
      const s = v ?? (await getCustomSound());
      if (s && s.data) saveNativeSound(s.data, s.mime); else removeNativeSound();
    };
    pushSound();
    subscribe(KEYS.customSound, (v) => pushSound(v));
    onNativeChange(refresh);
    CapApp.addListener('resume', () => { refresh(); syncNative(); });
    syncNative();
  }
  createRoot(document.getElementById('root')).render(<MobileApp />);
}
boot();
