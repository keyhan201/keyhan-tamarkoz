// پل JS ↔ Android. خارج از اندروید (مرورگر/تست) همه‌چیز بی‌خطا و بدون اثر است.
import { Capacitor, registerPlugin } from '@capacitor/core';

export const isNative = () => {
  try { return Capacitor.isNativePlatform(); } catch { return false; }
};
const Plugin = registerPlugin('KeyhanNative');
const call = async (name, args, fallback) => {
  if (!isNative()) return fallback;
  try { return await Plugin[name](args || {}); } catch { return fallback; }
};

export const syncNative = () => call('sync', {}, null);
export const setEndQuotes = (quotes) => call('setEndQuotes', { quotes }, null);
export const saveNativeSound = (base64, mime) => call('saveCustomSound', { base64, mime }, null);
export const removeNativeSound = () => call('removeCustomSound', {}, null);
export const listApps = async () => (await call('listLaunchableApps', {}, { apps: [] })).apps || [];
export const getPermissions = () => call('getPermissions', {}, { notifications: true, exactAlarm: true, usageAccess: false, overlay: false, battery: true });
export const openSetting = (name) => call(name, {}, null); // requestNotifications | openUsageAccess | openOverlay | openExactAlarm | openBattery
export const onNativeChange = (cb) => {
  if (!isNative()) return () => {};
  let handle = null;
  Plugin.addListener('stateChanged', cb).then((h) => { handle = h; });
  return () => handle && handle.remove();
};
