// ذخیره‌سازی اندروید: Capacitor Preferences (SharedPreferences) تا بخش native هم همان تایمر/جلسه‌ها را بخواند و بنویسد.
// فقط صدای دلخواه (حجیم) در localStorage وب‌ویو می‌ماند؛ نسخه‌ی قابل‌پخش در پس‌زمینه را main.jsx به native می‌فرستد.
import { Preferences } from '@capacitor/preferences';
import { syncNative } from './native.js';

const LOCAL = new Set(['customSound']);
const SYNC_KEYS = new Set(['timer', 'settings']);

export const backend = {
  async get(key) {
    try {
      const raw = LOCAL.has(key) ? localStorage.getItem('kt:' + key) : (await Preferences.get({ key })).value;
      return raw === null || raw === undefined ? undefined : JSON.parse(raw);
    } catch { return undefined; }
  },
  async set(key, value) {
    const raw = JSON.stringify(value);
    if (LOCAL.has(key)) localStorage.setItem('kt:' + key, raw);
    else await Preferences.set({ key, value: raw });
    if (SYNC_KEYS.has(key)) syncNative();
  },
  async remove(key) {
    if (LOCAL.has(key)) localStorage.removeItem('kt:' + key);
    else await Preferences.remove({ key });
    if (SYNC_KEYS.has(key)) syncNative();
  },
};
