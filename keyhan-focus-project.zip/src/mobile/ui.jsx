import { useCallback, useEffect, useState } from 'react';
import { App as CapApp } from '@capacitor/app';
import { getPermissions } from './native.js';

export function Switch({ checked, onChange, label }) {
  return (
    <button role="switch" aria-checked={!!checked} aria-label={label} className="switch" onClick={() => onChange(!checked)}>
      <span />
    </button>
  );
}

export function Row({ title, hint, children }) {
  return (
    <div className="row">
      <div>
        <div className="row-title">{title}</div>
        {hint && <div className="row-hint">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

/** وضعیت مجوزها؛ با بازگشت از تنظیمات اندروید (resume) و در بازه‌های کوتاه (poll) دوباره خوانده می‌شود. */
export function usePerms(pollMs = 0) {
  const [perm, setPerm] = useState(null);
  const reload = useCallback(() => getPermissions().then(setPerm), []);
  useEffect(() => {
    reload();
    const h = CapApp.addListener('resume', reload);
    const timer = pollMs ? setInterval(reload, pollMs) : null;
    return () => { h.then((x) => x.remove()); if (timer) clearInterval(timer); };
  }, [reload, pollMs]);
  return [perm, reload];
}

export const PERMS = [
  { id: 'notifications', title: 'اعلان‌ها', action: 'requestNotifications', essential: true,
    why: 'برای اعلام پایان جلسه و دکمه‌های «استراحت»، «تمدید جلسه» و «بستن».',
    guide: 'اندروید یک پنجره‌ی اجازه نشان می‌دهد؛ «اجازه دادن» را بزن. اگر قبلاً رد کرده‌ای، صفحه‌ی اعلان‌های برنامه باز می‌شود.' },
  { id: 'exactAlarm', title: 'زنگ دقیق', action: 'openExactAlarm', essential: true,
    why: 'تا پایان جلسه سر وقت اعلام شود، حتی وقتی برنامه بسته است.',
    guide: 'در صفحه‌ی بعد گزینه‌ی «اجازه‌ی زنگ‌ها و یادآورها» را برای این برنامه روشن کن و برگرد.' },
  { id: 'battery', title: 'بهینه‌سازی باتری', action: 'openBattery', essential: false,
    why: 'در بعضی گوشی‌ها سیستم تایمر را در پس‌زمینه می‌بندد؛ استثنا قرار دادن کمک می‌کند.',
    guide: 'در فهرست باز‌شده برنامه‌ی «Keyhan focus» را پیدا کن و روی «بهینه‌سازی نکن» بگذار، بعد برگرد.' },
  { id: 'usageAccess', title: 'آمار استفاده از برنامه‌ها', action: 'openUsageAccess', essential: false,
    why: 'فقط برای تشخیص برنامه‌ی جلوی صفحه هنگام تمرکز (محدودسازی). چیزی ذخیره یا ارسال نمی‌شود.',
    guide: 'در فهرست «Keyhan focus» را پیدا کن، «اجازه‌ی دسترسی» را روشن کن و برگرد.' },
  { id: 'overlay', title: 'نمایش روی برنامه‌های دیگر', action: 'openOverlay', essential: false,
    why: 'برای پنجره‌ی پایان جلسه روی برنامه‌ها و برگرداندن به اپ در حالت محدودسازی.',
    guide: 'کلید «اجازه‌ی نمایش روی برنامه‌های دیگر» را روشن کن و برگرد.' },
];
export const permOk = (perm, id) => !!(perm && perm[id]);
