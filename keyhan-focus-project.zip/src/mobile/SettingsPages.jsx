import { useEffect, useRef, useState } from 'react';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { KEYS, MAX_BREAK_MINUTES, MAX_MINUTES, MIN_BREAK_MINUTES, MIN_MINUTES } from '../core/constants.js';
import { fromFa, toFa } from '../core/format.js';
import { MAX_BACKUP_BYTES, parseBackup, restoreBackup } from '../core/backup.js';
import { dailySummaryJson, sessionsToCsv } from '../core/exportStats.js';
import { MAX_LIMITED_APPS, normalizePackages, togglePackage } from '../core/appLimits.js';
import { THEMES } from '../core/themes.js';
import { getItem, setItem } from '../core/storage.js';
import { useSettings } from '../hooks/useStoredValue.js';
import ThemeSettings from '../dashboard/components/settings/ThemeSettings.jsx';
import SoundSettings from '../dashboard/components/settings/SoundSettings.jsx';
import { downloadText } from '../shared/download.js';
import { isNative, listApps, openSetting } from './native.js';
import { PERMS, Row, Switch, permOk, usePerms } from './ui.jsx';

export const TITLES = {
  appearance: 'ظاهر و تم',
  'appearance/themes': 'تم‌های آماده',
  'appearance/custom': 'ساخت و مدیریت تم شخصی',
  session: 'جلسه و زمان‌ها',
  alerts: 'صدا و اعلان‌ها',
  'alerts/sound': 'صدای هشدار',
  'alerts/notifications': 'اعلان‌ها و پنجره‌ی پایان جلسه',
  files: 'فایل‌ها و پشتیبان‌گیری',
  access: 'دسترسی‌ها و محدودسازی برنامه‌ها',
  'access/status': 'وضعیت دسترسی‌ها',
  'access/limits': 'محدودسازی برنامه‌ها',
};

/* ---------- ابزارهای مشترک ---------- */
function Link({ title, status, onClick }) {
  return (
    <button className="m-link" onClick={onClick}>
      <span className="m-link-title">{title}</span>
      {status && <span className="m-link-status">{status}</span>}
    </button>
  );
}

function useMinuteField(s, patch, key, min, max) {
  const [text, setText] = useState('');
  useEffect(() => setText(toFa(s[key])), [s[key]]);
  const commit = () => {
    const n = parseInt(fromFa(text), 10);
    if (Number.isInteger(n) && n >= min && n <= max) patch({ [key]: n });
    else setText(toFa(s[key]));
  };
  return [text, setText, commit];
}

function MinuteRow({ s, patch, k, min, max, title, hint, label }) {
  const [text, setText, commit] = useMinuteField(s, patch, k, min, max);
  return (
    <Row title={title} hint={hint}>
      <div className="mini-field">
        <input inputMode="numeric" value={text} aria-label={label} onChange={(e) => setText(e.target.value)}
          onBlur={commit} onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()} />
        <span>دقیقه</span>
      </div>
    </Row>
  );
}

async function shareFile(name, text, mime) {
  if (!isNative()) { downloadText(name, text, mime); return; }
  const { uri } = await Filesystem.writeFile({ path: name, data: text, directory: Directory.Cache, encoding: Encoding.UTF8 });
  await Share.share({ title: name, url: uri, dialogTitle: 'ذخیره یا ارسال فایل' });
}

/* ---------- ظاهر ---------- */
function AppearanceMenu({ s, go }) {
  const customs = Array.isArray(s.customThemes) ? s.customThemes : [];
  const cur = THEMES.find((t) => t.id === s.theme) || customs.find((c) => c.id === s.theme);
  return (
    <div className="rows">
      <Link title="تم‌های آماده" status={cur ? `انتخاب‌شده: ${cur.label || cur.name}` : undefined} onClick={() => go('themes')} />
      <Link title="ساخت و مدیریت تم شخصی" status={customs.length ? `${toFa(customs.length)} تم شخصی` : 'هنوز تمی نساخته‌ای'} onClick={() => go('custom')} />
    </div>
  );
}

/* ---------- جلسه و زمان‌ها ---------- */
function SessionPage({ s, patch }) {
  return (
    <div className="rows">
      <MinuteRow s={s} patch={patch} k="defaultMinutes" min={MIN_MINUTES} max={MAX_MINUTES} title="مدت پیش‌فرض تمرکز" hint={`${toFa(MIN_MINUTES)} تا ${toFa(MAX_MINUTES)} دقیقه`} label="مدت پیش‌فرض به دقیقه" />
      <MinuteRow s={s} patch={patch} k="breakMinutes" min={MIN_BREAK_MINUTES} max={MAX_BREAK_MINUTES} title="مدت استراحت" hint={`${toFa(MIN_BREAK_MINUTES)} تا ${toFa(MAX_BREAK_MINUTES)} دقیقه؛ پیش‌فرض ${toFa(5)}`} label="مدت استراحت به دقیقه" />
      <MinuteRow s={s} patch={patch} k="extendMinutes" min={MIN_BREAK_MINUTES} max={MAX_BREAK_MINUTES} title="مدت تمدید جلسه" hint={`با دکمه‌ی «تمدید جلسه»؛ ${toFa(MIN_BREAK_MINUTES)} تا ${toFa(MAX_BREAK_MINUTES)} دقیقه`} label="مدت تمدید جلسه به دقیقه" />
      <Row title="جمله‌های انگیزشی" hint="زیر تایمر و در اعلان پایان جلسه نشان داده می‌شوند.">
        <Switch checked={s.showQuotes} onChange={(v) => patch({ showQuotes: v })} label="نمایش جمله‌های انگیزشی" />
      </Row>
    </div>
  );
}

/* ---------- صدا و اعلان‌ها ---------- */
function AlertsMenu({ s, perm, go }) {
  return (
    <div className="rows">
      <Link title="صدای هشدار" status={s.soundEnabled ? 'روشن' : 'خاموش'} onClick={() => go('sound')} />
      <Link title="اعلان‌ها و پنجره‌ی پایان جلسه" status={`اعلان ${s.notifications ? 'روشن' : 'خاموش'} · پنجره ${s.endOverlay && permOk(perm, 'overlay') ? 'روشن' : 'خاموش'}`} onClick={() => go('notifications')} />
    </div>
  );
}

function NotificationsPage({ s, patch, perm }) {
  return (
    <div className="rows">
      <Row title="اعلان پایان جلسه و استراحت" hint="با دکمه‌های «استراحت»، «تمدید جلسه» و «بستن».">
        <Switch checked={s.notifications} onChange={(v) => patch({ notifications: v })} label="اعلان پایان جلسه" />
      </Row>
      {perm && !perm.notifications && (
        <Row title="مجوز اعلان خاموش است" hint="بدون آن اعلان‌ها نمایش داده نمی‌شوند.">
          <button className="btn" onClick={() => openSetting('requestNotifications')}>اجازه دادن</button>
        </Row>
      )}
      {perm && perm.notifications && perm.headsUp === false && (
        <Row title="اعلان شناور خاموش است" hint="اهمیت کانال «پایان جلسه» روی «بالا» نیست؛ برای دیدن اعلان در بالای صفحه آن را روی «نمایش شناور» بگذار.">
          <button className="btn" onClick={() => openSetting('openChannelSettings')}>باز کردن تنظیمات</button>
        </Row>
      )}
      <Row title="پنجره‌ی پایان جلسه روی برنامه‌ها" hint="اختیاری و جدا از اعلان شناور: یک کارت کوچک در میانه‌ی صفحه با دکمه‌های استراحت، تمدید و بستن. اگر مجوز «نمایش روی برنامه‌های دیگر» نباشد، فقط اعلان سیستمی می‌آید.">
        <Switch checked={s.endOverlay && permOk(perm, 'overlay')} onChange={(v) => { if (v && !permOk(perm, 'overlay')) openSetting('openOverlay'); else patch({ endOverlay: v }); }} label="پنجره‌ی پایان جلسه روی برنامه‌ها" />
      </Row>
      {s.endOverlay && perm && !perm.overlay && (
        <p className="m-hint" role="alert">پنجره‌ی روی برنامه‌ها روشن است ولی مجوز نمایش نیست؛ فعلاً فقط اعلان می‌آید.</p>
      )}
    </div>
  );
}

/* ---------- فایل‌ها ---------- */
function FilesPage({ s }) {
  const [confirm, setConfirm] = useState(false);
  const [restore, setRestore] = useState(null);
  const [msg, setMsg] = useState('');
  const fileInput = useRef(null);
  const sessionsNow = () => getItem(KEYS.sessions, []);
  const exportData = async () => shareFile('keyhan-tamarkoz-backup.json', JSON.stringify({ exportedAt: new Date().toISOString(), sessions: await sessionsNow(), settings: s }, null, 2), 'application/json');
  const pickBackup = async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > MAX_BACKUP_BYTES) { setRestore({ step: 'error', message: 'حجم فایل بیش از حد مجاز است.' }); return; }
    const res = parseBackup(await file.text(), { tasks: false });
    setRestore(res.ok ? { step: 'confirm', data: res.data, summary: res.summary } : { step: 'error', message: res.error });
  };
  const summaryText = (m) => `${toFa(m.sessions)} جلسه${m.settings ? ' و تنظیمات' : ''}` + (m.skipped ? ` (${toFa(m.skipped)} مورد نامعتبر نادیده گرفته شد)` : '');
  return (
    <>
      <div className="rows">
        <Row title="دریافت نسخه‌ی پشتیبان" hint="جلسه‌ها و تنظیمات در یک فایل JSON.">
          <button className="btn" onClick={exportData}>دریافت فایل</button>
        </Row>
        <Row title="خروجی آمار" hint="CSV برای Excel یا جمع روزانه JSON.">
          <div className="confirm">
            <button className="btn" onClick={async () => shareFile('keyhan-tamarkoz-sessions.csv', sessionsToCsv(await sessionsNow()), 'text/csv')}>CSV</button>
            <button className="btn" onClick={async () => shareFile('keyhan-tamarkoz-daily.json', dailySummaryJson(await sessionsNow()), 'application/json')}>JSON</button>
          </div>
        </Row>
        <Row title="بازیابی از فایل پشتیبان" hint="فایل JSON همین اپ یا افزونه‌ی کیهان تمرکز؛ بخش‌هایی که در این اپ نیست نادیده گرفته می‌شود.">
          <input ref={fileInput} type="file" accept=".json,application/json" hidden onChange={pickBackup} />
          <button className="btn" onClick={() => fileInput.current && fileInput.current.click()}>انتخاب فایل</button>
        </Row>
        {restore && restore.step === 'confirm' && (
          <div role="status"><Row title="بازیابی انجام شود؟" hint={`این فایل شامل ${summaryText(restore.summary)} است. جلسه‌های فعلی با محتوای فایل جایگزین می‌شوند.`}>
            <div className="confirm">
              <button className="btn danger" onClick={async () => { try { await restoreBackup(restore.data); setRestore({ step: 'done', summary: restore.summary }); } catch { setRestore({ step: 'error', message: 'بازیابی انجام نشد.' }); } }}>بله</button>
              <button className="btn" onClick={() => setRestore(null)}>انصراف</button>
            </div></Row></div>
        )}
        {restore && restore.step === 'done' && <div role="status"><Row title="بازیابی انجام شد" hint={`${summaryText(restore.summary)} بازیابی شد.`}><button className="btn" onClick={() => setRestore(null)}>بستن</button></Row></div>}
        {restore && restore.step === 'error' && <div role="alert"><Row title="بازیابی انجام نشد" hint={restore.message}><button className="btn" onClick={() => setRestore(null)}>بستن</button></Row></div>}
        <Row title="حذف همه‌ی جلسه‌ها" hint="آمار برای همیشه پاک می‌شود.">
          {confirm ? (
            <div className="confirm">
              <button className="btn danger" onClick={async () => { await setItem(KEYS.sessions, []); setConfirm(false); setMsg('جلسه‌ها حذف شد.'); }}>بله</button>
              <button className="btn" onClick={() => setConfirm(false)}>انصراف</button>
            </div>
          ) : <button className="btn danger" onClick={() => setConfirm(true)}>حذف جلسه‌ها</button>}
        </Row>
      </div>
      {msg && <p className="m-hint" role="status">{msg}</p>}
    </>
  );
}

/* ---------- دسترسی‌ها ---------- */
function PermissionFlow({ perm }) {
  const [flow, setFlow] = useState(null); // { queue, i, opened, seen }
  const missing = PERMS.filter((p) => !permOk(perm, p.id));
  const step = flow && flow.i < flow.queue.length ? PERMS.find((p) => p.id === flow.queue[flow.i]) : null;

  // با هر خواندن تازه‌ی وضعیت (بازگشت از تنظیمات): اگر مورد فعلی فعال شد برو مرحله‌ی بعد
  useEffect(() => {
    if (!flow || !perm) return;
    const id = flow.queue[flow.i];
    if (id === undefined) return;
    if (permOk(perm, id)) setFlow((f) => ({ ...f, i: f.i + 1, opened: false, seen: false }));
    else if (flow.opened && !flow.seen) setFlow((f) => ({ ...f, seen: true }));
  }, [perm]);

  if (!perm) return null;
  if (!flow) {
    return missing.length === 0
      ? <p className="m-ok" role="status">همه‌ی دسترسی‌ها فعال است.</p>
      : (
        <div className="m-flow">
          <button className="btn solid wide big" onClick={() => setFlow({ queue: missing.map((p) => p.id), i: 0, opened: false, seen: false })}>فعال‌سازی دسترسی‌های لازم</button>
          <p className="m-hint">{toFa(missing.length)} دسترسی خاموش است. اندروید هر دسترسی را در صفحه‌ی جداگانه می‌گیرد؛ این دکمه فقط مرحله‌ها را پشت‌سرهم و با راهنما جلو می‌برد، و می‌توانی هر مورد را رد کنی.</p>
        </div>
      );
  }
  if (!step) {
    const left = PERMS.filter((p) => !permOk(perm, p.id));
    return (
      <div className="m-flow" role="status">
        <p>{left.length === 0 ? 'همه‌ی دسترسی‌ها فعال شد.' : `این موارد فعال نشد: ${left.map((p) => p.title).join('، ')}. هر زمان خواستی از «وضعیت دسترسی‌ها» دوباره تلاش کن.`}</p>
        <button className="btn" onClick={() => setFlow(null)}>بستن</button>
      </div>
    );
  }
  return (
    <div className="m-flow" role="group" aria-label="راهنمای دسترسی">
      <p className="m-flow-step">مرحله‌ی {toFa(flow.i + 1)} از {toFa(flow.queue.length)}: {step.title}</p>
      <p>{step.why}</p>
      <p className="m-hint">{step.guide}</p>
      {flow.opened && flow.seen && <p className="m-hint" role="status">هنوز فعال نشده؛ می‌توانی دوباره تلاش کنی یا این مورد را رد کنی.</p>}
      <div className="confirm">
        <button className="btn solid" onClick={() => { openSetting(step.action); setFlow((f) => ({ ...f, opened: true, seen: false })); }}>{flow.opened ? 'تلاش دوباره' : 'ادامه'}</button>
        <button className="btn" onClick={() => setFlow((f) => ({ ...f, i: f.i + 1, opened: false, seen: false }))}>رد کردن</button>
        <button className="btn" onClick={() => setFlow(null)}>توقف</button>
      </div>
    </div>
  );
}

function AccessMenu({ s, perm, go }) {
  const total = PERMS.length;
  const ok = PERMS.filter((p) => permOk(perm, p.id)).length;
  return (
    <>
      <PermissionFlow perm={perm} />
      <div className="rows">
        <Link title="وضعیت دسترسی‌ها" status={perm ? `${toFa(ok)} از ${toFa(total)} فعال` : undefined} onClick={() => go('status')} />
        <Link title="محدودسازی برنامه‌ها" status={`هشدار ${s.limitEnabled ? 'روشن' : 'خاموش'} · حالت محدودسازی ${s.blockMode ? 'روشن' : 'خاموش'}`} onClick={() => go('limits')} />
      </div>
    </>
  );
}

function StatusPage({ perm }) {
  return (
    <div className="rows">
      {PERMS.map((p) => (
        <Row key={p.id} title={p.title} hint={`${permOk(perm, p.id) ? 'فعال' : 'خاموش'} · ${p.why}`}>
          {permOk(perm, p.id) ? <span className="m-ok">فعال</span> : <button className="btn" onClick={() => openSetting(p.action)}>{perm ? 'فعال‌سازی' : '…'}</button>}
        </Row>
      ))}
      <p className="m-hint">اگر مجوزی را رد کردی یا بعداً خاموش شد، همین‌جا دوباره فعالش کن. بعضی دسترسی‌ها فقط از صفحه‌ی تنظیمات اندروید داده می‌شوند.</p>
    </div>
  );
}

function LimitsPage({ s, patch, perm }) {
  const [apps, setApps] = useState(null);
  const [q, setQ] = useState('');
  const [consent, setConsent] = useState(false);
  const [blockMsg, setBlockMsg] = useState('');
  const selected = normalizePackages(s.limitedApps);
  useEffect(() => { listApps().then((a) => setApps(a)); }, []);
  const list = (apps || []).filter((a) => !q.trim() || a.label.toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <>
      <p className="m-rules">
        فقط برنامه‌هایی که خودت انتخاب می‌کنی بررسی می‌شوند. وقتی تمرکز در حال اجراست و یکی از آن‌ها جلوی صفحه بیاید، یک هشدار می‌گیری. اندروید به برنامه‌های عادی اجازه‌ی بستن یا قفل‌کردن برنامه‌های دیگر را نمی‌دهد، پس این قابلیت مسدودسازی قطعی نیست. هیچ داده‌ای از دستگاه خارج نمی‌شود.
      </p>
      <div className="rows">
        <Row title="هشدار هنگام استفاده از برنامه‌های منتخب" hint="فقط در حین جلسه‌ی تمرکز (نه استراحت) فعال است.">
          <Switch checked={s.limitEnabled} onChange={(v) => patch({ limitEnabled: v })} label="فعال‌سازی محدودیت برنامه‌ها" />
        </Row>
        <Row title="دسترسی به آمار استفاده" hint={permOk(perm, 'usageAccess') ? 'فعال است.' : 'لازم است تا بدانیم کدام برنامه جلوی صفحه است. فقط نام برنامه‌ی جلوی صفحه، روی همین گوشی و فقط هنگام تمرکز بررسی می‌شود.'}>
          {permOk(perm, 'usageAccess') ? <span className="m-ok">فعال</span> : <button className="btn" onClick={() => openSetting('openUsageAccess')}>باز کردن تنظیمات</button>}
        </Row>
        <Row title="بازگرداندن خودکار به اپ تمرکز" hint="اختیاری. نیاز به مجوز «نمایش روی برنامه‌های دیگر» دارد؛ بدون آن فقط هشدار اعلان می‌آید.">
          <Switch checked={s.limitBringBack} onChange={(v) => patch({ limitBringBack: v })} label="بازگرداندن خودکار" />
        </Row>
      </div>

      <h2 className="sub">حالت محدودسازی (سخت‌گیرانه)</h2>
      <p className="m-rules">
        اختیاری و پیش‌فرض خاموش. هنگام جلسه‌ی تمرکز، هر برنامه‌ای (به‌جز تماس، تنظیمات، صفحه‌ی اصلی، کیبورد و نوار سیستم) که جلوی صفحه بیاید، فوراً به این اپ برمی‌گردد. این مسدودسازی ۱۰۰٪ نیست: اندروید به اپ عادی اجازه‌ی قفل‌کردن گوشی نمی‌دهد (برای آن مدیریت دستگاه لازم است)؛ فقط برمی‌گرداند و تا لحظه‌ای که خودت بخواهی فعال می‌ماند. در استراحت و بین جلسه‌ها اعمال نمی‌شود.
      </p>
      <div className="rows">
        <Row title="مجوز آمار استفاده" hint="لازم است تا برنامه‌ی جلوی صفحه تشخیص داده شود.">
          {permOk(perm, 'usageAccess') ? <span className="m-ok">فعال</span> : <button className="btn" onClick={() => openSetting('openUsageAccess')}>باز کردن تنظیمات</button>}
        </Row>
        <Row title="مجوز نمایش روی برنامه‌های دیگر" hint="لازم است تا اپ بتواند از پس‌زمینه جلو بیاید.">
          {permOk(perm, 'overlay') ? <span className="m-ok">فعال</span> : <button className="btn" onClick={() => openSetting('openOverlay')}>باز کردن تنظیمات</button>}
        </Row>
        {!s.blockMode && (
          <label className="m-consent">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            <span>می‌دانم که در حین تمرکز استفاده از برنامه‌های دیگر ناممکن یا دشوار می‌شود و هر زمان می‌توانم از همین صفحه، از صفحه‌ی تمرکز یا از دکمه‌ی اعلان آن را خاموش کنم.</span>
          </label>
        )}
        <Row title="فعال‌سازی حالت محدودسازی" hint={s.blockMode ? 'فعال است؛ هر زمان خاموشش کن.' : 'خاموش'}>
          <Switch checked={s.blockMode} label="حالت محدودسازی" onChange={(v) => {
            if (!v) { setBlockMsg(''); patch({ blockMode: false }); return; }
            if (!consent) { setBlockMsg('ابتدا گزینه‌ی رضایت را تأیید کن.'); return; }
            if (!(permOk(perm, 'usageAccess') && permOk(perm, 'overlay'))) { setBlockMsg('هر دو مجوز بالا باید فعال باشند.'); return; }
            setBlockMsg(''); patch({ blockMode: true });
          }} />
        </Row>
        {s.blockMode && perm && !(perm.usageAccess && perm.overlay) && (
          <p className="m-hint" role="alert">یکی از مجوزها خاموش شده؛ تا فعال‌شدنش فقط هشدار اعلان می‌آید.</p>
        )}
        {blockMsg && <p className="m-hint" role="alert">{blockMsg}</p>}
      </div>

      <h2 className="sub">برنامه‌های منتخب ({toFa(selected.length)} از {toFa(MAX_LIMITED_APPS)})</h2>
      <input className="m-search" placeholder="جست‌وجوی برنامه" aria-label="جست‌وجوی برنامه" value={q} onChange={(e) => setQ(e.target.value)} />
      {apps === null ? <p className="empty">در حال بارگذاری…</p> : list.length === 0 ? (
        <p className="empty">{isNative() ? 'برنامه‌ای پیدا نشد.' : 'فهرست برنامه‌ها فقط در اپ اندروید در دسترس است.'}</p>
      ) : (
        <ul className="m-apps">
          {list.map((a) => (
            <li key={a.package}>
              <label>
                <input type="checkbox" checked={selected.includes(a.package)} onChange={() => patch({ limitedApps: togglePackage(selected, a.package) })} />
                <span>{a.label}</span>
              </label>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

/* ---------- مسیریاب تنظیمات ---------- */
export default function SettingsRouter({ path, setPath }) {
  const [s, patch, ready] = useSettings();
  const [perm] = usePerms(path[0] === 'access' ? 1500 : 0);
  if (!ready) return <div className="m-screen" />;

  const key = path.join('/');
  const go = (id) => setPath([...path, id]);
  const back = () => setPath(path.slice(0, -1));
  const sec = path[0];

  if (path.length === 0) {
    const customs = Array.isArray(s.customThemes) ? s.customThemes : [];
    const cur = THEMES.find((t) => t.id === s.theme) || customs.find((c) => c.id === s.theme);
    const ok = PERMS.filter((p) => permOk(perm, p.id)).length;
    return (
      <div className="m-screen">
        <h1>تنظیمات</h1>
        <div className="rows">
          <Link title={TITLES.appearance} status={cur ? `تم: ${cur.label || cur.name}` : undefined} onClick={() => setPath(['appearance'])} />
          <Link title={TITLES.session} status={`تمرکز ${toFa(s.defaultMinutes)} · استراحت ${toFa(s.breakMinutes)} · تمدید ${toFa(s.extendMinutes)} دقیقه`} onClick={() => setPath(['session'])} />
          <Link title={TITLES.alerts} status={`اعلان ${s.notifications ? 'روشن' : 'خاموش'} · صدا ${s.soundEnabled ? 'روشن' : 'خاموش'}`} onClick={() => setPath(['alerts'])} />
          <Link title={TITLES.files} status="پشتیبان، بازیابی و خروجی آمار" onClick={() => setPath(['files'])} />
          <Link title={TITLES.access} status={perm ? `${toFa(ok)} از ${toFa(PERMS.length)} دسترسی فعال · محدودسازی ${s.blockMode ? 'روشن' : 'خاموش'}` : undefined} onClick={() => setPath(['access'])} />
        </div>
      </div>
    );
  }

  let body = null;
  if (key === 'appearance') body = <AppearanceMenu s={s} go={go} />;
  else if (key === 'appearance/themes') body = <div className="rows"><ThemeSettings s={s} patch={patch} Row={Row} part="select" /></div>;
  else if (key === 'appearance/custom') body = <div className="rows"><ThemeSettings s={s} patch={patch} Row={Row} part="custom" /></div>;
  else if (key === 'session') body = <SessionPage s={s} patch={patch} />;
  else if (key === 'alerts') body = <AlertsMenu s={s} perm={perm} go={go} />;
  else if (key === 'alerts/sound') body = <div className="rows"><SoundSettings s={s} patch={patch} Row={Row} Switch={Switch} /></div>;
  else if (key === 'alerts/notifications') body = <NotificationsPage s={s} patch={patch} perm={perm} />;
  else if (key === 'files') body = <FilesPage s={s} />;
  else if (key === 'access') body = <AccessMenu s={s} perm={perm} go={go} />;
  else if (key === 'access/status') body = <StatusPage perm={perm} />;
  else if (key === 'access/limits') body = <LimitsPage s={s} patch={patch} perm={perm} />;

  return (
    <div className="m-screen">
      <div className="m-subhead">
        <button className="btn small" onClick={back}>{path.length === 1 ? 'بازگشت به تنظیمات' : `بازگشت به ${TITLES[sec]}`}</button>
      </div>
      <h1>{TITLES[key]}</h1>
      {body}
    </div>
  );
}
