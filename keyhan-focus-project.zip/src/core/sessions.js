// افزودن، ویرایش و حذف جلسه‌ی دستی. جلسه‌ی دستی در همان آرایه‌ی جلسه‌های تایمر ذخیره می‌شود
// (source: 'manual')؛ پس هر جلسه فقط یک‌بار در آمار شمرده می‌شود. به تایمر و کارها دست نمی‌زند.
import { KEYS } from './constants.js';
import { formatTime, fromFa } from './format.js';
import { jalaliMonthLength, jalaliToDate } from './jalali.js';
import { endOf, isManual, MANUAL_MAX_MS, uniqueSessions, validSession } from './sessionRules.js';
import { getItem, setItem } from './storage.js';
import { getTimer, withLock } from './timerService.js';

const fail = (field, error) => ({ ok: false, field, error });

export function parseClock(text) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(fromFa(String(text ?? '')).trim());
  if (!m) return null;
  const h = Number(m[1]);
  const min = Number(m[2]);
  return h <= 23 && min <= 59 ? h * 60 + min : null;
}

/**
 * ورودی: { jy, jm, jd, start: 'HH:MM', end: 'HH:MM' }
 * جلسه‌ای که از نیمه‌شب می‌گذرد پشتیبانی نمی‌شود (آمار هر جلسه را به روز شروعش نسبت می‌دهد)،
 * پس پایان باید در همان روز و بعد از شروع باشد.
 */
export function validateManual(input, { now = Date.now(), sessions = [], timer = null, ignoreId = null } = {}) {
  const { jy, jm, jd } = input || {};
  if (![jy, jm, jd].every(Number.isInteger) || jm < 1 || jm > 12 || jd < 1 || jy < 1300 || jy > 1600) {
    return fail('date', 'تاریخ نامعتبر است.');
  }
  if (jd > jalaliMonthLength(jy, jm)) return fail('date', 'این روز در این ماه وجود ندارد.');

  const s = parseClock(input.start);
  if (s === null) return fail('start', 'ساعت شروع را درست وارد کنید.');
  const e = parseClock(input.end);
  if (e === null) return fail('end', 'ساعت پایان را درست وارد کنید.');
  if (e <= s) {
    return fail('end', 'ساعت پایان باید بعد از ساعت شروع باشد. جلسه‌ای که از نیمه‌شب می‌گذرد را در دو جلسه‌ی جدا ثبت کنید.');
  }

  const day = jalaliToDate(jy, jm, jd);
  const startedAt = new Date(day.getFullYear(), day.getMonth(), day.getDate(), 0, s).getTime();
  const endedAt = new Date(day.getFullYear(), day.getMonth(), day.getDate(), 0, e).getTime();
  const focusedMs = endedAt - startedAt;

  if (!Number.isFinite(focusedMs) || focusedMs <= 0) return fail('end', 'مدت جلسه نامعتبر است.');
  if (focusedMs > MANUAL_MAX_MS) return fail('end', 'مدت جلسه نمی‌تواند بیشتر از ۱۲ ساعت باشد.');
  if (endedAt > now) return fail('end', 'زمان پایان نمی‌تواند در آینده باشد.');

  // هم‌پوشانی با جلسه‌های دیگر (تایمر یا دستی) یعنی شمارش دوباره‌ی همان زمان
  for (const o of uniqueSessions(sessions)) {
    if (!validSession(o) || String(o.id) === String(ignoreId)) continue;
    if (startedAt < endOf(o) && o.startedAt < endedAt) {
      return fail('start', `با جلسه‌ی ${formatTime(o.startedAt)} تا ${formatTime(endOf(o))} هم‌پوشانی دارد.`);
    }
  }
  if (timer && timer.kind !== 'break' && (timer.status === 'running' || timer.status === 'paused') && Number.isFinite(timer.startedAt)) {
    if (startedAt < now && timer.startedAt < endedAt) {
      return fail('start', 'این بازه با تایمر در حال اجرا هم‌پوشانی دارد.');
    }
  }
  return { ok: true, startedAt, endedAt, focusedMs };
}

const newId = () => `manual-${globalThis.crypto.randomUUID()}`;

export function addManualSession(input, now = Date.now()) {
  return withLock(async () => {
    const sessions = await getItem(KEYS.sessions, []);
    const v = validateManual(input, { now, sessions, timer: await getTimer() });
    if (!v.ok) return v;
    const session = {
      id: newId(),
      source: 'manual',
      startedAt: v.startedAt,
      endedAt: v.endedAt,
      plannedMs: v.focusedMs,
      focusedMs: v.focusedMs,
      completed: true,
      createdAt: now,
    };
    await setItem(KEYS.sessions, [...sessions, session]);
    return { ok: true, session };
  });
}

/** فقط جلسه‌ی دستی ویرایش می‌شود؛ جلسه‌ی تایمر هیچ‌وقت. */
export function updateManualSession(id, input, now = Date.now()) {
  return withLock(async () => {
    const sessions = await getItem(KEYS.sessions, []);
    const idx = sessions.findIndex((s) => String(s.id) === String(id));
    if (idx < 0) return fail('form', 'این جلسه پیدا نشد.');
    if (!isManual(sessions[idx])) return fail('form', 'فقط جلسه‌های دستی قابل ویرایش‌اند.');
    const v = validateManual(input, { now, sessions, timer: await getTimer(), ignoreId: id });
    if (!v.ok) return v;
    const next = sessions.slice();
    next[idx] = { ...sessions[idx], startedAt: v.startedAt, endedAt: v.endedAt, plannedMs: v.focusedMs, focusedMs: v.focusedMs, editedAt: now };
    await setItem(KEYS.sessions, next);
    return { ok: true, session: next[idx] };
  });
}
