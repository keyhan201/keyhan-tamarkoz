// آمار تکمیلی: رکوردها، زنجیره‌ی روزهای متوالی، تقویم شمسی (هفته از شنبه) و برنامه‌ریزی‌شده در برابر واقعی.
// فقط از جلسه‌های معتبر ذخیره‌شده ساخته می‌شود؛ اگر داده‌ای نباشد مقدار null برمی‌گردد، نه عدد ساختگی.
import { addDays, startOfDay } from './dailyStats.js';
import { jalaliMonthLength, jalaliToDate, toJalali, weekdayIndex, WEEK_DAYS } from './jalali.js';
import { endOf, uniqueSessions, validSession } from './sessionRules.js';
import { dayKey } from './stats.js';

const fin = (v) => typeof v === 'number' && Number.isFinite(v);

export const cleanSessions = (list) => uniqueSessions(list).filter(validSession);

/** نقشه‌ی روزانه: کلید = dayKey؛ مقدار = { ts (آغاز روز), count, focusedMs, plannedMs, plannedActualMs, unplanned, sessions } */
export function buildDayMap(sessions) {
  const map = new Map();
  for (const s of cleanSessions(sessions)) {
    const ts = startOfDay(s.startedAt);
    const k = dayKey(ts);
    let d = map.get(k);
    if (!d) {
      d = { ts, count: 0, focusedMs: 0, plannedMs: 0, plannedActualMs: 0, unplanned: 0, sessions: [] };
      map.set(k, d);
    }
    d.count += 1;
    d.focusedMs += s.focusedMs;
    d.sessions.push(s);
    if (fin(s.plannedMs) && s.plannedMs > 0) {
      d.plannedMs += s.plannedMs;
      d.plannedActualMs += s.focusedMs; // فقط جلسه‌هایی که زمان برنامه‌ریزی‌شده دارند، تا مقایسه منصفانه بماند
    } else {
      d.unplanned += 1;
    }
  }
  for (const d of map.values()) d.sessions.sort((a, b) => a.startedAt - b.startedAt);
  return map;
}

const dayInfo = (d) => ({ ts: d.ts, weekday: WEEK_DAYS[weekdayIndex(d.ts)], count: d.count, focusedMs: d.focusedMs });

/** برای برابری، قدیمی‌ترین روز نگه داشته می‌شود تا نتیجه با ترتیب ورودی عوض نشود. */
function bestDay(dayMap, pick) {
  let best = null;
  for (const d of dayMap.values()) {
    if (!best || pick(d) > pick(best) || (pick(d) === pick(best) && d.ts < best.ts)) best = d;
  }
  return best && pick(best) > 0 ? dayInfo(best) : null;
}

export function longestSession(sessions) {
  let best = null;
  for (const s of cleanSessions(sessions)) {
    if (!best || s.focusedMs > best.focusedMs || (s.focusedMs === best.focusedMs && s.startedAt < best.startedAt)) best = s;
  }
  if (!best) return null;
  return { ts: startOfDay(best.startedAt), weekday: WEEK_DAYS[weekdayIndex(best.startedAt)], focusedMs: best.focusedMs, startedAt: best.startedAt, endedAt: endOf(best) };
}

/** زنجیره: روزهای تقویمی پشت‌سرهم با دست‌کم یک جلسه. جابه‌جایی روز با تقویم محلی است (امن در تغییر ساعت). */
export function streaks(dayMap, now = Date.now()) {
  const days = [...dayMap.values()].map((d) => d.ts).sort((a, b) => a - b);
  if (!days.length) return { current: 0, best: 0, bestFrom: null, bestTo: null };

  let best = 0;
  let bestFrom = null;
  let bestTo = null;
  let run = 0;
  let runFrom = null;
  for (let i = 0; i < days.length; i++) {
    if (i > 0 && addDays(days[i - 1], 1) === days[i]) run += 1;
    else {
      run = 1;
      runFrom = days[i];
    }
    if (run > best) {
      best = run;
      bestFrom = runFrom;
      bestTo = days[i];
    }
  }

  // زنجیره‌ی فعلی: اگر امروز هنوز جلسه‌ای نیست، از دیروز شمرده می‌شود (روز جاری هنوز تمام نشده)
  const have = new Set(days);
  let cursor = startOfDay(now);
  if (!have.has(cursor)) cursor = addDays(cursor, -1);
  let current = 0;
  while (have.has(cursor)) {
    current += 1;
    cursor = addDays(cursor, -1);
  }
  return { current, best, bestFrom, bestTo };
}

/** تفکیک بر اساس روز هفته (شنبه=۰): مجموع تمرکز، تعداد روزهای فعال و میانگین هر روز فعال */
export function weekdayBreakdown(dayMap) {
  const rows = WEEK_DAYS.map((name, index) => ({ index, name, totalMs: 0, activeDays: 0, avgMs: 0 }));
  for (const d of dayMap.values()) {
    const r = rows[weekdayIndex(d.ts)];
    r.totalMs += d.focusedMs;
    r.activeDays += 1;
  }
  for (const r of rows) r.avgMs = r.activeDays ? r.totalMs / r.activeDays : 0;
  const top = rows.reduce((a, r) => (r.totalMs > (a ? a.totalMs : 0) ? r : a), null);
  return { rows, topIndex: top ? top.index : null };
}

export function buildInsights(sessions, now = Date.now()) {
  const dayMap = buildDayMap(sessions);
  return {
    dayMap,
    hasData: dayMap.size > 0,
    longest: longestSession(sessions),
    mostSessions: bestDay(dayMap, (d) => d.count),
    mostFocus: bestDay(dayMap, (d) => d.focusedMs),
    streaks: streaks(dayMap, now),
    weekdays: weekdayBreakdown(dayMap),
  };
}

/**
 * شبکه‌ی یک ماه شمسی؛ ستون اول شنبه است. خانه‌های خالی ابتدا/انتها null هستند.
 * level (۰ تا ۴) نسبت به بیشینه‌ی زمان تمرکز هر روز در کل داده است تا ماه‌ها قابل مقایسه بمانند.
 */
export function monthGrid(jy, jm, dayMap) {
  const first = jalaliToDate(jy, jm, 1);
  const len = jalaliMonthLength(jy, jm);
  let max = 0;
  for (const d of dayMap.values()) max = Math.max(max, d.focusedMs);

  const cells = Array(weekdayIndex(first)).fill(null);
  for (let jd = 1; jd <= len; jd++) {
    const ts = jalaliToDate(jy, jm, jd).getTime();
    const data = dayMap.get(dayKey(ts)) || null;
    const level = !data || !max ? 0 : Math.min(4, Math.max(1, Math.ceil((4 * data.focusedMs) / max)));
    cells.push({ jd, ts, data, level });
  }
  while (cells.length % 7) cells.push(null);
  const weeks = [];
  for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));
  return { jy, jm, length: len, weeks };
}

export const jalaliMonthOf = (ts) => {
  const { jy, jm } = toJalali(ts);
  return { jy, jm };
};
export const shiftMonth = ({ jy, jm }, delta) => {
  const idx = jy * 12 + (jm - 1) + delta;
  return { jy: Math.floor(idx / 12), jm: (idx % 12) + 1 };
};
export const compareMonth = (a, b) => a.jy * 12 + a.jm - (b.jy * 12 + b.jm);
