// منطق انتخاب جمله‌ی انگیزشی؛ متن‌ها در src/data/quotes.js هستند.
import { QUOTES_BY_CATEGORY } from '../data/quotes.js';

export const QUOTE_CATEGORIES = ['start', 'keep', 'end'];
export const RECENT_LIMIT = 25; // آخرین جمله‌های نمایش‌داده‌شده‌ی هر دسته که تا حد ممکن تکرار نمی‌شوند

export const ALL_QUOTES = QUOTE_CATEGORIES.flatMap((category) =>
  QUOTES_BY_CATEGORY[category].map((text, i) => ({ id: `${category}-${i}`, category, text })),
);

/** shuffle نیست؛ از میان جمله‌های غیرتکراری تصادفی انتخاب می‌شود. rng برای تست قابل‌تزریق است. */
export function pickQuote(category, recentIds = [], rng = Math.random, quotes = ALL_QUOTES) {
  const pool = quotes.filter((q) => q.category === category);
  if (!pool.length) return null;
  const window = Math.min(RECENT_LIMIT, pool.length - 1);
  const recent = new Set((Array.isArray(recentIds) ? recentIds : []).slice(-window));
  const fresh = pool.filter((q) => !recent.has(q.id));
  const from = fresh.length ? fresh : pool;
  const r = Number(rng());
  const i = Number.isFinite(r) ? Math.min(from.length - 1, Math.max(0, Math.floor(r * from.length))) : 0;
  return from[i];
}

export const pushRecent = (recentIds, id, limit = RECENT_LIMIT) => {
  const list = (Array.isArray(recentIds) ? recentIds : []).filter((x) => x !== id);
  list.push(id);
  return list.slice(-limit);
};

/** وضعیت تایمر → دسته‌ی جمله */
export function categoryFor(timer, now = Date.now()) {
  if (timer && (timer.status === 'running' || timer.status === 'paused')) return 'keep';
  const r = timer && timer.lastResult;
  if (r && Number.isFinite(r.at) && now - r.at < 60 * 60 * 1000) return 'end';
  return 'start';
}
