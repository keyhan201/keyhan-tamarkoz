import { weekdayName } from './jalali.js';

const FA = '۰۱۲۳۴۵۶۷۸۹';
const AR = '٠١٢٣٤٥٦٧٨٩';

export const toFa = (v) => String(v).replace(/\d/g, (d) => FA[d]);
export const fromFa = (s) =>
  String(s)
    .replace(/[۰-۹]/g, (d) => FA.indexOf(d))
    .replace(/[٠-٩]/g, (d) => AR.indexOf(d));

/** ثانیه → «۲۵:۰۰». ورودی نامعتبر (NaN، null، undefined) همیشه به ۰ تبدیل می‌شود. */
export function formatSeconds(totalSeconds) {
  const safe = Number.isFinite(totalSeconds) ? Math.max(0, Math.floor(totalSeconds)) : 0;
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return toFa(`${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`);
}

/** میلی‌ثانیه باقی‌مانده → ساعت‌شمار (رو به بالا گرد می‌شود تا با شمارش معکوس هم‌خوان باشد) */
export const clock = (ms) => formatSeconds(Number.isFinite(ms) ? Math.ceil(ms / 1000) : 0);

/** نمایش مدت به‌صورت متن: «۱ ساعت و ۱۰ دقیقه» */
export function duration(ms) {
  if (!Number.isFinite(ms) || ms <= 0) return '۰ دقیقه';
  const minutes = Math.round(ms / 60000);
  if (minutes < 1) return 'کمتر از ۱ دقیقه';
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  const parts = [];
  if (h) parts.push(`${toFa(h)} ساعت`);
  if (m) parts.push(`${toFa(m)} دقیقه`);
  return parts.join(' و ');
}

const fullDay = new Intl.DateTimeFormat('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' });
const dayNumber = new Intl.DateTimeFormat('fa-IR', { day: 'numeric' });
const time = new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit', hour12: false });

const dayMonth = new Intl.DateTimeFormat('fa-IR', { day: 'numeric', month: 'long' });
export const formatDayMonth = (ts) => dayMonth.format(ts);
export const formatFullDay = (ts) => fullDay.formatToParts(ts)
  .map((part) => part.type === 'weekday' ? weekdayName(ts) : part.value).join('');
export const formatShortDay = weekdayName;
export const formatDayNumber = (ts) => dayNumber.format(ts);
export const formatTime = (ts) => time.format(ts);
