export const PRESETS = [5, 15, 25, 45, 60];
export const MIN_MINUTES = 1;
export const MAX_MINUTES = 360;
export const MIN_BREAK_MINUTES = 1;
export const MAX_BREAK_MINUTES = 60;
export const DEFAULT_BREAK_MINUTES = 5;
export const STOP_WINDOW_MS = 10 * 1000; // توقف و انصراف فقط در ۱۰ ثانیه‌ی اول ممکن است

export const KEYS = {
  customSound: 'customSound',
  recentQuotes: 'recentQuotes',
  timer: 'timer',
  sessions: 'sessions',
  tasks: 'tasks',
  settings: 'settings',
};

export const DEFAULT_SETTINGS = {
  defaultMinutes: 25,
  customMinutes: [], // زمان‌های دلخواه ذخیره‌شده (عدد صحیح، بدون تکرار)
  notifications: true,
  badge: true,
  theme: 'main', // شناسه‌ی تم آماده یا تم شخصی (custom-…)
  customThemes: [], // تم‌های شخصی: { id, name, accent, bg, ink }
  soundEnabled: true,
  soundId: 'ding', // ding | chime | soft | drop | custom
  tasksEnabled: true, // نمایش بخش «کارهای روزانه»؛ پنهان‌کردن داده‌ها را پاک نمی‌کند
  showQuotes: true, // جمله‌ی انگیزشی کوتاه در پاپ‌آپ
  breakMinutes: 5, // مدت استراحت (اندروید): عدد صحیح ۱ تا ۶۰ دقیقه
  limitEnabled: false, // محدودیت برنامه‌های منتخب هنگام تمرکز (اندروید)
  limitedApps: [], // نام بسته‌ی برنامه‌هایی که خود کاربر انتخاب کرده
  extendMinutes: 5, // مدت «تمدید جلسه» (اندروید): ۱ تا ۶۰ دقیقه
  blockMode: false, // حالت محدودسازی سخت‌گیرانه هنگام تمرکز (اندروید؛ فقط با رضایت صریح کاربر)
  endOverlay: false, // پنجره‌ی پایان جلسه روی برنامه‌های دیگر (اختیاری؛ نیاز به مجوز جدا)
  limitBringBack: false, // بازگرداندن خودکار به اپ تمرکز (نیاز به مجوز «نمایش روی برنامه‌های دیگر»)
};

// صدای پایان فقط وقتی پخش می‌شود که ثبت جلسه حداکثر این‌قدر بعد از لحظه‌ی پایان انجام شده باشد.
// اگر مرورگر/سیستم بسته بوده و بعداً وضعیت بازیابی شود، جلسه ثبت می‌شود ولی صدا پخش نمی‌شود.
export const SOUND_MAX_DELAY_MS = 20 * 1000;
// اعلان بصری هم با همان قاعده: اگر ثبت جلسه دیر انجام شده باشد، اعلان دیرهنگام نمایش داده نمی‌شود.
export const NOTICE_MAX_DELAY_MS = SOUND_MAX_DELAY_MS;

// وضعیت تایمر: همه‌ی زمان‌ها یا عدد معتبرند یا null (هیچ‌وقت NaN/undefined ذخیره نمی‌شود)
export const IDLE_TIMER = {
  status: 'idle', // idle | running | paused
  kind: 'focus', // focus | break (استراحت؛ جلسه‌ای ثبت نمی‌کند)
  durationSeconds: 25 * 60,
  remainingSeconds: 25 * 60,
  startedAt: null,
  endsAt: null,
  gracePeriodEndsAt: null, // پایان بازه‌ی ۱۰ ثانیه‌ی توقف/انصراف (در حالت اجرا)
  graceRemainingMs: null, // باقی‌مانده‌ی همان بازه در حالت توقف (منجمد می‌شود)
  sessionId: null,
  lastResult: null,
};
