// صداهای کوتاه و ملایم، با Web Audio ساخته می‌شوند (بدون فایل صوتی).
// هم در صفحه‌ی تنظیمات (پیش‌نمایش) و هم در سندِ offscreen (پخش پایان جلسه) استفاده می‌شود.
export const SOUNDS = [
  { id: 'ding', label: 'دینگ' },
  { id: 'chime', label: 'زنگوله' },
  { id: 'soft', label: 'نت نرم' },
  { id: 'drop', label: 'قطره' },
];

export const CUSTOM_SOUND_ID = 'custom'; // «صدای من»؛ داده‌اش در core/customSound.js نگه‌داری می‌شود
export const soundIdOf = (id) => (id === CUSTOM_SOUND_ID || SOUNDS.some((s) => s.id === id) ? id : 'ding');

// هر نت: [فرکانس، شروع (ثانیه)، مدت (ثانیه)، بلندی، نوع موج]
const SCORES = {
  ding: [
    [1318.5, 0, 1.3, 0.3, 'sine'],
    [2637, 0, 0.6, 0.07, 'sine'],
  ],
  chime: [
    [783.99, 0, 1.0, 0.22, 'sine'],
    [1046.5, 0.16, 1.0, 0.22, 'sine'],
    [1318.5, 0.32, 1.4, 0.22, 'sine'],
  ],
  soft: [
    [523.25, 0, 1.2, 0.24, 'triangle'],
    [659.25, 0.01, 1.2, 0.14, 'triangle'],
  ],
  drop: [
    [880, 0, 0.5, 0.26, 'sine'],
    [660, 0.14, 0.7, 0.2, 'sine'],
  ],
};

import { MAX_SOUND_SECONDS, base64ToBytes, validStoredSound } from './customSound.js';

let shared = null;
function context() {
  const AC = globalThis.AudioContext || globalThis.webkitAudioContext;
  if (!AC) return null;
  if (!shared || shared.state === 'closed') shared = new AC();
  return shared;
}

/**
 * صدای کاربر را پخش می‌کند؛ ورودی همان شکل ذخیره‌شده است. اگر نامعتبر یا غیرقابل‌پخش باشد false برمی‌گرداند
 * (فراخوان می‌تواند به صدای داخلی برگردد). خطا بیرون نمی‌زند و آدرس موقت همیشه آزاد می‌شود.
 */
export async function playCustom(stored) {
  const sound = validStoredSound(stored);
  if (!sound || typeof Audio === 'undefined') return false;
  let url = null;
  try {
    url = URL.createObjectURL(new Blob([base64ToBytes(sound.data)], { type: sound.mime }));
    const audio = new Audio(url);
    await new Promise((resolve, reject) => {
      const timer = setTimeout(resolve, (Math.min(sound.duration, MAX_SOUND_SECONDS) + 2) * 1000);
      audio.onended = () => { clearTimeout(timer); resolve(); };
      audio.onerror = () => { clearTimeout(timer); reject(new Error('audio')); };
      audio.play().catch((e) => { clearTimeout(timer); reject(e); });
    });
    return true;
  } catch {
    return false;
  } finally {
    if (url) URL.revokeObjectURL(url);
  }
}

/** صدا را پخش می‌کند و وقتی تمام شد resolve می‌شود. خطا هیچ‌وقت بیرون نمی‌زند. */
export async function playSound(id) {
  try {
    const ctx = context();
    if (!ctx) return;
    if (ctx.state === 'suspended') await ctx.resume();
    const score = SCORES[soundIdOf(id)] || SCORES.ding; // «custom» جدا پخش می‌شود؛ این‌جا فقط جایگزین امن
    const t0 = ctx.currentTime + 0.03;
    let end = 0;
    for (const [freq, at, len, vol, type] of score) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, t0 + at);
      gain.gain.setValueAtTime(0.0001, t0 + at);
      gain.gain.exponentialRampToValueAtTime(vol, t0 + at + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + at + len);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t0 + at);
      osc.stop(t0 + at + len + 0.05);
      end = Math.max(end, at + len + 0.05);
    }
    await new Promise((r) => setTimeout(r, (end + 0.1) * 1000));
  } catch {
    /* پخش صدا هرگز نباید جلسه یا رابط را خراب کند */
  }
}
