// داده‌ی تب «مقایسه»: فقط از جلسه‌های واقعی (تایمر + دستی) در یک آرایه‌ی واحد؛ هیچ مقدار ساختگی ساخته نمی‌شود.
// آرایه‌ی هفته از شنبه تا جمعه ساخته می‌شود؛ محور نمودار ستونی همین ترتیب را از راست به چپ رسم می‌کند.
import { addDays, startOfDay } from './dailyStats.js';
import { duration, formatDayMonth, formatFullDay, formatShortDay, toFa } from './format.js';
import { JALALI_MONTHS, WEEK_DAYS, jalaliToDate, jalaliMonthLength, toJalali, startOfWeek, weekdayIndex } from './jalali.js';
import { uniqueSessions, validSession } from './sessionRules.js';

export const RANGES = [
  { id: 'day', label: 'روزانه', hint: '۷ روز اخیر' },
  { id: 'week', label: 'هفتگی', hint: 'هفته‌ی شمسی' },
  { id: 'month', label: 'ماهانه', hint: 'ماه شمسی' },
  { id: 'year', label: 'سالانه', hint: 'سال شمسی' },
];

export const METRICS = [
  { id: 'total', label: 'مجموع زمان تمرکز', short: 'زمان تمرکز', time: true },
  { id: 'count', label: 'تعداد جلسه‌های کامل‌شده', short: 'تعداد جلسه', time: false },
  { id: 'avg', label: 'میانگین مدت جلسه', short: 'میانگین جلسه', time: true },
  { id: 'longest', label: 'طولانی‌ترین جلسه', short: 'طولانی‌ترین', time: true },
];

/** جابه‌جایی لنگر بازه به اندازه‌ی یک بازه‌ی کامل (dir = ±۱) */
export function shiftAnchor(range, anchor, dir) {
  if (range === 'day' || range === 'week') return addDays(anchor, 7 * dir);
  const j = toJalali(anchor);
  if (range === 'month') {
    const idx = j.jy * 12 + (j.jm - 1) + dir;
    return jalaliToDate(Math.floor(idx / 12), (idx % 12) + 1, 1).getTime();
  }
  return jalaliToDate(j.jy + dir, 1, 1).getTime();
}

/** لنگر مجاز: بازه‌ی شامل امروز آخرین بازه است. */
export const clampAnchor = (anchor, today) => Math.min(anchor, today);

function dayBucket(ts, today, label) {
  return { start: ts, end: addDays(ts, 1), label: label ?? formatShortDay(ts), full: formatFullDay(ts), future: ts > today };
}

export function periodOf(range, anchor, today = startOfDay(Date.now())) {
  if (range === 'day') {
    const first = addDays(anchor, -6);
    const buckets = Array.from({ length: 7 }, (_, i) => dayBucket(addDays(first, i), today));
    return { range, buckets, label: `${formatDayMonth(first)} تا ${formatDayMonth(anchor)}` };
  }
  if (range === 'week') {
    const first = startOfWeek(anchor);
    const buckets = WEEK_DAYS.map((label, i) => dayBucket(addDays(first, i), today, label));
    return { range, buckets, label: `${formatDayMonth(first)} تا ${formatDayMonth(addDays(first, 6))}` };
  }
  const j = toJalali(anchor);
  if (range === 'month') {
    const len = jalaliMonthLength(j.jy, j.jm);
    const buckets = Array.from({ length: len }, (_, i) => {
      const ts = jalaliToDate(j.jy, j.jm, i + 1).getTime();
      return dayBucket(ts, today, toFa(i + 1));
    });
    return { range, buckets, label: `${JALALI_MONTHS[j.jm - 1]} ${toFa(j.jy)}` };
  }
  const buckets = Array.from({ length: 12 }, (_, i) => {
    const start = jalaliToDate(j.jy, i + 1, 1).getTime();
    const end = (i === 11 ? jalaliToDate(j.jy + 1, 1, 1) : jalaliToDate(j.jy, i + 2, 1)).getTime();
    return { start, end, label: JALALI_MONTHS[i], full: `${JALALI_MONTHS[i]} ${toFa(j.jy)}`, future: start > today };
  });
  return { range, buckets, label: toFa(j.jy) };
}

export function aggregate(list) {
  const totalMs = list.reduce((a, s) => a + s.focusedMs, 0);
  const count = list.length;
  return {
    count,
    totalMs,
    avgMs: count ? totalMs / count : null,
    longestMs: count ? list.reduce((a, s) => Math.max(a, s.focusedMs), 0) : null,
  };
}

function fill(valid, period) {
  const buckets = period.buckets.map((b) => ({
    ...b,
    ...aggregate(valid.filter((s) => s.startedAt >= b.start && s.startedAt < b.end)),
  }));
  const first = period.buckets[0].start;
  const last = period.buckets[period.buckets.length - 1].end;
  return { ...period, buckets, all: aggregate(valid.filter((s) => s.startedAt >= first && s.startedAt < last)) };
}

/** بازه‌ی جاری و بازه‌ی قبلی از همان نوع، با آمار هر دسته (روز/ماه) */
export function buildSeries(sessions, range, anchorTs, today = startOfDay(Date.now())) {
  const valid = uniqueSessions(sessions).filter(validSession);
  const anchor = clampAnchor(startOfDay(anchorTs), today);
  return {
    range,
    anchor,
    cur: fill(valid, periodOf(range, anchor, today)),
    prev: fill(valid, periodOf(range, shiftAnchor(range, anchor, -1), today)),
  };
}

/** مقدار عددی معیار برای یک دسته یا کل بازه: دقیقه یا تعداد؛ بدون داده null (نه صفر ساختگی). */
export function metricValue(metricId, a) {
  if (a.future) return null;
  switch (metricId) {
    case 'total': return a.totalMs / 60000;
    case 'count': return a.count;
    case 'avg': return a.avgMs === null ? null : a.avgMs / 60000;
    case 'longest': return a.longestMs === null ? null : a.longestMs / 60000;
    default: return null;
  }
}

export function metricText(metricId, a) {
  if (a.future) return 'هنوز نرسیده';
  if (metricId === 'count') return `${toFa(a.count)} جلسه`;
  if (metricId === 'total') return duration(a.totalMs);
  if (!a.count) return 'جلسه‌ای نیست';
  return duration(metricId === 'avg' ? a.avgMs : a.longestMs);
}

/** واحد محور: زمان‌های بزرگ به ساعت نمایش داده می‌شوند */
export function chooseUnit(metricId, values) {
  const m = METRICS.find((x) => x.id === metricId);
  if (!m.time) return { name: 'جلسه', div: 1, digits: 0 };
  const max = Math.max(0, ...values.filter((v) => Number.isFinite(v)));
  return max >= 600 ? { name: 'ساعت', div: 60, digits: 1 } : { name: 'دقیقه', div: 1, digits: 0 };
}

export const scaleValue = (v, unit) => {
  if (!Number.isFinite(v)) return null;
  const f = 10 ** unit.digits;
  return Math.round((v / unit.div) * f) / f;
};

/** ردیف‌های نمودار به ترتیب زمانی (قدیمی → جدید) */
export function chartRows(series, metricId) {
  const raw = [];
  const rows = series.cur.buckets.map((b, i) => {
    const pb = series.prev.buckets[i] ?? null; // ماه ۳۱ روزه در برابر ماه ۳۰ روزه: دسته‌ی نظیر ندارد
    const cur = metricValue(metricId, b);
    const prev = pb ? metricValue(metricId, pb) : null;
    raw.push(cur, prev);
    return { i, dow: weekdayIndex(b.start), label: b.label, full: b.full, curRaw: cur, prevRaw: prev, curText: metricText(metricId, b), prevText: pb ? metricText(metricId, pb) : 'ندارد', prevFull: pb ? pb.full : null, count: b.count };
  });
  // «۷ روز اخیر» یک بازه‌ی لغزان است و می‌تواند از هر روزی شروع شود؛ ردیف‌های نمودار/جدول آن
  // به ترتیب هفته (شنبه … جمعه) چیده می‌شوند. هر ردیف همچنان به تاریخ واقعی خودش (full) وصل است.
  if (series.range === 'day') rows.sort((a, b) => a.dow - b.dow);
  const unit = chooseUnit(metricId, raw);
  return { unit, rows: rows.map((r) => ({ ...r, cur: scaleValue(r.curRaw, unit), prev: scaleValue(r.prevRaw, unit) })) };
}

export const hasData = (period) => period.buckets.some((b) => !b.future && b.count > 0);

/** مقدار کل بازه: مجموع/تعداد/میانگین/بیشترین روی همه‌ی جلسه‌های بازه */
export const periodValue = (metricId, period) => metricValue(metricId, { ...period.all, future: false });

/** متن تغییر بازه‌ی جاری نسبت به قبلی */
export function changeText(metricId, series) {
  const a = periodValue(metricId, series.cur);
  const b = periodValue(metricId, series.prev);
  if (!Number.isFinite(a) || !Number.isFinite(b)) return 'قابل مقایسه نیست';
  const diff = metricId === 'count' ? a - b : Math.round(a) - Math.round(b);
  if (diff === 0) return 'بدون تغییر';
  const abs = Math.abs(diff);
  return `${metricId === 'count' ? `${toFa(abs)} جلسه` : duration(abs * 60000)} ${diff > 0 ? 'بیشتر' : 'کمتر'}`;
}
