// خروجی آمار برای پشتیبان‌گیری و تحلیل شخصی. فقط از جلسه‌های معتبر؛ ارقام لاتین تا در Excel و پایتون راحت خوانده شوند.
import { buildDayMap, cleanSessions } from './insights.js';
import { toJalali, weekdayName } from './jalali.js';
import { endOf } from './sessionRules.js';

const p2 = (n) => String(n).padStart(2, '0');
const jalaliText = (ts) => { const j = toJalali(ts); return `${j.jy}/${p2(j.jm)}/${p2(j.jd)}`; };
const isoDate = (ts) => { const d = new Date(ts); return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`; };
const clock = (ts) => { const d = new Date(ts); return `${p2(d.getHours())}:${p2(d.getMinutes())}`; };
const minutes = (ms) => Math.round((ms / 60000) * 100) / 100;

/** سلول CSV: جلوگیری از تزریق فرمول (=،+،-،@) و نقل‌قول‌گذاری درست */
export function csvCell(v) {
  let s = String(v ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export const CSV_HEADER = ['id', 'source', 'date_jalali', 'date_iso', 'weekday', 'start', 'end', 'planned_minutes', 'focused_minutes'];

export function sessionsToCsv(sessions) {
  const rows = cleanSessions(sessions).sort((a, b) => a.startedAt - b.startedAt).map((s) => [
    s.id, s.source === 'manual' ? 'manual' : 'timer', jalaliText(s.startedAt), isoDate(s.startedAt), weekdayName(s.startedAt),
    clock(s.startedAt), clock(endOf(s)), Number.isFinite(s.plannedMs) && s.plannedMs > 0 ? minutes(s.plannedMs) : '', minutes(s.focusedMs),
  ]);
  return '\ufeff' + [CSV_HEADER, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n') + '\r\n';
}

/** جمع روزانه (بدون جلسه‌های تک‌تک) برای تحلیل */
export function dailySummaryJson(sessions, now = Date.now()) {
  const days = [...buildDayMap(sessions).values()].sort((a, b) => a.ts - b.ts).map((d) => ({
    date_jalali: jalaliText(d.ts), date_iso: isoDate(d.ts), weekday: weekdayName(d.ts), sessions: d.count,
    focused_minutes: minutes(d.focusedMs), planned_minutes: d.plannedMs > 0 ? minutes(d.plannedMs) : null, sessions_without_plan: d.unplanned,
  }));
  return JSON.stringify({ exportedAt: new Date(now).toISOString(), days }, null, 2);
}
