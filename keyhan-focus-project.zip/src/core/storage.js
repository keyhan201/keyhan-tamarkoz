// لایه‌ی ذخیره‌سازی مشترک بین پاپ‌آپ، صفحه‌ی کامل و پس‌زمینه.
// در محیط افزونه از chrome.storage.local استفاده می‌شود؛ بیرون از آن (npm run dev) localStorage جایگزین است.
const ext = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
const EVT = 'kt-storage';

// پشتیبان ذخیره‌سازی قابل‌تعویض (اپ اندروید: Capacitor Preferences). بدون آن رفتار افزونه دست‌نخورده است.
let backend = null;
export const useBackend = (b) => { backend = b; };
const emit = (key, value) => window.dispatchEvent(new CustomEvent(EVT, { detail: { key, value } }));
/** وقتی بخش native مقداری را عوض کرده (اعلان/سرویس)، رابط دوباره از ذخیره‌سازی می‌خواند. */
export async function refreshKeys(keys, fallbacks = {}) {
  for (const key of keys) emit(key, await getItem(key, fallbacks[key]));
}

export async function getItem(key, fallback) {
  if (backend) {
    const v = await backend.get(key);
    return v === undefined || v === null ? fallback : v;
  }
  if (ext) {
    const r = await chrome.storage.local.get(key);
    return r[key] === undefined ? fallback : r[key];
  }
  try {
    const raw = localStorage.getItem('kt:' + key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

export async function setItem(key, value) {
  if (backend) {
    await backend.set(key, value);
    emit(key, value);
    return;
  }
  if (ext) {
    await chrome.storage.local.set({ [key]: value });
    return;
  }
  localStorage.setItem('kt:' + key, JSON.stringify(value));
  window.dispatchEvent(new CustomEvent(EVT, { detail: { key, value } }));
}

export function subscribe(key, cb) {
  if (backend) {
    const handler = (e) => { if (e.detail.key === key) cb(e.detail.value); };
    window.addEventListener(EVT, handler);
    return () => window.removeEventListener(EVT, handler);
  }
  if (ext) {
    const handler = (changes, area) => {
      if (area === 'local' && changes[key]) cb(changes[key].newValue);
    };
    chrome.storage.onChanged.addListener(handler);
    return () => chrome.storage.onChanged.removeListener(handler);
  }
  const handler = (e) => {
    if (e.detail.key === key) cb(e.detail.value);
  };
  window.addEventListener(EVT, handler);
  return () => window.removeEventListener(EVT, handler);
}

export async function removeItem(key) {
  if (backend) {
    await backend.remove(key);
    emit(key, undefined);
    return;
  }
  if (ext) {
    await chrome.storage.local.remove(key);
    return;
  }
  localStorage.removeItem('kt:' + key);
  window.dispatchEvent(new CustomEvent(EVT, { detail: { key, value: undefined } }));
}
