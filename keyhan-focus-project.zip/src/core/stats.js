// محاسبه‌ی آمار؛ فقط بر پایه‌ی جلسه‌های تایمر است و به کارهای روزانه ربطی ندارد.
export const dayKey = (ts) => {
  const d = new Date(ts);
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
};

/** آغاز n روز آخر (قدیمی‌ترین اول) */
export function lastDays(n, now = Date.now()) {
  const base = new Date(now);
  base.setHours(0, 0, 0, 0);
  const out = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(base);
    d.setDate(base.getDate() - i);
    out.push(d.getTime());
  }
  return out;
}

export function dailyTotals(sessions, n, now = Date.now()) {
  const days = lastDays(n, now);
  const map = new Map(days.map((t) => [dayKey(t), 0]));
  for (const s of sessions) {
    const k = dayKey(s.startedAt);
    if (map.has(k)) map.set(k, map.get(k) + s.focusedMs);
  }
  return days.map((ts) => ({ ts, ms: map.get(dayKey(ts)) }));
}

export function summarize(sessions, days, now = Date.now()) {
  const from = days ? lastDays(days, now)[0] : 0;
  const list = sessions.filter((s) => s.startedAt >= from);
  const totalMs = list.reduce((a, s) => a + s.focusedMs, 0);
  const longestMs = list.reduce((a, s) => Math.max(a, s.focusedMs), 0);
  return {
    totalMs,
    count: list.length,
    avgMs: list.length ? totalMs / list.length : 0,
    longestMs,
  };
}

export function todayMs(sessions, now = Date.now()) {
  const k = dayKey(now);
  return sessions.filter((s) => dayKey(s.startedAt) === k).reduce((a, s) => a + s.focusedMs, 0);
}

/** تعداد روزهای پیاپی که دست‌کم یک جلسه داشته‌اند (اگر امروز هنوز جلسه‌ای نیست از دیروز می‌شمارد) */
export function streak(sessions, now = Date.now()) {
  const keys = new Set(sessions.map((s) => dayKey(s.startedAt)));
  const d = new Date(now);
  d.setHours(0, 0, 0, 0);
  if (!keys.has(dayKey(d.getTime()))) d.setDate(d.getDate() - 1);
  let n = 0;
  while (keys.has(dayKey(d.getTime()))) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
}
