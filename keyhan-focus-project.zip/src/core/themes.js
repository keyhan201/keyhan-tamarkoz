// تم‌ها: رنگ تم‌های آماده فقط در styles/themes.css با متغیرهای CSS تعریف می‌شود.
// «تم اصلی» همان مقادیر :root در base.css است و هیچ override ای ندارد.
// تم شخصی از سه رنگ معتبر ساخته می‌شود (core/themeColors.js) و به‌صورت متغیر روی :root نوشته می‌شود.
import { getItem, subscribe } from './storage.js';
import { DEFAULT_SETTINGS, KEYS } from './constants.js';
import { CUSTOM_VAR_NAMES, deriveExtras, deriveVars, isDarkBackground, normalizeCustomThemes } from './themeColors.js';

export const THEMES = [
  { id: 'main', label: 'تم اصلی', mode: 'dark' },
  { id: 'navy', label: 'سرمه‌ای', mode: 'dark' },
  { id: 'violet', label: 'بنفش', mode: 'dark' },
  { id: 'forest', label: 'سبز جنگلی', mode: 'dark' },
  { id: 'ember', label: 'مسی', mode: 'dark' },
  { id: 'graphite', label: 'گرافیتی', mode: 'dark' },
  { id: 'light', label: 'روشن', mode: 'light' },
  { id: 'sand', label: 'شنی', mode: 'light' },
];

// رنگ نشان (badge) روی آیکون افزونه CSS نیست؛ این مقادیر فقط برای همان‌جا هستند.
export const BADGE_COLORS = {
  main: { running: '#F1D28B', paused: '#5B6490', text: '#0D1124' },
  navy: { running: '#7CC4F5', paused: '#4F6A8A', text: '#07142B' },
  violet: { running: '#C9A6FF', paused: '#6E5A99', text: '#160D2B' },
  forest: { running: '#8FD6A4', paused: '#4F7A63', text: '#08180F' },
  ember: { running: '#FF9F6B', paused: '#8A5A48', text: '#2A0F06' },
  graphite: { running: '#E0E0E0', paused: '#6A6A6A', text: '#121212' },
  light: { running: '#2F5BD9', paused: '#8A93AD', text: '#FFFFFF' },
  sand: { running: '#B4571B', paused: '#9A8B72', text: '#FFFFFF' },
};

// رنگ‌های اعلان داخل صفحه‌ی سایت (Shadow DOM): متغیرهای CSS افزونه آنجا در دسترس نیست،
// پس مقدارها از themes.css / base.css اینجا هم‌خوان نگه داشته می‌شوند.
export const OVERLAY_COLORS = {
  main: { surface: '#151b35', line: '#262e50', ink: '#e9ebf7', muted: '#8d96bb', accent: '#f1d28b', accentSoft: 'rgba(241, 210, 139, 0.16)', onAccent: '#0d1124' },
  navy: { surface: '#0f2038', line: '#223a5c', ink: '#e6f0fb', muted: '#8fa8c6', accent: '#7cc4f5', accentSoft: 'rgba(124, 196, 245, 0.18)', onAccent: '#07142b' },
  violet: { surface: '#1f1438', line: '#3a2a63', ink: '#f0eafd', muted: '#a99bcf', accent: '#c9a6ff', accentSoft: 'rgba(201, 166, 255, 0.18)', onAccent: '#160d2b' },
  forest: { surface: '#12261c', line: '#25402f', ink: '#e7f3ec', muted: '#8fb09c', accent: '#8fd6a4', accentSoft: 'rgba(143, 214, 164, 0.18)', onAccent: '#08180f' },
  ember: { surface: '#261613', line: '#4a2d26', ink: '#f7ebe6', muted: '#c0a095', accent: '#ff9f6b', accentSoft: 'rgba(255, 159, 107, 0.18)', onAccent: '#2a0f06' },
  graphite: { surface: '#1b1b1b', line: '#333333', ink: '#ececec', muted: '#9a9a9a', accent: '#e0e0e0', accentSoft: 'rgba(224, 224, 224, 0.16)', onAccent: '#121212' },
  light: { surface: '#ffffff', line: '#d3d8e8', ink: '#1b2140', muted: '#5c6585', accent: '#2f5bd9', accentSoft: 'rgba(47, 91, 217, 0.14)', onAccent: '#ffffff' },
  sand: { surface: '#fffaf0', line: '#dccfb8', ink: '#2d2619', muted: '#6e6350', accent: '#b4571b', accentSoft: 'rgba(180, 87, 27, 0.14)', onAccent: '#ffffff' },
};

const isBuiltin = (id) => THEMES.some((t) => t.id === id);

/** شناسه‌ی تم معتبر: تم آماده، یا یکی از تم‌های شخصی ذخیره‌شده؛ در غیر این صورت تم اصلی. */
export function themeIdOf(id, customThemes = []) {
  if (isBuiltin(id)) return id;
  if (typeof id === 'string' && normalizeCustomThemes(customThemes).some((t) => t.id === id)) return id;
  return DEFAULT_SETTINGS.theme;
}

/** از روی تنظیمات: { id, custom (تم شخصی یا null), badge, overlay } — برای service worker هم استفاده می‌شود. */
export function resolveTheme(settings) {
  const s = settings || {};
  const customs = normalizeCustomThemes(s.customThemes);
  const id = themeIdOf(s.theme, customs);
  const custom = customs.find((t) => t.id === id) || null;
  if (custom) return { id, custom, ...deriveExtras(custom) };
  return { id, custom: null, badge: BADGE_COLORS[id], overlay: OVERLAY_COLORS[id] };
}

export function applyTheme(settings) {
  const root = document.documentElement;
  const { id, custom } = resolveTheme(settings);
  for (const name of CUSTOM_VAR_NAMES) root.style.removeProperty(name);
  if (custom) {
    root.setAttribute('data-theme', 'custom');
    for (const [k, v] of Object.entries(deriveVars(custom))) root.style.setProperty(k, v);
    root.style.colorScheme = isDarkBackground(custom.bg) ? 'dark' : 'light';
  } else {
    root.style.removeProperty('color-scheme');
    if (id === 'main') root.removeAttribute('data-theme');
    else root.setAttribute('data-theme', id);
  }
}

/** تم ذخیره‌شده را اعمال می‌کند و با تغییر تنظیمات (از هر صفحه‌ای) هم‌گام می‌ماند. */
export async function initTheme() {
  try {
    applyTheme(await getItem(KEYS.settings, {}));
  } catch {
    applyTheme({});
  }
  subscribe(KEYS.settings, (s) => applyTheme(s));
}
