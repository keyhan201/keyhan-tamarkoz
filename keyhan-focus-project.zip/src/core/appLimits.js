// محدودیت برنامه‌های منتخب هنگام تمرکز (اندروید). این‌جا فقط «تصمیم» و اعتبارسنجی است؛
// تشخیص برنامه‌ی جلوی صفحه در بخش native انجام می‌شود (UsageStatsManager) و همین قواعد را تکرار می‌کند.
export const SELF_PACKAGE = 'com.keyhan.tamarkoz';
export const MAX_LIMITED_APPS = 30;
export const WARN_COOLDOWN_MS = 20 * 1000; // پشت‌سرهم هشدار نده
const PKG_RE = /^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$/;

/** فقط نام بسته‌ی معتبر، بدون تکرار، بدون خود اپ، با سقف. */
export function normalizePackages(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  for (const v of list) {
    if (typeof v !== 'string' || v.length > 200 || !PKG_RE.test(v) || v === SELF_PACKAGE || out.includes(v)) continue;
    out.push(v);
    if (out.length >= MAX_LIMITED_APPS) break;
  }
  return out;
}

export function togglePackage(list, pkg) {
  const cur = normalizePackages(list);
  if (cur.includes(pkg)) return cur.filter((p) => p !== pkg);
  return normalizePackages([...cur, pkg]);
}

/**
 * آیا الان باید هشدار داد؟ فقط وقتی: قابلیت روشن است، «تمرکز» در حال اجراست (نه استراحت/توقف)،
 * برنامه‌ی جلوی صفحه جزو انتخاب‌های خود کاربر است و از آخرین هشدار فاصله گذشته.
 */
export function shouldWarn({ timer, settings, foreground, now = Date.now(), lastWarnAt = 0 }) {
  if (!settings || settings.limitEnabled !== true) return false;
  if (!timer || timer.status !== 'running' || timer.kind === 'break') return false;
  if (typeof foreground !== 'string' || foreground === SELF_PACKAGE) return false;
  if (!normalizePackages(settings.limitedApps).includes(foreground)) return false;
  return now - lastWarnAt >= WARN_COOLDOWN_MS;
}

// ---- حالت محدودسازی (blockMode) ----
// اندروید به برنامه‌ی عادی اجازه‌ی بستن/مسدودکردن برنامه‌های دیگر را نمی‌دهد. نزدیک‌ترین راهکار مجاز:
// اگر برنامه‌ی «غیرایمن» جلوی صفحه آمد، کاربر به اپ تمرکز برگردانده می‌شود (نیاز به Usage Access و «نمایش روی برنامه‌های دیگر»).
// این برنامه‌ها هرگز برگردانده نمی‌شوند: تلفن/تماس، تنظیمات سیستم، نوار سیستم، صفحه‌ی اصلی و اضطراری. (بخش native فهرست پویا هم اضافه می‌کند.)
export const SAFE_PACKAGES = [
  'android', 'com.android.systemui', 'com.android.settings', 'com.android.phone', 'com.android.server.telecom',
  'com.android.incallui', 'com.android.emergency', 'com.android.dialer', 'com.google.android.dialer',
  'com.samsung.android.dialer', 'com.samsung.android.incallui', 'com.android.permissioncontroller',
  'com.google.android.permissioncontroller', 'com.google.android.apps.nexuslauncher', 'com.android.launcher3',
  'com.sec.android.app.launcher', 'com.miui.home', 'com.huawei.android.launcher', 'com.oneplus.launcher', 'com.oppo.launcher',
];
export const BOUNCE_COOLDOWN_MS = 2000;
export const NOTE_BLOCK = 'مسدودسازی واقعی نیست؛ فقط برگرداندن به اپ تمرکز است.';

export function shouldBounce({ timer, settings, foreground, safe = [], now = Date.now(), lastBounceAt = 0 }) {
  if (!settings || settings.blockMode !== true) return false;
  if (!timer || timer.status !== 'running' || timer.kind === 'break') return false; // فقط وسط تمرکز، نه استراحت/توقف
  if (typeof foreground !== 'string' || foreground === SELF_PACKAGE) return false;
  if (SAFE_PACKAGES.includes(foreground) || safe.includes(foreground)) return false;
  return now - lastBounceAt >= BOUNCE_COOLDOWN_MS;
}
