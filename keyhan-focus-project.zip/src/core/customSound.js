// صدای هشدار بارگذاری‌شده توسط کاربر. فقط فرمت‌هایی پذیرفته می‌شوند که امضای (magic bytes) واقعی‌شان با نوع ادعاشده می‌خواند؛
// پسوند نام فایل و نوع MIME مرورگر به‌تنهایی مورد اعتماد نیست. همه‌چیز در یک کلید جدا در chrome.storage.local می‌ماند
// (نه داخل تنظیمات) تا هر تغییر تنظیمات حجم صدا را جابه‌جا نکند.
import { KEYS } from './constants.js';
import { getItem, removeItem, setItem } from './storage.js';

export const MAX_SOUND_BYTES = 1024 * 1024; // ۱ مگابایت
export const MAX_SOUND_SECONDS = 15;

export const SOUND_FORMATS = [
  { id: 'mp3', label: 'MP3', mime: 'audio/mpeg', probe: 'audio/mpeg' },
  { id: 'wav', label: 'WAV', mime: 'audio/wav', probe: 'audio/wav' },
  { id: 'ogg', label: 'OGG', mime: 'audio/ogg', probe: 'audio/ogg' },
  { id: 'm4a', label: 'M4A (AAC)', mime: 'audio/mp4', probe: 'audio/mp4' },
  { id: 'webm', label: 'WebM', mime: 'audio/webm', probe: 'audio/webm' },
];
const MIMES = new Set(SOUND_FORMATS.map((f) => f.mime));
const M4A_BRANDS = ['M4A ', 'M4B ', 'mp42', 'mp41', 'isom', 'iso2', 'F4A '];

const ascii = (b, from, len) => String.fromCharCode(...b.slice(from, from + len));

/** نوع واقعی فایل از روی بایت‌های ابتدایی؛ ناشناخته → null */
export function sniffFormat(bytes) {
  const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
  if (b.length < 12) return null;
  if (ascii(b, 0, 3) === 'ID3' || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0 && (b[1] & 0x06) !== 0)) return 'mp3';
  if (ascii(b, 0, 4) === 'RIFF' && ascii(b, 8, 4) === 'WAVE') return 'wav';
  if (ascii(b, 0, 4) === 'OggS') return 'ogg';
  if (ascii(b, 4, 4) === 'ftyp' && M4A_BRANDS.includes(ascii(b, 8, 4))) return 'm4a';
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return 'webm';
  return null;
}

/** فرمت‌هایی که همین مرورگر واقعاً پخش می‌کند (canPlayType)؛ برای اعلام در رابط. */
export function supportedFormats(audio) {
  const a = audio || (typeof Audio !== 'undefined' ? new Audio() : null);
  if (!a || !a.canPlayType) return SOUND_FORMATS;
  return SOUND_FORMATS.filter((f) => a.canPlayType(f.probe) !== '');
}

export const displayName = (name) =>
  String(name || 'صدای من').split(/[\\/]/).pop().replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, 40) || 'صدای من';

/** بررسی اولیه (بدون پخش): اندازه و امضای فایل. خروجی { ok, format } یا { ok:false, error } */
export function validateSoundFile({ size, name }, bytes, allowed = SOUND_FORMATS) {
  if (!Number.isFinite(size) || size <= 0) return { ok: false, error: 'فایل خالی است.' };
  if (size > MAX_SOUND_BYTES) return { ok: false, error: `حجم فایل نباید بیش از ${Math.round(MAX_SOUND_BYTES / 1024 / 1024)} مگابایت باشد.` };
  const id = sniffFormat(bytes);
  const fmt = SOUND_FORMATS.find((f) => f.id === id);
  if (!fmt) return { ok: false, error: `قالب فایل پشتیبانی نمی‌شود. فقط ${allowed.map((f) => f.label).join('، ')} قابل استفاده است.` };
  if (!allowed.some((f) => f.id === fmt.id)) return { ok: false, error: `مرورگر شما قالب ${fmt.label} را پخش نمی‌کند.` };
  return { ok: true, format: fmt, name: displayName(name) };
}

export const checkDuration = (seconds) => {
  if (!Number.isFinite(seconds) || seconds <= 0) return { ok: false, error: 'مدت فایل خوانده نشد؛ فایل سالم نیست.' };
  if (seconds > MAX_SOUND_SECONDS) return { ok: false, error: `مدت صدا نباید بیش از ${MAX_SOUND_SECONDS} ثانیه باشد.` };
  return { ok: true };
};

export function bytesToBase64(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i += 0x8000) out += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(out);
}
export const base64ToBytes = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));

const B64 = /^[A-Za-z0-9+/]+={0,2}$/;
const MAX_B64 = Math.ceil((MAX_SOUND_BYTES * 4) / 3) + 8;

/** شکل ذخیره‌شده را قبل از هر پخش بررسی می‌کند (داده‌ی خراب یا دست‌کاری‌شده هرگز پخش نمی‌شود). */
export function validStoredSound(v) {
  if (!v || typeof v !== 'object') return null;
  if (typeof v.mime !== 'string' || !MIMES.has(v.mime)) return null;
  if (typeof v.data !== 'string' || v.data.length === 0 || v.data.length > MAX_B64 || !B64.test(v.data)) return null;
  const seconds = Number(v.duration);
  if (!checkDuration(seconds).ok) return null;
  return { name: displayName(v.name), mime: v.mime, data: v.data, duration: seconds, size: Number.isFinite(v.size) ? v.size : 0 };
}

export async function getCustomSound() {
  try {
    return validStoredSound(await getItem(KEYS.customSound, null));
  } catch {
    return null;
  }
}

/** ذخیره؛ خطای حافظه به پیام فارسی تبدیل می‌شود. */
export async function saveCustomSound({ name, mime, bytes, duration }) {
  const entry = { name: displayName(name), mime, data: bytesToBase64(bytes), duration, size: bytes.length, savedAt: Date.now() };
  if (!validStoredSound(entry)) return { ok: false, error: 'فایل معتبر نیست.' };
  try {
    await setItem(KEYS.customSound, entry);
    return { ok: true, sound: validStoredSound(entry) };
  } catch (e) {
    const quota = /quota/i.test(String(e && e.message));
    return { ok: false, error: quota ? 'فضای ذخیره‌سازی افزونه پر است. صدای دیگری را حذف کنید یا فایل کوچک‌تری بگیرید.' : 'ذخیره‌ی صدا انجام نشد. دوباره تلاش کنید.' };
  }
}

export const removeCustomSound = () => removeItem(KEYS.customSound);
