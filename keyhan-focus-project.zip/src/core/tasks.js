// To-Do ساده؛ هیچ ارتباطی با تایمر و آمار ندارد.
export const addTask = (list, text) => [
  ...list,
  { id: crypto.randomUUID(), text: text.trim(), done: false, createdAt: Date.now() },
];
export const toggleTask = (list, id) => list.map((t) => (t.id === id ? { ...t, done: !t.done } : t));
export const removeTask = (list, id) => list.filter((t) => t.id !== id);
export const clearDone = (list) => list.filter((t) => !t.done);
