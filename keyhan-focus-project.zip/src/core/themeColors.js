// تم شخصی: فقط سه رنگ hex شش‌رقمی پذیرفته می‌شود و همه‌ی متغیرهای CSS از آن‌ها محاسبه می‌شوند.
// هیچ رشته‌ی CSS آزادی از کاربر نه ذخیره می‌شود و نه روی صفحه اعمال می‌شود.
const HEX = /^#[0-9a-fA-F]{6}$/;
export const MAX_CUSTOM_THEMES = 6;
export const MAX_THEME_NAME = 24;
export const CUSTOM_ID = /^custom-[0-9a-f-]{8,40}$/;
export const MIN_TEXT_CONTRAST = 4.5;
export const MIN_ACCENT_CONTRAST = 3;

export const isHex = (v) => typeof v === 'string' && HEX.test(v);
const rgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const hex = (c) => '#' + c.map((v) => Math.round(Math.min(255, Math.max(0, v))).toString(16).padStart(2, '0')).join('');
const mix = (a, b, t) => { const x = rgb(a); const y = rgb(b); return hex(x.map((v, i) => v * (1 - t) + y[i] * t)); };
const rgba = (h, a) => `rgba(${rgb(h).join(', ')}, ${a})`;

export function luminance(h) {
  const [r, g, b] = rgb(h).map((v) => { const s = v / 255; return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4; });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export function contrast(a, b) {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

export const isDarkBackground = (bg) => luminance(bg) < 0.35;

/** ورودی: { name, accent, bg, ink } → { ok: true, theme } یا { ok: false, field, error } */
export function validateCustomTheme(input) {
  const t = input && typeof input === 'object' ? input : {};
  const name = typeof t.name === 'string' ? t.name.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim() : '';
  if (!name) return { ok: false, field: 'name', error: 'برای تم یک نام بنویسید.' };
  if (name.length > MAX_THEME_NAME) return { ok: false, field: 'name', error: `نام تم نباید از ${MAX_THEME_NAME} نویسه بیشتر باشد.` };
  for (const [field, label] of [['accent', 'رنگ تأکیدی'], ['bg', 'رنگ پس‌زمینه'], ['ink', 'رنگ متن']]) {
    if (!isHex(t[field])) return { ok: false, field, error: `${label} معتبر نیست.` };
  }
  const theme = { name, accent: t.accent.toLowerCase(), bg: t.bg.toLowerCase(), ink: t.ink.toLowerCase() };
  if (contrast(theme.ink, theme.bg) < MIN_TEXT_CONTRAST) {
    return { ok: false, field: 'ink', error: 'تضاد رنگ متن و پس‌زمینه کم است و خواندن سخت می‌شود. رنگ‌ها را از هم دورتر کنید.' };
  }
  if (contrast(theme.accent, theme.bg) < MIN_ACCENT_CONTRAST) {
    return { ok: false, field: 'accent', error: 'رنگ تأکیدی روی این پس‌زمینه کم‌رنگ است و وضعیت اجرا/توقف دیده نمی‌شود.' };
  }
  return { ok: true, theme };
}

/** فهرست ذخیره‌شده را پاک‌سازی می‌کند (شناسه‌ی معتبر، بی‌تکرار، رنگ‌های معتبر، سقف تعداد). */
export function normalizeCustomThemes(list) {
  if (!Array.isArray(list)) return [];
  const seen = new Set();
  const out = [];
  for (const raw of list) {
    if (!raw || typeof raw.id !== 'string' || !CUSTOM_ID.test(raw.id) || seen.has(raw.id)) continue;
    const v = validateCustomTheme(raw);
    if (!v.ok) continue;
    seen.add(raw.id);
    out.push({ id: raw.id, ...v.theme });
  }
  return out.slice(0, MAX_CUSTOM_THEMES);
}

export const newCustomId = () => `custom-${globalThis.crypto.randomUUID()}`;

/** همه‌ی متغیرهایی که یک تم شخصی روی :root می‌نویسد (فقط رنگ hex/rgba محاسبه‌شده). */
export function deriveVars({ accent, bg, ink }) {
  const dark = isDarkBackground(bg);
  const onStar = contrast(accent, '#0d1124') >= contrast(accent, '#ffffff') ? '#0d1124' : '#ffffff';
  return {
    '--night': bg,
    '--night-2': mix(bg, ink, 0.06),
    '--night-3': mix(bg, ink, 0.12),
    '--line': mix(bg, ink, 0.2),
    '--ink': ink,
    '--mute': mix(ink, bg, 0.32),
    '--star': accent,
    '--star-dim': rgba(accent, 0.14),
    '--star-line': rgba(accent, 0.38),
    '--danger': dark ? '#f0959b' : '#c0392b',
    '--bar-today': mix(accent, bg, 0.5),
    '--scrim': dark ? 'rgba(4, 6, 14, 0.62)' : rgba(ink, 0.35),
    '--on-star': onStar,
  };
}
export const CUSTOM_VAR_NAMES = Object.keys(deriveVars({ accent: '#000000', bg: '#000000', ink: '#000000' }));

/** رنگ‌های اعلان داخل صفحه‌ی سایت و نشان آیکون برای تم شخصی */
export function deriveExtras(theme) {
  const v = deriveVars(theme);
  return {
    overlay: { surface: v['--night-2'], line: v['--line'], ink: v['--ink'], muted: v['--mute'], accent: v['--star'], accentSoft: rgba(theme.accent, 0.16), onAccent: v['--on-star'] },
    badge: { running: theme.accent, paused: mix(theme.ink, theme.bg, 0.5), text: v['--on-star'] },
  };
}
