// بازیابی از فایل پشتیبانی که همین افزونه می‌سازد: { exportedAt, sessions, tasks, settings }.
// فرمت و ساختار داده‌ها تغییر نمی‌کند؛ فقط اعتبارسنجی می‌شود و در همان کلیدهای فعلی نوشته می‌شود.
// وضعیت تایمر هیچ‌وقت خوانده یا نوشته نمی‌شود.
import { DEFAULT_SETTINGS, KEYS, MAX_BREAK_MINUTES, MAX_MINUTES, MIN_BREAK_MINUTES, MIN_MINUTES } from './constants.js';
import { normalizeCustomMinutes } from './durations.js';
import { uniqueSessions } from './sessionRules.js';
import { normalizePackages } from './appLimits.js';
import { getItem, setItem } from './storage.js';
import { soundIdOf } from './sounds.js';
import { themeIdOf } from './themes.js';
import { normalizeCustomThemes } from './themeColors.js';
import { withLock } from './timerService.js';

export const MAX_BACKUP_BYTES = 10 * 1024 * 1024;

const fin = (v) => typeof v === 'number' && Number.isFinite(v);
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const hasId = (v) => (typeof v === 'string' && v !== '') || fin(v);
const fail = (error) => ({ ok: false, error });

const goodSession = (s) =>
  isObj(s) && hasId(s.id) && fin(s.startedAt) && fin(s.focusedMs) && s.focusedMs > 0 &&
  (s.endedAt === undefined || s.endedAt === null || fin(s.endedAt));

const goodTask = (t) => isObj(t) && hasId(t.id) && typeof t.text === 'string' && t.text.trim() !== '' && typeof t.done === 'boolean';

function cleanSettings(raw) {
  const out = {};
  for (const key of Object.keys(DEFAULT_SETTINGS)) {
    if (!(key in raw)) continue;
    const v = raw[key];
    const def = DEFAULT_SETTINGS[key];
    // حالت محدودسازی و پنجره‌ی پایان جلسه هرگز از فایل بازیابی نمی‌شوند: فعال‌شدنشان همیشه باید رضایت و مجوز همین دستگاه را بگیرد
    if (key === 'blockMode' || key === 'endOverlay') continue; // endOverlay هم به مجوز همین دستگاه وابسته است
    if (key === 'customThemes') out.customThemes = normalizeCustomThemes(v);
    else if (key === 'theme') out.theme = themeIdOf(v, raw.customThemes);
    // فایل صوتی کاربر در پشتیبان نیست؛ پس «صدای من» به دینگ برمی‌گردد
    else if (key === 'soundId') out.soundId = v === 'custom' ? 'ding' : soundIdOf(v);
    else if (key === 'customMinutes') out.customMinutes = normalizeCustomMinutes(v);
    else if (key === 'limitedApps') out.limitedApps = normalizePackages(v);
    else if (key === 'extendMinutes') {
      if (Number.isInteger(v) && v >= MIN_BREAK_MINUTES && v <= MAX_BREAK_MINUTES) out.extendMinutes = v;
    } else if (key === 'breakMinutes') {
      if (Number.isInteger(v) && v >= MIN_BREAK_MINUTES && v <= MAX_BREAK_MINUTES) out.breakMinutes = v;
    } else if (key === 'defaultMinutes') {
      if (Number.isInteger(v) && v >= MIN_MINUTES && v <= MAX_MINUTES) out.defaultMinutes = v;
    } else if (typeof v === typeof def) out[key] = v;
  }
  return out;
}

/** متن فایل را بررسی می‌کند. خروجی: { ok, error } یا { ok, data, summary } */
export function parseBackup(text, { tasks: withTasks = true } = {}) {
  if (typeof text !== 'string' || text.trim() === '') return fail('فایل خالی است.');
  if (text.length > MAX_BACKUP_BYTES) return fail('حجم فایل بیش از حد مجاز است.');
  let root;
  try {
    root = JSON.parse(text);
  } catch {
    return fail('این فایل JSON معتبر نیست.');
  }
  if (!isObj(root) || !['sessions', 'tasks', 'settings'].some((k) => k in root)) {
    return fail('این فایل، پشتیبان کیهان تمرکز نیست.');
  }
  if ('sessions' in root && !Array.isArray(root.sessions)) return fail('بخش جلسه‌های فایل معتبر نیست.');
  if (withTasks && 'tasks' in root && !Array.isArray(root.tasks)) return fail('بخش کارهای فایل معتبر نیست.');
  if ('settings' in root && !isObj(root.settings)) return fail('بخش تنظیمات فایل معتبر نیست.');

  const data = {};
  const summary = { sessions: 0, tasks: 0, settings: false, skipped: 0 };
  if (root.sessions) {
    const good = uniqueSessions(root.sessions.filter(goodSession));
    data.sessions = good;
    summary.sessions = good.length;
    summary.skipped += root.sessions.length - good.length;
  }
  // اپ اندروید بخش «کارهای روزانه» ندارد: tasks در فایل بدون خطا نادیده گرفته می‌شود (نه نمایش، نه ذخیره)
  if (withTasks && root.tasks) {
    const seen = new Set();
    const good = root.tasks.filter((t) => goodTask(t) && !seen.has(String(t.id)) && seen.add(String(t.id)));
    data.tasks = good;
    summary.tasks = good.length;
    summary.skipped += root.tasks.length - good.length;
  }
  if (root.settings) {
    data.settings = cleanSettings(root.settings);
    summary.settings = Object.keys(data.settings).length > 0;
  }
  if (!summary.sessions && !summary.tasks && !summary.settings && !('sessions' in data) && !('tasks' in data)) {
    return fail('در این فایل داده‌ای برای بازیابی نیست.');
  }
  return { ok: true, data, summary };
}

/** داده‌های اعتبارسنجی‌شده را جایگزین جلسه‌ها و کارها می‌کند و تنظیمات را روی تنظیمات فعلی می‌نشاند. */
export function restoreBackup(data) {
  return withLock(async () => {
    if (data.sessions) await setItem(KEYS.sessions, data.sessions);
    if (data.tasks) await setItem(KEYS.tasks, data.tasks);
    if (data.settings && Object.keys(data.settings).length) {
      await setItem(KEYS.settings, { ...(await getItem(KEYS.settings, {})), ...data.settings });
    }
  });
}
