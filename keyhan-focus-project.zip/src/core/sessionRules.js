// قواعد مشترک جلسه‌ها (تایمر و دستی در یک آرایه‌ی واحد ذخیره می‌شوند؛ هر جلسه فقط یک‌بار شمرده می‌شود).
export const MANUAL_MAX_MS = 12 * 60 * 60 * 1000;

export const isManual = (s) => Boolean(s) && s.source === 'manual';

const fin = (v) => typeof v === 'number' && Number.isFinite(v);

/** جلسه‌ی قابل‌شمارش: کامل‌شده، شروع و مدت معتبر، و اگر پایان دارد بعد از شروع باشد. */
export function validSession(s) {
  if (!s || typeof s !== 'object') return false;
  if (s.completed === false) return false;
  if (!fin(s.startedAt) || !fin(s.focusedMs) || s.focusedMs <= 0) return false;
  if (s.endedAt !== undefined && s.endedAt !== null && !(fin(s.endedAt) && s.endedAt > s.startedAt)) return false;
  return true;
}

/** زمان پایان؛ برای داده‌های قدیمی بدون endedAt از شروع + مدت ساخته می‌شود. */
export const endOf = (s) => (fin(s.endedAt) ? s.endedAt : s.startedAt + s.focusedMs);

/** حذف تکراری‌ها بر اساس id (نخستین مورد می‌ماند) */
export function uniqueSessions(list) {
  const seen = new Set();
  const out = [];
  for (const s of Array.isArray(list) ? list : []) {
    if (!s || typeof s !== 'object') continue;
    const id = String(s.id);
    if (seen.has(id)) continue;
    seen.add(id);
    out.push(s);
  }
  return out;
}
