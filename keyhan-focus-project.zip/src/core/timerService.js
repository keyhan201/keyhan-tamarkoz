// منطق تایمر: فقط وضعیت را در storage می‌نویسد. زمان همیشه از timestamp حساب می‌شود
// (setInterval فقط برای رندر دوباره است)، پس بستن پاپ‌آپ یا مرورگر چیزی را از بین نمی‌برد.
import {
  DEFAULT_SETTINGS,
  MAX_BREAK_MINUTES,
  MIN_BREAK_MINUTES,
  IDLE_TIMER,
  KEYS,
  MAX_MINUTES,
  MIN_MINUTES,
  NOTICE_MAX_DELAY_MS,
  SOUND_MAX_DELAY_MS,
  STOP_WINDOW_MS,
} from './constants.js';
import { soundIdOf } from './sounds.js';
import { getItem, setItem } from './storage.js';

const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);
const STATUSES = ['idle', 'running', 'paused'];

/**
 * هر مقداری که از storage بیاید (از جمله نسخه‌ی قدیمی بر پایه‌ی میلی‌ثانیه یا داده‌ی خراب)
 * به یک وضعیت معتبر تبدیل می‌شود. خروجی هیچ‌وقت NaN/undefined ندارد.
 */
export function normalizeTimer(raw) {
  const t = raw && typeof raw === 'object' ? raw : {};
  const lastResult =
    t.lastResult && num(t.lastResult.minutes) !== null && num(t.lastResult.at) !== null
      ? {
          minutes: t.lastResult.minutes,
          at: t.lastResult.at,
          sessionId: t.lastResult.sessionId != null ? String(t.lastResult.sessionId) : null,
          // شناسه‌ی صدایی که باید پخش شود؛ null یعنی صدایی پخش نشود
          sound: typeof t.lastResult.sound === 'string' ? t.lastResult.sound : null,
          // آیا اعلان بصری برای این جلسه مجاز است (پایان به‌موقع و جلسه‌ی تازه)؟ مستقل از صدا
          notice: t.lastResult.notice === true,
          kind: t.lastResult.kind === 'break' ? 'break' : 'focus',
        }
      : null;

  const oldMs = num(t.durationMs);
  const durationSeconds = Math.max(0, Math.floor(num(t.durationSeconds) ?? (oldMs !== null ? oldMs / 1000 : 0)));
  const startedAt = num(t.startedAt) || null;
  const rawId = t.sessionId ?? t.id;
  const sessionId = rawId !== undefined && rawId !== null && rawId !== '' ? String(rawId) : null;
  const status = STATUSES.includes(t.status) ? t.status : 'idle';
  const kind = t.kind === 'break' ? 'break' : 'focus';

  if (status === 'idle' || durationSeconds === 0 || !startedAt) {
    const d = durationSeconds || IDLE_TIMER.durationSeconds;
    return { ...IDLE_TIMER, durationSeconds: d, remainingSeconds: d, lastResult };
  }

  if (status === 'running') {
    const endsAt = num(t.endsAt) || startedAt + durationSeconds * 1000;
    return {
      status,
      kind,
      durationSeconds,
      remainingSeconds: Math.min(durationSeconds, Math.max(0, Math.ceil(num(t.remainingSeconds) ?? durationSeconds))),
      startedAt,
      endsAt,
      gracePeriodEndsAt: num(t.gracePeriodEndsAt) ?? startedAt + STOP_WINDOW_MS,
      graceRemainingMs: null,
      sessionId: sessionId ?? String(startedAt),
      lastResult: null,
    };
  }

  // paused
  const oldRemMs = num(t.remainingMs);
  const rem = num(t.remainingSeconds) ?? (oldRemMs !== null ? Math.ceil(oldRemMs / 1000) : durationSeconds);
  const remainingSeconds = Math.min(durationSeconds, Math.max(0, Math.ceil(rem)));
  const graceFallback = STOP_WINDOW_MS - (durationSeconds - remainingSeconds) * 1000;
  return {
    status,
    kind,
    durationSeconds,
    remainingSeconds,
    startedAt,
    endsAt: num(t.endsAt) || null,
    gracePeriodEndsAt: null,
    graceRemainingMs: Math.min(STOP_WINDOW_MS, Math.max(0, num(t.graceRemainingMs) ?? graceFallback)),
    sessionId: sessionId ?? String(startedAt),
    lastResult: null,
  };
}

export const remainingMsOf = (t, now = Date.now()) =>
  t.status === 'running' ? Math.max(0, t.endsAt - now) : t.status === 'paused' ? t.remainingSeconds * 1000 : 0;

/** فقط تا قبل از پایان ۱۰ ثانیه‌ی اول (بر پایه‌ی timestamp شروع) می‌شود توقف یا انصراف داد. */
export function canInterrupt(t, now = Date.now()) {
  if (t.kind === 'break') return t.status !== 'idle'; // استراحت را هر زمان می‌شود رد کرد
  if (t.status === 'running') return now < t.gracePeriodEndsAt;
  if (t.status === 'paused') return t.graceRemainingMs > 0; // بازه در توقف منجمد است
  return false;
}

export const getTimer = async () => normalizeTimer(await getItem(KEYS.timer, IDLE_TIMER));
const setTimer = (t) => setItem(KEYS.timer, normalizeTimer(t));

export async function getSettings() {
  return { ...DEFAULT_SETTINGS, ...(await getItem(KEYS.settings, {})) };
}

async function idleState(lastResult = null) {
  const { defaultMinutes } = await getSettings();
  const m = Number.isFinite(defaultMinutes) && defaultMinutes >= MIN_MINUTES ? Math.min(defaultMinutes, MAX_MINUTES) : 25;
  return { ...IDLE_TIMER, durationSeconds: m * 60, remainingSeconds: m * 60, lastResult };
}

// پاپ‌آپ و service worker هم‌زمان به تایمر دست می‌زنند؛ قفل مرورگر (Web Locks) بین همه‌ی آن‌ها مشترک است.
export function withLock(fn) {
  const locks = typeof navigator !== 'undefined' && navigator.locks;
  return locks && locks.request ? locks.request('kt-timer', fn) : fn();
}

export function startTimer(minutes, now = Date.now()) {
  return withLock(async () => {
    if (!Number.isFinite(minutes) || minutes < MIN_MINUTES || minutes > MAX_MINUTES) return false;
    const durationSeconds = Math.floor(minutes) * 60;
    await setTimer({
      status: 'running',
      kind: 'focus',
      durationSeconds,
      remainingSeconds: durationSeconds,
      startedAt: now,
      endsAt: now + durationSeconds * 1000,
      gracePeriodEndsAt: now + STOP_WINDOW_MS,
      graceRemainingMs: null,
      sessionId: `${now}-${Math.random().toString(36).slice(2, 8)}`,
      lastResult: null,
    });
    return true;
  });
}

/** استراحت: تایمر جداگانه با همان ساختار؛ جلسه‌ی تمرکز ثبت نمی‌شود و به باغ/آمار چیزی نمی‌افزاید. */
export function startBreak(minutes, now = Date.now()) {
  return withLock(async () => {
    if (!Number.isInteger(minutes) || minutes < MIN_BREAK_MINUTES || minutes > MAX_BREAK_MINUTES) return false;
    const t = await getTimer();
    if (t.kind !== 'break' && (t.status === 'running' || t.status === 'paused')) return false; // وسط تمرکز استراحت شروع نمی‌شود
    const durationSeconds = minutes * 60;
    await setTimer({
      status: 'running',
      kind: 'break',
      durationSeconds,
      remainingSeconds: durationSeconds,
      startedAt: now,
      endsAt: now + durationSeconds * 1000,
      gracePeriodEndsAt: now,
      graceRemainingMs: null,
      sessionId: `break-${now}-${Math.random().toString(36).slice(2, 8)}`,
      lastResult: null,
    });
    return true;
  });
}

export function pauseTimer(now = Date.now()) {
  return withLock(async () => {
    const t = await getTimer();
    if (t.status !== 'running' || t.kind === 'break' || !canInterrupt(t, now)) return false;
    await setTimer({
      ...t,
      status: 'paused',
      remainingSeconds: Math.ceil(Math.max(0, t.endsAt - now) / 1000),
      graceRemainingMs: Math.max(0, t.gracePeriodEndsAt - now),
      gracePeriodEndsAt: null,
    });
    return true;
  });
}

export function resumeTimer(now = Date.now()) {
  return withLock(async () => {
    const t = await getTimer();
    if (t.status !== 'paused') return false;
    await setTimer({
      ...t,
      status: 'running',
      endsAt: now + t.remainingSeconds * 1000,
      gracePeriodEndsAt: now + t.graceRemainingMs,
      graceRemainingMs: null,
    });
    return true;
  });
}

/** انصراف: فقط در ۱۰ ثانیه‌ی اول؛ هیچ جلسه‌ای ثبت نمی‌شود. */
export function cancelTimer(now = Date.now()) {
  return withLock(async () => {
    const t = await getTimer();
    if (t.status === 'idle' || !canInterrupt(t, now)) return false;
    await setTimer(await idleState());
    return true;
  });
}

async function finish(now) {
  const t = await getTimer();
  if (t.status !== 'running' || now < t.endsAt) return null;
  if (t.kind === 'break') {
    const settings = await getSettings();
    const onTime = now - t.endsAt <= SOUND_MAX_DELAY_MS;
    await setTimer(
      await idleState({
        minutes: Math.round(t.durationSeconds / 60),
        at: t.endsAt,
        sessionId: t.sessionId,
        sound: onTime && settings.soundEnabled ? soundIdOf(settings.soundId) : null,
        notice: now - t.endsAt <= NOTICE_MAX_DELAY_MS,
        kind: 'break',
      }),
    );
    return null; // استراحت جلسه‌ی ثبت‌شده ندارد
  }
  const session = await saveSession(t);
  // صدا فقط برای اتمام «به‌موقع» تصمیم‌گیری می‌شود؛ اگر ثبت دیر انجام شده (مرورگر/سیستم بسته بوده) صدایی نیست.
  const settings = await getSettings();
  const onTime = now - t.endsAt <= SOUND_MAX_DELAY_MS;
  const sound = session && onTime && settings.soundEnabled ? soundIdOf(settings.soundId) : null;
  await setTimer(
    await idleState({
      minutes: Math.round(t.durationSeconds / 60),
      at: t.endsAt,
      sessionId: t.sessionId,
      sound,
      notice: Boolean(session) && now - t.endsAt <= NOTICE_MAX_DELAY_MS,
    }),
  );
  return session;
}

/** پایان جلسه؛ با sessionId و قفل، هر جلسه فقط یک بار ثبت می‌شود. فقط جلسه‌ی تازه را برمی‌گرداند. */
export const completeTimer = (now = Date.now()) => withLock(() => finish(now));

async function saveSession(t) {
  const sessions = await getItem(KEYS.sessions, []);
  if (sessions.some((s) => String(s.id) === t.sessionId)) return null;
  const session = {
    id: t.sessionId,
    startedAt: t.startedAt,
    endedAt: t.endsAt,
    plannedMs: t.durationSeconds * 1000,
    focusedMs: t.durationSeconds * 1000,
    completed: true,
    source: 'timer',
  };
  await setItem(KEYS.sessions, [...sessions, session]);
  return session;
}

export function deleteSession(id) {
  return withLock(async () => {
    const sessions = await getItem(KEYS.sessions, []);
    await setItem(KEYS.sessions, sessions.filter((s) => String(s.id) !== String(id)));
  });
}
