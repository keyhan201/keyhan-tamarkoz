// باغ: کاملاً از روی جلسه‌های ثبت‌شده محاسبه می‌شود (بدون حالت ذخیره‌ی جدا)، پس با حذف/بازیابی جلسه‌ها همیشه هم‌خوان است.
// قواعد:
//  • فقط جلسه‌ی تمرکزِ کامل‌شده‌ی تایمر شمرده می‌شود؛ استراحت جلسه نیست، جلسه‌ی انصرافی ثبت نمی‌شود، جلسه‌ی دستی نمی‌شمارد.
//  • جلسه‌های کوتاه‌تر از ۱۰ دقیقه رشدی ندارند؛ هر جلسه حداکثر ۱۲۰ دقیقه حساب می‌شود.
//  • هر دقیقه‌ی شمرده‌شده یک امتیاز رشد است؛ هر ۱۰۰ امتیاز یک گل کامل در باغ می‌شود و گیاه تازه‌ای شروع می‌شود.
import { isManual, uniqueSessions, validSession } from './sessionRules.js';

// نمایش تصویری گل‌ها فعلاً خاموش است (طراحی تازه لازم دارد). منطق رشد، داده‌ها و ثبت پیشرفت دست‌نخورده‌اند؛
// برای فعال‌سازی دوباره فقط همین مقدار را true کن (و در صورت نیاز PlantSvg را بازطراحی کن).
export const GARDEN_FLOWERS_ENABLED = false;

export const MIN_GROWTH_MINUTES = 10;
export const MAX_SESSION_GROWTH = 120;
export const POINTS_PER_FLOWER = 100;

export const STAGES = [
  { id: 'seed', at: 0, label: 'بذر' },
  { id: 'sprout', at: 25, label: 'جوانه' },
  { id: 'sapling', at: 60, label: 'نهال' },
];
export const FLOWER_KINDS = [
  { id: 'tulip', label: 'لاله', color: '#e5738a' },
  { id: 'daisy', label: 'گل‌بابونه', color: '#f4f1ea' },
  { id: 'sunflower', label: 'آفتابگردان', color: '#f1c24b' },
  { id: 'lavender', label: 'اسطوخودوس', color: '#9a86d8' },
  { id: 'poppy', label: 'شقایق', color: '#e0553f' },
];

export const growthOf = (s) => {
  if (!validSession(s) || isManual(s) || s.source !== 'timer') return 0;
  const minutes = Math.floor(s.focusedMs / 60000);
  return minutes < MIN_GROWTH_MINUTES ? 0 : Math.min(MAX_SESSION_GROWTH, minutes);
};

export const stageOf = (points) => {
  const p = Number.isFinite(points) ? Math.max(0, points) : 0;
  let cur = STAGES[0];
  for (const s of STAGES) if (p >= s.at) cur = s;
  return cur;
};

export function gardenFromSessions(sessions) {
  const list = uniqueSessions(sessions);
  let total = 0;
  let counted = 0;
  for (const s of list) {
    const g = growthOf(s);
    if (g > 0) { total += g; counted += 1; }
  }
  const flowers = Math.floor(total / POINTS_PER_FLOWER);
  const points = total % POINTS_PER_FLOWER;
  const stage = stageOf(points);
  const idx = STAGES.findIndex((s) => s.id === stage.id);
  const next = STAGES[idx + 1] ? STAGES[idx + 1].at : POINTS_PER_FLOWER;
  return {
    totalPoints: total,
    countedSessions: counted,
    flowers,
    kinds: Array.from({ length: flowers }, (_, i) => FLOWER_KINDS[i % FLOWER_KINDS.length].id),
    current: { points, stage, next, remaining: Math.max(0, POINTS_PER_FLOWER - points), progress: points / POINTS_PER_FLOWER },
  };
}
