// آمار یک روز و مقایسه‌ی آن با روز قبل؛ فقط از جلسه‌های کامل‌شده‌ی واقعی. به کارهای روزانه ربطی ندارد.
import { dayKey } from './stats.js';
import { duration, toFa } from './format.js';
import { uniqueSessions, validSession } from './sessionRules.js';

export const startOfDay = (ts) => {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
};

/** یک روز جلو/عقب (n = ±۱)؛ به‌جای جمع ۲۴ ساعت، با تقویم محلی تا تغییر ساعت تابستانی خرابش نکند */
export const addDays = (ts, n) => {
  const d = new Date(ts);
  d.setDate(d.getDate() + n);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
};

export function sessionsOfDay(sessions, ts) {
  const k = dayKey(ts);
  return uniqueSessions(sessions).filter((s) => validSession(s) && dayKey(s.startedAt) === k);
}

export function dayStats(sessions, ts) {
  const list = sessionsOfDay(sessions, ts);
  const totalMs = list.reduce((a, s) => a + s.focusedMs, 0);
  return {
    count: list.length,
    totalMs,
    avgMs: list.length ? totalMs / list.length : 0,
    longestMs: list.reduce((a, s) => Math.max(a, s.focusedMs), 0),
  };
}

const more = (diff, fmt) => (diff === 0 ? 'بدون تغییر' : `${fmt(Math.abs(diff))} ${diff > 0 ? 'بیشتر' : 'کمتر'}`);
const sessionsText = (n) => `${toFa(n)} جلسه`;

/** ردیف‌های متنیِ مقایسه برای روز انتخاب‌شده و روز قبل از آن */
export function buildComparison(sessions, ts) {
  const cur = dayStats(sessions, ts);
  const prev = dayStats(sessions, addDays(ts, -1));
  const both = cur.count > 0 && prev.count > 0;
  const none = 'جلسه‌ای نیست';

  const rows = [
    {
      id: 'focus',
      title: 'زمان تمرکز',
      current: duration(cur.totalMs),
      previous: duration(prev.totalMs),
      change: more(Math.round(cur.totalMs / 60000) - Math.round(prev.totalMs / 60000), (m) => duration(m * 60000)),
    },
    {
      id: 'count',
      title: 'جلسه‌های کامل‌شده',
      current: sessionsText(cur.count),
      previous: sessionsText(prev.count),
      change: more(cur.count - prev.count, sessionsText),
    },
    {
      id: 'avg',
      title: 'میانگین هر جلسه',
      current: cur.count ? duration(cur.avgMs) : none,
      previous: prev.count ? duration(prev.avgMs) : none,
      change: both
        ? more(Math.round(cur.avgMs / 60000) - Math.round(prev.avgMs / 60000), (m) => duration(m * 60000))
        : 'قابل مقایسه نیست',
    },
  ];
  if (cur.count || prev.count) {
    rows.push({
      id: 'longest',
      title: 'طولانی‌ترین جلسه',
      current: cur.count ? duration(cur.longestMs) : none,
      previous: prev.count ? duration(prev.longestMs) : none,
      change: both
        ? more(Math.round(cur.longestMs / 60000) - Math.round(prev.longestMs / 60000), (m) => duration(m * 60000))
        : 'قابل مقایسه نیست',
    });
  }
  return { cur, prev, rows };
}
