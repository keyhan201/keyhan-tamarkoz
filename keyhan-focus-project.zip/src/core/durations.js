// زمان‌های دلخواه ذخیره‌شونده. همه‌ی اعتبارسنجی‌ها این‌جا هستند تا رابط و بازیابی پشتیبان یک قاعده‌ی واحد داشته باشند.
import { MAX_MINUTES, MIN_MINUTES, PRESETS } from './constants.js';
import { fromFa, toFa } from './format.js';

export const MAX_CUSTOM_TIMES = 6;

/** متن (با ارقام فارسی یا انگلیسی) → عدد صحیح معتبر یا null. «۲۵.۵»، «۱e1» و «۲۵ دقیقه» پذیرفته نمی‌شوند. */
export function parseMinutes(raw) {
  const text = fromFa(String(raw ?? '')).trim();
  if (!/^\d{1,4}$/.test(text)) return null;
  const n = Number(text);
  return n >= MIN_MINUTES && n <= MAX_MINUTES ? n : null;
}

/** فهرست ذخیره‌شده را پاک‌سازی می‌کند: فقط عدد صحیح معتبر، بدون تکرار، بدون مقدار پیش‌فرض، مرتب و محدود. */
export function normalizeCustomMinutes(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  for (const v of list) {
    if (!Number.isInteger(v) || v < MIN_MINUTES || v > MAX_MINUTES) continue;
    if (PRESETS.includes(v) || out.includes(v)) continue;
    out.push(v);
  }
  return out.sort((a, b) => a - b).slice(0, MAX_CUSTOM_TIMES);
}

/** خروجی: { ok: true, list, minutes } یا { ok: false, error, duplicate?: عدد } */
export function addCustomMinute(list, raw) {
  const n = parseMinutes(raw);
  if (n === null) return { ok: false, error: `عددی صحیح بین ${toFa(MIN_MINUTES)} تا ${toFa(MAX_MINUTES)} وارد کنید.` };
  const current = normalizeCustomMinutes(list);
  if (PRESETS.includes(n) || current.includes(n)) {
    return { ok: false, duplicate: n, error: 'این زمان از قبل در فهرست هست.' };
  }
  if (current.length >= MAX_CUSTOM_TIMES) {
    return { ok: false, error: `حداکثر ${toFa(MAX_CUSTOM_TIMES)} زمان دلخواه می‌توانید نگه دارید. یکی را حذف کنید.` };
  }
  return { ok: true, minutes: n, list: normalizeCustomMinutes([...current, n]) };
}

export const removeCustomMinute = (list, n) => normalizeCustomMinutes(list).filter((v) => v !== n);
