package com.keyhan.tamarkoz;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Base64;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

@CapacitorPlugin(name = "KeyhanNative")
public class KeyhanNativePlugin extends Plugin {
    private static WeakReference<KeyhanNativePlugin> instance = new WeakReference<>(null);

    @Override public void load() { instance = new WeakReference<>(this); }

    /** وقتی بخش native تایمر/جلسه‌ها را عوض کرد و رابط زنده است، رابط دوباره از ذخیره‌سازی می‌خواند. */
    static void notifyChanged() {
        KeyhanNativePlugin p = instance.get();
        if (p != null) p.notifyListeners("stateChanged", new JSObject());
    }

    private Context ctx() { return getContext(); }

    @PluginMethod
    public void sync(PluginCall call) {
        Context c = ctx();
        JSONObject t = TimerEngine.obj(new PrefsKv(c), "timer");
        String st = t == null ? "idle" : t.optString("status", "idle");
        if ("running".equals(st) || "paused".equals(st)) {
            Notifications.cancel(c, Notifications.ID_END);
            EndOverlay.dismiss(c);
            TimerService.start(c, TimerService.ACTION_SYNC, null);
        } else {
            // تایمر بیکار: زنگ و اعلان تایمر فعال را بردار
            c.stopService(new Intent(c, TimerService.class));
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(
                    android.app.PendingIntent.getBroadcast(c, 7, new Intent(c, TimerReceiver.class).setAction(TimerReceiver.ACTION_ALARM),
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE));
            Notifications.cancel(c, Notifications.ID_RUNNING);
        }
        call.resolve();
    }

    @PluginMethod
    public void setEndQuotes(PluginCall call) {
        JSArray arr = call.getArray("quotes");
        if (arr != null) ctx().getSharedPreferences("kt_native", Context.MODE_PRIVATE).edit().putString("endQuotes", arr.toString()).apply();
        call.resolve();
    }

    @PluginMethod
    public void saveCustomSound(PluginCall call) {
        String b64 = call.getString("base64");
        if (b64 == null) { call.reject("no data"); return; }
        try (FileOutputStream out = new FileOutputStream(SoundPlayer.customFile(ctx()))) {
            out.write(Base64.decode(b64, Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject("write failed");
        }
    }

    @PluginMethod
    public void removeCustomSound(PluginCall call) {
        File f = SoundPlayer.customFile(ctx());
        if (f.exists()) //noinspection ResultOfMethodCallIgnored
            f.delete();
        call.resolve();
    }

    @PluginMethod
    public void listLaunchableApps(PluginCall call) {
        PackageManager pm = ctx().getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(main, 0);
        List<String[]> rows = new ArrayList<>();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (ResolveInfo ri : infos) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(ctx().getPackageName()) || !seen.add(pkg)) continue;
            rows.add(new String[]{String.valueOf(ri.loadLabel(pm)), pkg});
        }
        Collections.sort(rows, (a, b) -> a[0].toLowerCase(Locale.ROOT).compareTo(b[0].toLowerCase(Locale.ROOT)));
        JSArray out = new JSArray();
        for (String[] r : rows) {
            JSObject o = new JSObject();
            o.put("label", r[0]);
            o.put("package", r[1]);
            out.put(o);
        }
        JSObject res = new JSObject();
        res.put("apps", out);
        call.resolve(res);
    }

    @PluginMethod
    public void getPermissions(PluginCall call) {
        Context c = ctx();
        JSObject o = new JSObject();
        o.put("notifications", NotificationManagerCompat.from(c).areNotificationsEnabled());
        o.put("exactAlarm", Build.VERSION.SDK_INT < 31 || ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms());
        o.put("usageAccess", LimitMonitor.hasUsageAccess(c));
        o.put("overlay", Settings.canDrawOverlays(c));
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        o.put("battery", pm.isIgnoringBatteryOptimizations(c.getPackageName()));
        boolean heads = true;
        if (Build.VERSION.SDK_INT >= 26) {
            Notifications.ensureChannels(c);
            android.app.NotificationChannel ch = c.getSystemService(android.app.NotificationManager.class).getNotificationChannel(Notifications.CH_END);
            heads = ch == null || ch.getImportance() >= android.app.NotificationManager.IMPORTANCE_HIGH;
        }
        o.put("headsUp", heads);
        call.resolve(o);
    }

    private void launch(PluginCall call, Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx().startActivity(i);
        } catch (Exception ignored) { }
        call.resolve();
    }

    @PluginMethod
    public void requestNotifications(PluginCall call) {
        Activity a = getActivity();
        if (Build.VERSION.SDK_INT >= 33 && a != null
                && ctx().checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.shouldShowRequestPermissionRationale(a, Manifest.permission.POST_NOTIFICATIONS) == false
                && !ctx().getSharedPreferences("kt_native", Context.MODE_PRIVATE).getBoolean("askedNotif", false)) {
            ctx().getSharedPreferences("kt_native", Context.MODE_PRIVATE).edit().putBoolean("askedNotif", true).apply();
            ActivityCompat.requestPermissions(a, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4401);
            call.resolve();
            return;
        }
        // قبلاً پرسیده شده/رد شده: صفحه‌ی اعلان‌های همین برنامه
        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx().getPackageName());
        launch(call, i);
    }

    @PluginMethod
    public void openChannelSettings(PluginCall call) {
        Intent i = Build.VERSION.SDK_INT >= 26
                ? new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx().getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID, Notifications.CH_END)
                : new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx().getPackageName());
        launch(call, i);
    }

    @PluginMethod
    public void openUsageAccess(PluginCall call) { launch(call, new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }

    @PluginMethod
    public void openOverlay(PluginCall call) {
        launch(call, new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx().getPackageName())));
    }

    @PluginMethod
    public void openExactAlarm(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 31) launch(call, new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx().getPackageName())));
        else call.resolve();
    }

    @PluginMethod
    public void openBattery(PluginCall call) { launch(call, new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
}
