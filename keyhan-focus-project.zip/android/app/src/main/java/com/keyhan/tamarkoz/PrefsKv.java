package com.keyhan.tamarkoz;

import android.content.Context;
import android.content.SharedPreferences;

/** گروه پیش‌فرض Capacitor Preferences: «CapacitorStorage». */
public final class PrefsKv implements Kv {
    private final SharedPreferences sp;

    public PrefsKv(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences("CapacitorStorage", Context.MODE_PRIVATE);
    }

    @Override public String get(String key) { return sp.getString(key, null); }

    @Override public void put(String key, String value) { sp.edit().putString(key, value).commit(); }
}
