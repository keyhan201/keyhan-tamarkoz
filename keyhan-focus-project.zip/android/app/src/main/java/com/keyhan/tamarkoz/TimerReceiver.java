package com.keyhan.tamarkoz;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

/** زنگ پایان، بازراه‌اندازی گوشی، تغییر ساعت/منطقه‌ی زمانی، به‌روزرسانی اپ و بستن اعلان. */
public class TimerReceiver extends BroadcastReceiver {
    static final String ACTION_ALARM = "com.keyhan.tamarkoz.ALARM";
    static final String ACTION_DISMISS = "com.keyhan.tamarkoz.DISMISS";
    static final String ACTION_BLOCK_OFF = "com.keyhan.tamarkoz.BLOCK_OFF";

    @Override public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (a == null) return;
        if (ACTION_DISMISS.equals(a)) {
            Notifications.cancel(ctx, Notifications.ID_END);
            return;
        }
        if (ACTION_BLOCK_OFF.equals(a)) {
            // خروج فوری از حالت محدودسازی، بدون نیاز به باز کردن اپ
            TimerEngine.setSetting(new PrefsKv(ctx), "blockMode", false);
            KeyhanNativePlugin.notifyChanged();
            TimerService.start(ctx, TimerService.ACTION_SYNC, null);
            return;
        }
        if (ACTION_ALARM.equals(a)) {
            String sid = intent.getStringExtra(TimerService.EXTRA_SESSION);
            if (!TimerService.start(ctx, TimerService.ACTION_FINISH, sid)) {
                // سرویس پیش‌زمینه اجازه‌ی شروع نداشت: پایان را همین‌جا ثبت و اعلام می‌کنیم
                Finisher.handle(ctx, sid, null);
            }
            return;
        }
        // BOOT_COMPLETED / TIME_SET / TIMEZONE_CHANGED / MY_PACKAGE_REPLACED: زنگ‌ها پاک شده‌اند؛ از روی endsAt دوباره بساز.
        JSONObject t = TimerEngine.obj(new PrefsKv(ctx), "timer");
        String st = t == null ? "idle" : t.optString("status", "idle");
        if ("running".equals(st) || "paused".equals(st)) {
            if (!TimerService.start(ctx, TimerService.ACTION_SYNC, null)) {
                Finisher.handle(ctx, null, null); // اگر تمام شده، حداقل ثبت شود
            }
        }
    }
}
