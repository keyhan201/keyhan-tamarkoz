package com.keyhan.tamarkoz;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import java.io.File;

/** پخش صدای پایان: صداهای داخلی از res/raw و «صدای من» از فایل ذخیره‌شده؛ هر خطایی به دینگ و بعد سکوت می‌رسد. */
final class SoundPlayer {
    private static MediaPlayer player;
    private static final Handler H = new Handler(Looper.getMainLooper());

    private SoundPlayer() {}

    static File customFile(Context c) { return new File(c.getFilesDir(), "custom_sound"); }

    static synchronized boolean play(Context ctx, String id, Runnable done) {
        stop();
        Context app = ctx.getApplicationContext();
        boolean ok = tryPlay(app, id, done);
        if (!ok && "custom".equals(id)) ok = tryPlay(app, "ding", done);
        return ok;
    }

    private static boolean tryPlay(Context ctx, String id, Runnable done) {
        MediaPlayer mp = null;
        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            if ("custom".equals(id)) {
                File f = customFile(ctx);
                if (!f.exists()) { mp.release(); return false; }
                mp.setDataSource(f.getAbsolutePath());
            } else {
                String safe = "chime".equals(id) || "soft".equals(id) || "drop".equals(id) ? id : "ding";
                int res = ctx.getResources().getIdentifier("snd_" + safe, "raw", ctx.getPackageName());
                if (res == 0) { mp.release(); return false; }
                AssetFileDescriptor afd = ctx.getResources().openRawResourceFd(res);
                mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                afd.close();
            }
            final MediaPlayer mine = mp;
            mp.setOnCompletionListener(m -> finish(mine, done));
            mp.setOnErrorListener((m, w, e) -> { finish(mine, done); return true; });
            mp.prepare();
            mp.start();
            player = mp;
            H.postDelayed(() -> finish(mine, done), 20_000); // سقف ایمنی (صدای کاربر حداکثر ۱۵ ثانیه است)
            return true;
        } catch (Exception e) {
            if (mp != null) { try { mp.release(); } catch (Exception ignored) { } }
            return false;
        }
    }

    private static synchronized void finish(MediaPlayer m, Runnable done) {
        if (player != m && player != null) return;
        boolean was = player == m;
        try { m.release(); } catch (Exception ignored) { }
        if (was) {
            player = null;
            if (done != null) H.post(done);
        }
    }

    static synchronized void stop() {
        if (player != null) { try { player.release(); } catch (Exception ignored) { } player = null; }
    }

    static synchronized boolean isPlaying() { return player != null; }
}
