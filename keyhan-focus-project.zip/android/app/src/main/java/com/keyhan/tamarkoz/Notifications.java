package com.keyhan.tamarkoz;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import org.json.JSONObject;

/**
 * دو نوع اعلان جدا:
 *  1) اعلان تایمر فعال (ongoing، کم‌اهمیت، بی‌صدا، شمارش معکوس)؛ اندروید ۱۴+ به کاربر اجازه‌ی کنار زدن اعلان سرویس پیش‌زمینه را می‌دهد.
 *  2) اعلان پایان جلسه/استراحت (اهمیت بالا) با دکمه‌های «استراحت»، «شروع جلسه‌ی جدید» و «بستن».
 */
final class Notifications {
    static final String CH_RUNNING = "timer_running";
    static final String CH_END = "timer_end";
    static final String CH_LIMIT = "limit_warning";
    static final int ID_RUNNING = 1001;
    static final int ID_END = 1002;
    static final int ID_LIMIT = 1003;

    private Notifications() {}

    static void ensureChannels(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        NotificationChannel running = new NotificationChannel(CH_RUNNING, "تایمر فعال", NotificationManager.IMPORTANCE_LOW);
        running.setDescription("نمایش زمان باقی‌مانده‌ی جلسه‌ی تمرکز یا استراحت");
        running.setShowBadge(false);
        NotificationChannel end = new NotificationChannel(CH_END, "پایان جلسه", NotificationManager.IMPORTANCE_HIGH);
        end.setDescription("اعلام پایان تمرکز یا استراحت");
        end.setSound(null, null); // صدا را خود اپ (صدای انتخابی کاربر) پخش می‌کند
        end.enableVibration(true);
        NotificationChannel limit = new NotificationChannel(CH_LIMIT, "هشدار برنامه‌های منتخب", NotificationManager.IMPORTANCE_HIGH);
        limit.setDescription("هشدار هنگام باز شدن برنامه‌ای که برای محدودیت انتخاب کرده‌اید");
        nm.createNotificationChannels(java.util.Arrays.asList(running, end, limit));
    }

    private static PendingIntent open(Context c) {
        Intent i = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent service(Context c, String action, int req) {
        Intent i = new Intent(c, TimerService.class).setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        return Build.VERSION.SDK_INT >= 26 ? PendingIntent.getForegroundService(c, req, i, flags) : PendingIntent.getService(c, req, i, flags);
    }

    private static PendingIntent dismiss(Context c) {
        Intent i = new Intent(c, TimerReceiver.class).setAction(TimerReceiver.ACTION_DISMISS);
        return PendingIntent.getBroadcast(c, 3, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static String fa(long n) {
        StringBuilder sb = new StringBuilder();
        for (char ch : Long.toString(n).toCharArray()) sb.append(ch >= '0' && ch <= '9' ? (char) ('۰' + (ch - '0')) : ch);
        return sb.toString();
    }

    /** اعلان تایمر فعال؛ برای حالت بیکار هم یک اعلان حداقلی می‌دهد (لازمه‌ی startForeground). */
    static Notification running(Context c, JSONObject t) {
        ensureChannels(c);
        String status = t == null ? "idle" : t.optString("status", "idle");
        boolean brk = t != null && "break".equals(t.optString("kind"));
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_RUNNING)
                .setSmallIcon(R.drawable.ic_stat_timer)
                .setContentIntent(open(c))
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_PROGRESS)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);
        if ("running".equals(status)) {
            long endsAt = t.optLong("endsAt", System.currentTimeMillis());
            b.setContentTitle(brk ? "در حال استراحت" : "در حال تمرکز");
            if (!brk && TimerEngine.settings(new PrefsKv(c)).optBoolean("blockMode", false)) {
                Intent off = new Intent(c, TimerReceiver.class).setAction(TimerReceiver.ACTION_BLOCK_OFF);
                b.addAction(0, "توقف محدودسازی", PendingIntent.getBroadcast(c, 5, off, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            }
            b.setContentText("زمان باقی‌مانده تا پایان");
            if (Build.VERSION.SDK_INT >= 24) {
                b.setShowWhen(true).setWhen(endsAt).setUsesChronometer(true).setChronometerCountDown(true);
            } else {
                b.setContentText("پایان: " + new java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(new java.util.Date(endsAt)));
            }
        } else if ("paused".equals(status)) {
            long min = (t.optLong("remainingSeconds", 0) + 59) / 60;
            b.setContentTitle("تمرکز متوقف شد").setContentText(fa(min) + " دقیقه باقی مانده").setShowWhen(false);
        } else {
            b.setContentTitle("کیهان تمرکز").setShowWhen(false);
        }
        return b.build();
    }

    static void end(Context c, TimerEngine.Result r, String quote) {
        if (!NotificationManagerCompat.from(c).areNotificationsEnabled()) return;
        ensureChannels(c);
        boolean brk = "break".equals(r.kind);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_END)
                .setSmallIcon(R.drawable.ic_stat_timer)
                .setContentIntent(open(c))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
                .setDeleteIntent(dismiss(c));
        String body;
        if (brk) {
            b.setContentTitle("استراحت تمام شد");
            body = "آماده‌ای برای جلسه‌ی بعدی؟";
        } else {
            b.setContentTitle("تمرکزت تموم شد");
            body = fa(r.minutes) + " دقیقه ثبت شد.";
        }
        if (quote != null && !quote.isEmpty()) body = body + "\n" + quote;
        b.setContentText(body.split("\n")[0]).setStyle(new NotificationCompat.BigTextStyle().bigText(body));
        if (!brk) {
            b.addAction(0, "استراحت", service(c, TimerService.ACTION_REST, 1));
            b.addAction(0, "تمدید جلسه", service(c, TimerService.ACTION_EXTEND, 4));
        } else {
            b.addAction(0, "شروع جلسه‌ی جدید", service(c, TimerService.ACTION_NEW, 2));
        }
        b.addAction(0, "بستن", dismiss(c));
        try {
            NotificationManagerCompat.from(c).notify(ID_END, b.build());
        } catch (SecurityException ignored) { /* مجوز اعلان رد شده */ }
    }

    static void limitWarning(Context c) {
        if (!NotificationManagerCompat.from(c).areNotificationsEnabled()) return;
        ensureChannels(c);
        Notification n = new NotificationCompat.Builder(c, CH_LIMIT)
                .setSmallIcon(R.drawable.ic_stat_timer)
                .setContentTitle("الان وقت تمرکزه")
                .setContentText("این برنامه جزو برنامه‌های منتخب توست؛ برگرد به کیهان تمرکز؟")
                .setContentIntent(open(c))
                .setAutoCancel(true)
                .setTimeoutAfter(15_000)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();
        try { NotificationManagerCompat.from(c).notify(ID_LIMIT, n); } catch (SecurityException ignored) { }
    }

    static void cancel(Context c, int id) { NotificationManagerCompat.from(c).cancel(id); }
}
