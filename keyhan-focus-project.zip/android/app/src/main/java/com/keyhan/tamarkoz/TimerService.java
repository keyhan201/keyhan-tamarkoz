package com.keyhan.tamarkoz;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

/** سرویس پیش‌زمینه‌ی تایمر: اعلان شمارش معکوس، زنگ دقیق پایان، اقدام‌های اعلان و پایش برنامه‌های منتخب. */
public class TimerService extends Service {
    static final String ACTION_SYNC = "com.keyhan.tamarkoz.SYNC";
    static final String ACTION_FINISH = "com.keyhan.tamarkoz.FINISH";
    static final String ACTION_REST = "com.keyhan.tamarkoz.REST";
    static final String ACTION_NEW = "com.keyhan.tamarkoz.NEW";
    static final String ACTION_EXTEND = "com.keyhan.tamarkoz.EXTEND";
    static final String EXTRA_SESSION = "sessionId";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean soundBusy = false;
    private int ticks = 0;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            ticks++;
            Kv kv = new PrefsKv(TimerService.this);
            JSONObject t = TimerEngine.obj(kv, "timer");
            if (t != null && "running".equals(t.optString("status")) && System.currentTimeMillis() >= t.optLong("endsAt", Long.MAX_VALUE)) {
                finishNow(null);
            } else {
                LimitMonitor.tick(TimerService.this);
            }
            if (isActive()) handler.postDelayed(this, 1000);
        }
    };

    /** شروع/به‌روزرسانی سرویس از بیرون. اگر شروعش مجاز نبود (محدودیت پس‌زمینه) false می‌دهد. */
    static boolean start(Context c, String action, String sessionId) {
        try {
            Intent i = new Intent(c, TimerService.class).setAction(action);
            if (sessionId != null) i.putExtra(EXTRA_SESSION, sessionId);
            ContextCompat.startForegroundService(c, i);
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Kv kv = new PrefsKv(this);
        // باید سریع startForeground شود، حتی اگر در نهایت چیزی برای نمایش نباشد
        goForeground(TimerEngine.obj(kv, "timer"));
        String action = intent == null || intent.getAction() == null ? ACTION_SYNC : intent.getAction();
        long now = System.currentTimeMillis();
        switch (action) {
            case ACTION_EXTEND:
                // تمدید = یک جلسه‌ی تمرکز تازه (sessionId جدید)؛ جلسه‌ی قبلی فقط یک بار ثبت شده و دوباره ثبت نمی‌شود
                Notifications.cancel(this, Notifications.ID_END);
                EndOverlay.dismiss(this);
                TimerEngine.startFocus(kv, TimerEngine.extendMinutes(kv), now);
                KeyhanNativePlugin.notifyChanged();
                break;
            case ACTION_REST:
                Notifications.cancel(this, Notifications.ID_END);
                EndOverlay.dismiss(this);
                TimerEngine.startBreak(kv, TimerEngine.breakMinutes(kv), now);
                KeyhanNativePlugin.notifyChanged();
                break;
            case ACTION_NEW:
                Notifications.cancel(this, Notifications.ID_END);
                EndOverlay.dismiss(this);
                TimerEngine.startFocus(kv, TimerEngine.defaultMinutes(kv), now);
                KeyhanNativePlugin.notifyChanged();
                break;
            case ACTION_FINISH:
                finishNow(intent == null ? null : intent.getStringExtra(EXTRA_SESSION));
                break;
            default:
                JSONObject t = TimerEngine.obj(kv, "timer");
                if (t != null && "running".equals(t.optString("status")) && now >= t.optLong("endsAt", Long.MAX_VALUE)) finishNow(null);
                break;
        }
        refresh();
        return START_STICKY;
    }

    private void goForeground(JSONObject t) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(this, Notifications.ID_RUNNING, Notifications.running(this, t), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(Notifications.ID_RUNNING, Notifications.running(this, t));
            }
        } catch (RuntimeException ignored) { /* مجاز نبود؛ refresh سرویس را می‌بندد */ }
    }

    private void finishNow(String sessionId) {
        boolean sound = Finisher.handle(this, sessionId, () -> { soundBusy = false; refresh(); });
        if (sound) soundBusy = true;
    }

    private boolean isActive() {
        JSONObject t = TimerEngine.obj(new PrefsKv(this), "timer");
        String st = t == null ? "idle" : t.optString("status", "idle");
        return "running".equals(st) || "paused".equals(st);
    }

    private PendingIntent alarmIntent(String sessionId) {
        Intent i = new Intent(this, TimerReceiver.class).setAction(TimerReceiver.ACTION_ALARM);
        i.putExtra(EXTRA_SESSION, sessionId);
        return PendingIntent.getBroadcast(this, 7, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void refresh() {
        handler.removeCallbacks(tick);
        JSONObject t = TimerEngine.obj(new PrefsKv(this), "timer");
        String st = t == null ? "idle" : t.optString("status", "idle");
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if ("running".equals(st)) {
            long endsAt = t.optLong("endsAt", 0);
            PendingIntent pi = alarmIntent(t.optString("sessionId", ""));
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endsAt, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endsAt, pi); // مجوز زنگ دقیق ندارد: ممکن است کمی دیر برسد
            }
            goForeground(t);
            ticks = 0;
            handler.postDelayed(tick, 1000);
        } else if ("paused".equals(st)) {
            am.cancel(alarmIntent(""));
            goForeground(t);
        } else {
            am.cancel(alarmIntent(""));
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
            if (!soundBusy) stopSelf();
        }
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(tick);
        super.onDestroy();
    }
}
