package com.keyhan.tamarkoz;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Random;

/** پایان جلسه/استراحت: ثبت در ذخیره‌سازی، اعلان، صدا. هر sessionId حداکثر یک بار اعلام می‌شود. */
final class Finisher {
    private Finisher() {}

    /** @return true اگر صدایی شروع شد (سرویس تا پایانش زنده می‌ماند). */
    static boolean handle(Context ctx, String sessionId, Runnable soundDone) {
        Kv kv = new PrefsKv(ctx);
        long now = System.currentTimeMillis();
        TimerEngine.Result r = null;
        JSONObject t = TimerEngine.obj(kv, "timer");
        if (t != null && "running".equals(t.optString("status"))
                && (sessionId == null || sessionId.equals(t.optString("sessionId")))) {
            r = TimerEngine.finish(kv, now);
        }
        if (r == null && sessionId != null && t != null) {
            // اپ باز بود و JS زودتر جلسه را بسته؛ اعلان/صدا هنوز باید برسد
            JSONObject last = t.optJSONObject("lastResult");
            if (last != null && sessionId.equals(last.optString("sessionId"))) r = TimerEngine.fromLastResult(last);
        }
        if (r == null || r.sessionId == null) return false;
        KeyhanNativePlugin.notifyChanged();

        SharedPreferences np = ctx.getSharedPreferences("kt_native", Context.MODE_PRIVATE);
        if (r.sessionId.equals(np.getString("lastAnnounced", null))) return false;
        np.edit().putString("lastAnnounced", r.sessionId).apply();
        if (!r.notice) return false; // دیرهنگام: ثبت می‌شود ولی ناگهانی اعلام نمی‌شود

        JSONObject settings = TimerEngine.settings(kv);
        // یک جمله برای هر دو نمایش (اعلان و کارت) تا جمله‌ی مصرف‌شده دو بار خرج نشود
        String quote = "focus".equals(r.kind) && settings.optBoolean("showQuotes", true) ? nextQuote(np) : null;
        if (settings.optBoolean("notifications", true)) Notifications.end(ctx, r, quote);
        if (settings.optBoolean("endOverlay", false)) EndOverlay.show(ctx, r, quote);
        if (r.sound != null) return SoundPlayer.play(ctx, r.sound, soundDone);
        return false;
    }

    /** جمله‌ی پایان جلسه؛ ۲۵ جمله‌ی اخیر تا حد ممکن تکرار نمی‌شوند. */
    static String nextQuote(SharedPreferences np) {
        try {
            String raw = np.getString("endQuotes", null);
            if (raw == null) return null;
            JSONArray quotes = new JSONArray(raw);
            int n = quotes.length();
            if (n == 0) return null;
            JSONArray recent = new JSONArray(np.getString("recentEnd", "[]"));
            int window = Math.min(25, n - 1);
            java.util.HashSet<Integer> skip = new java.util.HashSet<>();
            for (int i = Math.max(0, recent.length() - window); i < recent.length(); i++) skip.add(recent.optInt(i, -1));
            java.util.ArrayList<Integer> pool = new java.util.ArrayList<>();
            for (int i = 0; i < n; i++) if (!skip.contains(i)) pool.add(i);
            if (pool.isEmpty()) for (int i = 0; i < n; i++) pool.add(i);
            int pick = pool.get(new Random().nextInt(pool.size()));
            recent.put(pick);
            JSONArray trimmed = new JSONArray();
            for (int i = Math.max(0, recent.length() - 25); i < recent.length(); i++) trimmed.put(recent.get(i));
            np.edit().putString("recentEnd", trimmed.toString()).apply();
            return quotes.optString(pick, null);
        } catch (Exception e) {
            return null;
        }
    }
}
