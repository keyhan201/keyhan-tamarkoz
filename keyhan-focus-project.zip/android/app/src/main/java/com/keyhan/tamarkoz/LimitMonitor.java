package com.keyhan.tamarkoz;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Process;
import android.provider.Settings;
import android.telecom.TelecomManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * پایش برنامه‌ی جلوی صفحه فقط هنگام «تمرکز در حال اجرا». دو رفتار جدا:
 *  1) هشدار برای برنامه‌های منتخب کاربر (limitEnabled)،
 *  2) حالت محدودسازی (blockMode): هر برنامه‌ی غیرایمن که جلو بیاید، به اپ تمرکز برگردانده می‌شود.
 * اندروید به برنامه‌ی عادی اجازه‌ی بستن/قفل‌کردن برنامه‌های دیگر را نمی‌دهد؛ این «برگرداندن» است، نه مسدودسازی ۱۰۰٪.
 * فقط نام بسته‌ی برنامه‌ی جلوی صفحه خوانده می‌شود؛ چیزی ذخیره یا ارسال نمی‌شود.
 */
final class LimitMonitor {
    static final long COOLDOWN_MS = 20_000L;      // مثل WARN_COOLDOWN_MS در src/core/appLimits.js
    static final long BOUNCE_COOLDOWN_MS = 2_000L; // مثل BOUNCE_COOLDOWN_MS
    /** هرگز برگردانده نمی‌شوند: تماس/اضطراری، تنظیمات و دیالوگ مجوزها، سیستم، لانچرها (مثل SAFE_PACKAGES در JS). */
    static final Set<String> SAFE = new HashSet<>(Arrays.asList(
            "android", "com.android.systemui", "com.android.settings", "com.android.phone", "com.android.server.telecom",
            "com.android.incallui", "com.android.emergency", "com.android.dialer", "com.google.android.dialer",
            "com.samsung.android.dialer", "com.samsung.android.incallui", "com.android.permissioncontroller",
            "com.google.android.permissioncontroller", "com.google.android.apps.nexuslauncher", "com.android.launcher3",
            "com.sec.android.app.launcher", "com.miui.home", "com.huawei.android.launcher", "com.oneplus.launcher", "com.oppo.launcher",
            "com.google.android.packageinstaller", "com.android.packageinstaller"));
    private static long lastWarnAt = 0;
    private static long lastBounceAt = 0;
    private static String lastFg = null;

    private LimitMonitor() {}

    static boolean hasUsageAccess(Context c) {
        try {
            AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    /** آخرین برنامه‌ی وارد‌شده به پیش‌زمینه؛ اگر در ۱۵ ثانیه رویدادی نبود، آخرین مقدار شناخته‌شده. */
    static String foregroundPackage(Context c) {
        try {
            UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            UsageEvents ev = usm.queryEvents(now - 15_000, now);
            UsageEvents.Event e = new UsageEvents.Event();
            String pkg = null;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) pkg = e.getPackageName();
            }
            if (pkg != null) lastFg = pkg;
            return lastFg;
        } catch (Exception ex) {
            return lastFg;
        }
    }

    /** لانچر پیش‌فرض، شماره‌گیر، کیبورد فعلی، دیالوگ‌های سیستمی: همیشه ایمن. */
    static Set<String> dynamicSafe(Context c) {
        Set<String> s = new HashSet<>();
        try {
            PackageManager pm = c.getPackageManager();
            ResolveInfo home = pm.resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY);
            if (home != null && home.activityInfo != null) s.add(home.activityInfo.packageName);
            ResolveInfo dial = pm.resolveActivity(new Intent(Intent.ACTION_DIAL), PackageManager.MATCH_DEFAULT_ONLY);
            if (dial != null && dial.activityInfo != null) s.add(dial.activityInfo.packageName);
            TelecomManager tm = (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
            if (tm != null && tm.getDefaultDialerPackage() != null) s.add(tm.getDefaultDialerPackage());
            String ime = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
            if (ime != null) {
                ComponentName cn = ComponentName.unflattenFromString(ime);
                if (cn != null) s.add(cn.getPackageName());
            }
        } catch (Exception ignored) { }
        return s;
    }

    /** تصمیم هشدار، هم‌ارز shouldWarn در src/core/appLimits.js */
    static boolean shouldWarn(JSONObject timer, JSONObject settings, String fg, long now, long lastWarn, String self) {
        if (settings == null || !settings.optBoolean("limitEnabled", false)) return false;
        if (!focusRunning(timer)) return false;
        if (fg == null || fg.equals(self)) return false;
        JSONArray apps = settings.optJSONArray("limitedApps");
        boolean listed = false;
        if (apps != null) for (int i = 0; i < apps.length(); i++) if (fg.equals(apps.optString(i))) { listed = true; break; }
        return listed && now - lastWarn >= COOLDOWN_MS;
    }

    /** تصمیم برگرداندن، هم‌ارز shouldBounce در src/core/appLimits.js */
    static boolean shouldBounce(JSONObject timer, JSONObject settings, String fg, long now, long lastBounce, String self, Set<String> extraSafe) {
        if (settings == null || !settings.optBoolean("blockMode", false)) return false;
        if (!focusRunning(timer)) return false;
        if (fg == null || fg.equals(self)) return false;
        if (SAFE.contains(fg) || (extraSafe != null && extraSafe.contains(fg))) return false;
        return now - lastBounce >= BOUNCE_COOLDOWN_MS;
    }

    private static boolean focusRunning(JSONObject timer) {
        return timer != null && "running".equals(timer.optString("status")) && !"break".equals(timer.optString("kind"));
    }

    private static void bringToFront(Context c) {
        c.startActivity(new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
    }

    static void tick(Context c) {
        Kv kv = new PrefsKv(c);
        JSONObject settings = TimerEngine.settings(kv);
        boolean block = settings.optBoolean("blockMode", false);
        if (!(block || settings.optBoolean("limitEnabled", false)) || !hasUsageAccess(c)) return;
        JSONObject timer = TimerEngine.obj(kv, "timer");
        if (!focusRunning(timer)) { lastFg = null; return; }
        long now = System.currentTimeMillis();
        String fg = foregroundPackage(c);
        String self = c.getPackageName();
        boolean canFront = Settings.canDrawOverlays(c);
        if (block && shouldBounce(timer, settings, fg, now, lastBounceAt, self, dynamicSafe(c))) {
            if (canFront) {
                lastBounceAt = now;
                try { bringToFront(c); return; } catch (Exception ignored) { }
            }
            // مجوز نمایش نیست یا اندروید اجازه نداد: فقط هشدار اعلان (با فاصله)
            if (now - lastWarnAt >= COOLDOWN_MS) { lastWarnAt = now; Notifications.limitWarning(c); }
            return;
        }
        if (shouldWarn(timer, settings, fg, now, lastWarnAt, self)) {
            lastWarnAt = now;
            Notifications.limitWarning(c);
            if (settings.optBoolean("limitBringBack", false) && canFront) {
                try { bringToFront(c); } catch (Exception ignored) { }
            }
        }
    }
}
