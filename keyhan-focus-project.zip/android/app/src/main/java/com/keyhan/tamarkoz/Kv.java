package com.keyhan.tamarkoz;

/** ذخیره‌ی کلید/مقدار رشته‌ای؛ در اندروید همان SharedPreferences ی است که Capacitor Preferences هم می‌نویسد. */
public interface Kv {
    String get(String key);
    void put(String key, String value);
}
