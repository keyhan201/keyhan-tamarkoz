package com.keyhan.tamarkoz;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(KeyhanNativePlugin.class);
        super.onCreate(savedInstanceState);
        Notifications.ensureChannels(this);
    }
}
