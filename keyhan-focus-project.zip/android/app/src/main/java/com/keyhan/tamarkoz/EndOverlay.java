package com.keyhan.tamarkoz;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * کارت پایان جلسه‌ی اختصاصی اپ، روی برنامه‌های دیگر (TYPE_APPLICATION_OVERLAY).
 * با «اعلان شناور» (heads-up) فرق دارد: اعلان را سیستم و در بالای صفحه نشان می‌دهد و موقعیتش قابل تغییر نیست؛
 * این کارت را خود اپ می‌کشد (میانه/نیمه‌ی پایین) و فقط با تنظیم اختیاری کاربر + مجوز «نمایش روی برنامه‌های دیگر» ساخته می‌شود.
 * بدون مجوز هیچ‌چیزی کشیده نمی‌شود و اعلان سیستمی همچنان می‌آید.
 */
final class EndOverlay {
    private static View current;
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static Runnable autoDismiss;
    private static final long AUTO_DISMISS_MS = 30_000L;

    private static final int NIGHT = Color.parseColor("#0D1124");
    private static final int STAR = Color.parseColor("#F1D28B");
    private static final int INK = Color.parseColor("#E9EBF7");
    private static final int MUTE = Color.parseColor("#98A0C4");
    private static final int LINE = Color.parseColor("#2F3760");

    private EndOverlay() {}

    private static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    private static String fa(long n) {
        StringBuilder sb = new StringBuilder();
        for (char ch : Long.toString(n).toCharArray()) sb.append(ch >= '0' && ch <= '9' ? (char) ('۰' + (ch - '0')) : ch);
        return sb.toString();
    }

    private static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setLineSpacing(0, 1.2f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** دکمه‌ی کامل‌عرض با ارتفاع لمسی ۵۲dp؛ fill = پررنگ، outline = حاشیه‌دار، وگرنه فقط متن. */
    private static TextView button(Context c, String label, String style, Runnable onClick) {
        TextView b = text(c, label, 16, "fill".equals(style) ? NIGHT : ("outline".equals(style) ? INK : MUTE), "fill".equals(style));
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 52));
        b.setClickable(true);
        b.setFocusable(true);
        b.setContentDescription(label);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(c, 16));
        if ("fill".equals(style)) {
            bg.setColor(STAR);
        } else if ("outline".equals(style)) {
            bg.setColor(Color.TRANSPARENT);
            bg.setStroke(dp(c, 1), LINE);
        } else {
            bg.setColor(Color.TRANSPARENT);
        }
        b.setBackground(bg);
        b.setOnClickListener(v -> onClick.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(c, 10);
        b.setLayoutParams(lp);
        return b;
    }

    static void show(Context ctx, TimerEngine.Result r, String quote) {
        final Context app = ctx.getApplicationContext();
        if (!Settings.canDrawOverlays(app)) return; // مجوز نیست: فقط اعلان سیستمی
        final boolean brk = "break".equals(r.kind);
        final int minutes = r.minutes;
        H.post(() -> {
            try {
                dismissNow(app);
                WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
                DisplayMetrics dm = app.getResources().getDisplayMetrics();

                LinearLayout card = new LinearLayout(app);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                card.setPadding(dp(app, 22), dp(app, 20), dp(app, 22), dp(app, 14));
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(NIGHT);
                bg.setCornerRadius(dp(app, 28));
                bg.setStroke(dp(app, 1), LINE);
                card.setBackground(bg);
                card.setElevation(dp(app, 10));

                // عنوان با یک نقطه‌ی کوچک زرد (هماهنگ با لوگوی اپ)
                LinearLayout head = new LinearLayout(app);
                head.setOrientation(LinearLayout.HORIZONTAL);
                head.setGravity(Gravity.CENTER_VERTICAL);
                View dot = new View(app);
                GradientDrawable dotBg = new GradientDrawable();
                dotBg.setShape(GradientDrawable.OVAL);
                dotBg.setColor(STAR);
                dot.setBackground(dotBg);
                LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(app, 10), dp(app, 10));
                dotLp.setMarginEnd(dp(app, 10));
                head.addView(dot, dotLp);
                head.addView(text(app, brk ? "استراحت تمام شد" : "تمرکزت تموم شد", 21, INK, true));
                card.addView(head);

                TextView sub = text(app, brk ? "آماده‌ای برای جلسه‌ی بعدی؟" : fa(minutes) + " دقیقه تمرکز ثبت شد.", 15, MUTE, false);
                LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                subLp.topMargin = dp(app, 6);
                card.addView(sub, subLp);

                if (quote != null && !quote.isEmpty()) {
                    TextView q = text(app, quote, 14, Color.parseColor("#C9CEE8"), false);
                    q.setMaxLines(3);
                    q.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams qLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    qLp.topMargin = dp(app, 12);
                    card.addView(q, qLp);
                }

                card.addView(new View(app), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(app, 6)));
                if (brk) {
                    card.addView(button(app, "شروع جلسه‌ی جدید", "fill", () -> act(app, TimerService.ACTION_NEW)));
                } else {
                    card.addView(button(app, "استراحت", "fill", () -> act(app, TimerService.ACTION_REST)));
                    card.addView(button(app, "تمدید جلسه", "outline", () -> act(app, TimerService.ACTION_EXTEND)));
                }
                card.addView(button(app, "بستن", "text", () -> dismissNow(app)));

                int widthPx = Math.min((int) (dm.widthPixels * 0.9f), dp(app, 400));
                boolean shortScreen = dm.heightPixels < dp(app, 520); // افقی/کم‌ارتفاع: دقیقاً وسط
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                        widthPx, WindowManager.LayoutParams.WRAP_CONTENT,
                        Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : legacyType(),
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                        PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.CENTER;
                lp.y = shortScreen ? 0 : (int) (dm.heightPixels * 0.12f); // کمی پایین‌تر از مرکز؛ دور از نوار وضعیت و ناوبری
                card.setAlpha(0f);
                card.setTranslationY(dp(app, 24));
                wm.addView(card, lp);
                card.animate().alpha(1f).translationY(0f).setDuration(220).start();
                current = card;
                autoDismiss = () -> dismissNow(app);
                H.postDelayed(autoDismiss, AUTO_DISMISS_MS);
            } catch (Exception ignored) {
                // سیستم اجازه نداد؛ اعلان سیستمی همچنان هست
            }
        });
    }

    @SuppressWarnings("deprecation")
    private static int legacyType() { return WindowManager.LayoutParams.TYPE_PHONE; }

    private static void act(Context app, String action) {
        TimerService.start(app, action, null);
        dismissNow(app);
    }

    static void dismiss(Context ctx) {
        final Context app = ctx.getApplicationContext();
        H.post(() -> dismissNow(app));
    }

    private static void dismissNow(Context app) {
        if (autoDismiss != null) {
            H.removeCallbacks(autoDismiss);
            autoDismiss = null;
        }
        if (current == null) return;
        try {
            ((WindowManager) app.getSystemService(Context.WINDOW_SERVICE)).removeView(current);
        } catch (Exception ignored) {
            // پنجره قبلاً حذف شده
        }
        current = null;
    }
}
