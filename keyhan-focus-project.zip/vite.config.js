import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

const p = (rel) => fileURLToPath(new URL(rel, import.meta.url));

// ورودی‌ها: پاپ‌آپ، صفحه‌ی کامل، سند offscreen (پخش صدا) و service worker پس‌زمینه
export default defineConfig({
  plugins: [react()],
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    modulePreload: { polyfill: false },
    rollupOptions: {
      input: {
        popup: p('./popup.html'),
        dashboard: p('./dashboard.html'),
        offscreen: p('./offscreen.html'),
        background: p('./src/background/background.js'),
      },
      output: {
        entryFileNames: (chunk) =>
          chunk.name === 'background' ? 'background.js' : 'assets/[name]-[hash].js',
      },
    },
  },
});
