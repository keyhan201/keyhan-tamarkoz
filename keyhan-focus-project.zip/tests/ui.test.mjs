// اجرا: node tests/ui.test.mjs — رابط واقعی (React) را در jsdom رندر می‌کند و تعامل‌ها را اجرا می‌کند.
// بررسی بصری/چیدمان در مرورگر واقعی را جایگزین نمی‌کند؛ فقط اتصال کامپوننت‌ها، کیبورد و ذخیره‌سازی را می‌سنجد.
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { JSDOM } from 'jsdom';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', { url: 'https://kt.test/dashboard.html', pretendToBeVisual: true });
const w = dom.window;
for (const k of ['window', 'document', 'localStorage', 'CustomEvent', 'HTMLElement', 'Event', 'KeyboardEvent', 'MouseEvent', 'MutationObserver', 'getComputedStyle', 'Node']) {
  Object.defineProperty(globalThis, k, { configurable: true, writable: true, value: k === 'window' ? w : w[k] });
}
w.matchMedia = w.matchMedia || (() => ({ matches: false, addListener() {}, removeListener() {} }));
w.Element.prototype.scrollIntoView = () => {};
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
w.ResizeObserver = globalThis.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };

const out = join(mkdtempSync(join(tmpdir(), 'kt-ui-')), 'bundle.mjs');
await build({ entryPoints: ['tests/ui-entry.jsx'], bundle: true, format: 'esm', platform: 'node', outfile: out, jsx: 'automatic', loader: { '.css': 'empty', '.woff2': 'empty' }, logLevel: 'error', define: { 'process.env.NODE_ENV': '"development"' } });
const { h, createRoot, act, PopupApp, DashboardApp, InsightsTab, initTheme } = await import(pathToFileURL(out).href);

let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const $ = (sel, root = w.document) => root.querySelector(sel);
const $$ = (sel, root = w.document) => [...root.querySelectorAll(sel)];
const byText = (sel, text) => $$(sel).find((e) => e.textContent.includes(text));
const flush = () => act(async () => { await new Promise((r) => setTimeout(r, 30)); });
const read = (k) => JSON.parse(w.localStorage.getItem('kt:' + k) || 'null');
const seed = (k, v) => w.localStorage.setItem('kt:' + k, JSON.stringify(v));
const click = (el) => act(async () => { el.dispatchEvent(new w.MouseEvent('click', { bubbles: true })); });
const key = (el, k) => act(async () => { el.dispatchEvent(new w.KeyboardEvent('keydown', { key: k, bubbles: true, cancelable: true })); });
const type = (el, v) => act(async () => {
  Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype, 'value').set.call(el, v);
  el.dispatchEvent(new w.Event('input', { bubbles: true }));
});
let root;
const mount = async (el) => { w.document.body.innerHTML = '<div id="root"></div>'; root = createRoot($('#root')); await act(async () => root.render(el)); await flush(); };
const unmount = async () => { await act(async () => root.unmount()); w.localStorage.clear(); };

// ---------- popup: زمان‌های دلخواه ----------
await mount(h(PopupApp));
assert.ok($('.quote').textContent.trim().length > 6, 'جمله‌ی انگیزشی نمایش داده نشد');
await click($('.chip-add')); await flush();
assert.ok($('.sheet'), 'برگه باز نشد');
assert.equal(w.document.activeElement, $('#custom'), 'فوکوس روی فیلد نیست');
await type($('#custom'), '۴۰'); await key($('#custom'), 'Enter'); await flush();
assert.deepEqual(read('settings').customMinutes, [40]); assert.equal(read('settings').defaultMinutes, 40);
assert.ok(byText('.preset.saved', '۴۰'), 'زمان ذخیره‌شده در فهرست نیست');
ok('popup: دکمه‌ی + فیلد را فوکوس می‌کند؛ Enter زمان را ذخیره و انتخاب می‌کند');

await type($('#custom'), '40'); await key($('#custom'), 'Enter'); await flush();
assert.deepEqual(read('settings').customMinutes, [40]);
await type($('#custom'), '25'); await key($('#custom'), 'Enter'); await flush();
assert.deepEqual(read('settings').customMinutes, [40]); assert.equal(read('settings').defaultMinutes, 25);
ok('popup: مقدار تکراری (حتی پیش‌فرض) ثبت نمی‌شود و فقط انتخاب می‌شود');

await type($('#custom'), '999');
assert.match($('.hint').textContent, /۳۶۰/); assert.equal($('.add-time').disabled, true); assert.equal($('.primary').disabled, true);
await type($('#custom'), '');
ok('popup: مقدار نامعتبر خطای فارسی می‌دهد و دکمه‌ها غیرفعال می‌شوند');

await click($('.saved-pick')); await flush();
assert.equal(read('settings').defaultMinutes, 40);
await click($('.saved-del')); await flush();
assert.deepEqual(read('settings').customMinutes, []); assert.equal(read('settings').defaultMinutes, 25);
assert.equal($$('.preset').length, 5);
ok('popup: انتخاب و حذف زمان ذخیره‌شده؛ زمان‌های پیش‌فرض حذف‌پذیر نیستند');

await key(w.document.body, 'Escape'); await act(async () => { w.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape' })); }); await flush();
assert.equal($('.sheet'), null);
await unmount();
ok('popup: Escape برگه را می‌بندد');

// ---------- popup: خاموش‌کردن جمله‌ها ----------
seed('settings', { showQuotes: false });
await mount(h(PopupApp));
assert.equal($('.quote'), null);
await unmount();
ok('popup: با خاموش بودن جمله‌ها، جایی اشغال نمی‌شود');

// ---------- داشبورد: بخش کارها اختیاری ----------
seed('tasks', [{ id: 't1', text: 'کار قبلی', done: false, createdAt: 1 }]);
w.location.hash = '#tasks';
await mount(h(DashboardApp));
assert.ok(byText('.nav', 'کارهای روزانه') && byText('h1', 'کارهای روزانه'));
assert.ok(w.document.body.textContent.includes('کار قبلی'));
w.location.hash = '#settings'; await act(async () => { w.dispatchEvent(new w.Event('hashchange')); }); await flush();
const sw = $('button[aria-label="نمایش بخش کارهای روزانه"]');
await click(sw); await flush();
assert.equal(read('settings').tasksEnabled, false);
assert.equal(byText('.nav', 'کارهای روزانه'), undefined);
assert.equal(read('tasks').length, 1);
w.location.hash = '#tasks'; await act(async () => { w.dispatchEvent(new w.Event('hashchange')); }); await flush();
assert.ok(byText('h1', 'آمار تمرکز'), 'با بخش پنهان باید به آمار برگردد');
ok('کارها: پنهان‌شدن بخش و فاصله‌ی خالی ندارد، آدرس #tasks به آمار می‌رود، داده‌ها می‌مانند');
w.location.hash = '#settings'; await act(async () => { w.dispatchEvent(new w.Event('hashchange')); }); await flush();
await click($('button[aria-label="نمایش بخش کارهای روزانه"]')); await flush();
w.location.hash = '#tasks'; await act(async () => { w.dispatchEvent(new w.Event('hashchange')); }); await flush();
assert.ok(w.document.body.textContent.includes('کار قبلی'));
ok('کارها: با نمایش دوباره، داده‌های قبلی در دسترس‌اند');
await unmount();

// ---------- تنظیمات: منوی تم با کیبورد، تم شخصی ----------
w.location.hash = '#settings';
await initTheme();
await mount(h(DashboardApp));
const trigger = $('button[aria-label="تم"]');
assert.equal(trigger.getAttribute('aria-expanded'), 'false');
await key(trigger, 'ArrowDown'); await flush();
assert.equal(trigger.getAttribute('aria-expanded'), 'true');
assert.equal($$('[role=option]').length, 8);
assert.equal($$('[role=option]')[0].getAttribute('aria-selected'), 'true');
for (let i = 0; i < 3; i++) await key(trigger, 'ArrowDown');
await key(trigger, 'Enter'); await flush();
assert.equal(read('settings').theme, 'forest'); assert.equal(w.document.documentElement.getAttribute('data-theme'), 'forest');
assert.equal($('[role=listbox]'), null);
ok('منوی تم: باز شدن با کیبورد، ۸ گزینه، انتخاب با Enter و اعمال فوری روی صفحه');

await key($('button[aria-label="تم"]'), 'ArrowDown'); await key($('button[aria-label="تم"]'), 'Escape'); await flush();
assert.equal($('[role=listbox]'), null); assert.equal(read('settings').theme, 'forest');
ok('منوی تم: Escape بدون تغییر انتخاب می‌بندد');

await click(byText('button.btn', 'ساخت تم')); await flush();
const colors = $$('input[type=color]');
await type($('input.text-input'), 'نیمه‌شب'); await type(colors[1], '#222222'); await type(colors[2], '#2a2a2a');
await click(byText('button.btn', 'ذخیره و اعمال')); await flush();
assert.match($('.err').textContent, /تضاد/); assert.equal((read('settings').customThemes || []).length, 0);
ok('تم شخصی: تضاد کم متن/پس‌زمینه رد می‌شود');

await type(colors[2], '#f5f5f5'); await type(colors[0], '#ffb703'); await type(colors[1], '#10151f');
await click(byText('button.btn', 'ذخیره و اعمال')); await flush();
const st = read('settings');
assert.equal(st.customThemes.length, 1); assert.equal(st.theme, st.customThemes[0].id); assert.equal(st.customThemes[0].accent, '#ffb703');
assert.equal(w.document.documentElement.getAttribute('data-theme'), 'custom');
assert.equal(w.document.documentElement.style.getPropertyValue('--star'), '#ffb703');
ok('تم شخصی: ذخیره، انتخاب و اعمال به‌صورت متغیرهای CSS');

await click($('button[aria-label^="حذف تم"]')); await click(byText('button', 'بله، حذف شود')); await flush();
assert.equal(read('settings').customThemes.length, 0); assert.equal(read('settings').theme, 'main');
assert.equal(w.document.documentElement.getAttribute('data-theme'), null); assert.equal(w.document.documentElement.style.getPropertyValue('--star'), '');
ok('تم شخصی: حذف، بازگشت به تم اصلی و پاک‌شدن متغیرها');

// ---------- تنظیمات: منوی صدا ----------
const sound = $('button[aria-label="صدای هشدار"]');
await key(sound, 'ArrowDown'); await flush();
assert.equal($$('[role=option]').length, 4);
await key(sound, 'ArrowDown'); await key(sound, 'Enter'); await flush();
assert.equal(read('settings').soundId, 'chime');
assert.ok(byText('.note', '') === undefined || true);
assert.ok(w.document.body.textContent.includes('قالب‌های قابل‌استفاده'));
ok('منوی صدا: انتخاب با کیبورد؛ قالب‌های پشتیبانی‌شده در رابط اعلام می‌شود');
await unmount();

// ---------- آمار: رکوردها و تقویم ----------
const MIN = 60000;
const mk = (id, d, h, m) => { const t = new Date(2026, 2, d, h, m).getTime(); return { id, startedAt: t, endedAt: t + m * MIN, plannedMs: m * MIN, focusedMs: m * MIN, completed: true, source: 'timer' }; };
await mount(h(InsightsTab, { sessions: [] }));
assert.ok(w.document.body.textContent.includes('هنوز داده‌ی کافی نیست')); assert.equal($('.cal-grid'), null);
await unmount();
ok('رکوردها: بدون داده حالت خالی نشان می‌دهد، نه عدد ساختگی');

await mount(h(InsightsTab, { sessions: [mk('a', 21, 9, 25), mk('b', 21, 12, 25), mk('c', 22, 9, 90)] }));
assert.ok(w.document.body.textContent.includes('۹۰') || w.document.body.textContent.includes('۱ ساعت و ۳۰ دقیقه'));
assert.equal($$('[role=columnheader]')[0].getAttribute('aria-label'), 'شنبه');
assert.ok(byText('.fig', 'طولانی‌ترین جلسه').textContent.includes('یکشنبه'));
await unmount();
ok('رکوردها: روز هفته‌ی شمسی طولانی‌ترین جلسه و سرستون تقویم از شنبه');
console.log('UI smoke tests complete');
process.exit(0);
