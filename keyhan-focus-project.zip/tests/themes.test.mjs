// اجرا: node tests/themes.test.mjs  (تم‌های آماده، تم شخصی، اعتبارسنجی رنگ و تضاد)
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const C = await import('../src/core/themeColors.js');
const T = await import('../src/core/themes.js');
const B = await import('../src/core/backup.js');
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);

// تم‌های آماده‌ی CSS: سازگاری با متغیرها و تضاد کافی
const css = readFileSync(new URL('../src/styles/themes.css', import.meta.url), 'utf8') + readFileSync(new URL('../src/styles/base.css', import.meta.url), 'utf8');
const block = (id) => {
  const re = id === 'main' ? /:root,\s*\[data-theme='main'\]\s*\{([^}]*)\}/ : new RegExp(`\\[data-theme='${id}'\\]\\s*\\{([^}]*)\\}`);
  const m = re.exec(css); assert.ok(m, `تم ${id} در CSS نیست`);
  return Object.fromEntries([...m[1].matchAll(/--([\w-]+):\s*([^;]+);/g)].map((x) => [x[1], x[2].trim()]));
};
for (const t of T.THEMES) {
  const v = block(t.id);
  for (const k of ['night', 'night-2', 'night-3', 'line', 'ink', 'mute', 'star', 'star-dim', 'danger', 'on-star', 'scrim', 'bar-today']) assert.ok(v[k], `${t.id}: --${k}`);
  assert.ok(C.contrast(v.ink, v.night) >= 7, `${t.id} ink/night`);
  assert.ok(C.contrast(v.mute, v.night) >= 4.5, `${t.id} mute/night = ${C.contrast(v.mute, v.night).toFixed(2)}`);
  assert.ok(C.contrast(v.star, v.night) >= 3, `${t.id} star/night`);
  assert.ok(C.contrast(v['on-star'], v.star) >= 4.5, `${t.id} on-star/star`);
  assert.ok(C.contrast(v.danger, v.night) >= 3, `${t.id} danger/night`);
  assert.ok(T.BADGE_COLORS[t.id] && T.OVERLAY_COLORS[t.id], `${t.id}: رنگ نشان و اعلان`);
  assert.equal(T.OVERLAY_COLORS[t.id].accent.toLowerCase(), v.star.toLowerCase(), `${t.id}: رنگ اعلان با CSS هم‌خوان است`);
}
ok(`همه‌ی ${T.THEMES.length} تم آماده: متغیرها کامل، تضاد کافی، رنگ نشان/اعلان هم‌خوان`);

// اعتبارسنجی تم شخصی
const good = { name: 'شب من', accent: '#FFAA00', bg: '#101820', ink: '#F5F5F5' };
let r = C.validateCustomTheme(good);
assert.equal(r.ok, true); assert.equal(r.theme.accent, '#ffaa00');
for (const bad of [
  { ...good, accent: 'red' }, { ...good, accent: '#fff' }, { ...good, bg: 'url(x)' }, { ...good, ink: '#12345g' },
  { ...good, ink: 'red; background:url(//evil)' }, { ...good, accent: 'var(--x)' }, { ...good, name: '' }, { ...good, name: 'x'.repeat(25) },
]) assert.equal(C.validateCustomTheme(bad).ok, false, JSON.stringify(bad));
ok('فقط hex شش‌رقمی پذیرفته می‌شود؛ CSS آزاد، نام رنگ و url رد می‌شوند');

assert.equal(C.validateCustomTheme({ ...good, ink: '#202830' }).field, 'ink');
assert.equal(C.validateCustomTheme({ ...good, accent: '#141c24' }).field, 'accent');
assert.equal(C.validateCustomTheme({ name: 'روشن', accent: '#1d4ed8', bg: '#ffffff', ink: '#111827' }).ok, true);
ok('تضاد کم متن/تأکیدی رد می‌شود؛ تم روشن معتبر پذیرفته می‌شود');

// متغیرهای مشتق: فقط hex/rgba؛ هیچ رشته‌ی دلخواهی نیست
const vars = C.deriveVars(r.theme);
assert.deepEqual(Object.keys(vars).sort(), [...C.CUSTOM_VAR_NAMES].sort());
for (const v of Object.values(vars)) assert.match(v, /^(#[0-9a-f]{6}|rgba\(\d+, \d+, \d+, [\d.]+\))$/);
assert.ok(C.contrast(vars['--ink'], vars['--night']) >= 4.5 && C.contrast(vars['--on-star'], vars['--star']) >= 4.5);
ok('متغیرهای مشتق‌شده امن‌اند و رنگ روی تأکیدی خوانا می‌ماند');

// پاک‌سازی فهرست (مثلاً از فایل پشتیبان دست‌کاری‌شده)
const id1 = C.newCustomId(); const id2 = C.newCustomId();
const list = C.normalizeCustomThemes([
  { id: id1, ...good }, { id: id1, ...good }, { id: 'custom-../../x', ...good }, { id: id2, ...good, accent: 'javascript:1' }, { id: 'main', ...good }, null,
]);
assert.deepEqual(list.map((t) => t.id), [id1]);
const many = Array.from({ length: 10 }, () => ({ id: C.newCustomId(), ...good }));
assert.equal(C.normalizeCustomThemes(many).length, C.MAX_CUSTOM_THEMES);
ok('پاک‌سازی: شناسه‌ی نامعتبر، تکراری و رنگ خراب حذف می‌شود؛ سقف تعداد رعایت می‌شود');

// themeIdOf / resolveTheme
assert.equal(T.themeIdOf('sand'), 'sand'); assert.equal(T.themeIdOf('nope'), 'main');
assert.equal(T.themeIdOf(id1), 'main'); assert.equal(T.themeIdOf(id1, [{ id: id1, ...good }]), id1);
const rt = T.resolveTheme({ theme: id1, customThemes: [{ id: id1, ...good }] });
assert.equal(rt.id, id1); assert.equal(rt.badge.running, '#ffaa00'); assert.equal(rt.overlay.accent, '#ffaa00');
assert.equal(T.resolveTheme({ theme: id1 }).id, 'main'); // تم شخصی حذف‌شده → تم اصلی
assert.equal(T.resolveTheme(undefined).id, 'main');
ok('تم شخصی حذف‌شده یا ناموجود به تم اصلی برمی‌گردد؛ نشان و اعلان از رنگ شخصی ساخته می‌شود');

// پشتیبان: تم و فهرست با هم اعتبارسنجی می‌شوند
const bk = B.parseBackup(JSON.stringify({ settings: { theme: id1, customThemes: [{ id: id1, ...good }, { id: 'zzz', ...good }], soundId: 'custom' } }));
assert.equal(bk.ok, true); assert.equal(bk.data.settings.theme, id1); assert.equal(bk.data.settings.customThemes.length, 1); assert.equal(bk.data.settings.soundId, 'ding');
const bk2 = B.parseBackup(JSON.stringify({ settings: { theme: id1, customThemes: [] } }));
assert.equal(bk2.data.settings.theme, 'main');
ok('بازیابی پشتیبان: تم شخصی بدون تعریف معتبر به تم اصلی می‌افتد');
