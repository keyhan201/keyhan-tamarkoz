// اجرا: node tests/daily.test.mjs  (برای مناطق زمانی مختلف هم اجرا کنید: TZ=America/New_York node ...)
import assert from 'node:assert/strict';
import { addDays, buildComparison, dayStats, sessionsOfDay, startOfDay } from '../src/core/dailyStats.js';

let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const at = (y, m, d, h = 10) => new Date(y, m - 1, d, h, 0).getTime();
const S = (id, ts, min, extra = {}) => ({ id, startedAt: ts, focusedMs: min * 60000, completed: true, ...extra });

// پیمایش روز به روز، از جمله مرز ماه/سال و تغییر ساعت تابستانی
let d = startOfDay(at(2026, 3, 1));
const seen = [];
for (let i = 0; i < 900; i++) { const nx = addDays(d, 1); assert.equal(new Date(nx).getHours(), 0); assert.equal(addDays(nx, -1), d); seen.push(nx); d = nx; }
const keys = new Set(seen.map((t) => new Date(t).toDateString()));
assert.equal(keys.size, 900);
ok('«بعدی/قبلی» همیشه دقیقاً یک روز جابه‌جا می‌شود (۹۰۰ روز، بدون پرش/تکرار در تغییر ساعت)');

// آمار فقط جلسه‌ی کامل همان روز
const today = startOfDay(at(2026, 10, 25));
const yday = addDays(today, -1);
const sessions = [
  S('a', at(2026, 10, 25, 9), 25), S('b', at(2026, 10, 25, 11), 35), S('c', at(2026, 10, 25, 23), 20), // امروز: ۸۰ دقیقه، ۳ جلسه
  S('d', at(2026, 10, 24, 8), 30), S('e', at(2026, 10, 24, 23), 30), // دیروز: ۶۰، ۲ جلسه
  S('x', at(2026, 10, 25, 12), 50, { completed: false }), // نیمه‌کاره: شمرده نمی‌شود
  S('y', at(2026, 10, 23, 12), 99),
];
assert.equal(sessionsOfDay(sessions, today).length, 3);
assert.deepEqual(dayStats(sessions, today), { count: 3, totalMs: 80 * 60000, avgMs: (80 / 3) * 60000, longestMs: 35 * 60000 });
ok('آمار روز: فقط جلسه‌های کامل‌شده‌ی همان روز');

// مقایسه نوشتاری
let { rows } = buildComparison(sessions, today);
const by = (id) => rows.find((r) => r.id === id);
assert.deepEqual([by('focus').current, by('focus').previous, by('focus').change], ['۱ ساعت و ۲۰ دقیقه', '۱ ساعت', '۲۰ دقیقه بیشتر']);
assert.deepEqual([by('count').current, by('count').previous, by('count').change], ['۳ جلسه', '۲ جلسه', '۱ جلسه بیشتر']);
assert.equal(by('avg').change, '۳ دقیقه کمتر'); assert.equal(by('longest').current, '۳۵ دقیقه');
ok('مقایسه با روز قبل: مقدار هر دو روز و تغییر (بیشتر/کمتر)');

// کمتر، بدون تغییر
({ rows } = buildComparison(sessions, yday));
assert.equal(rows.find((r) => r.id === 'focus').change, '۳۹ دقیقه کمتر'); // ۶۰ دقیقه‌ی ۲۴ام در برابر ۹۹ دقیقه‌ی ۲۳ام
const eq = buildComparison([S('p', at(2026, 10, 24), 30), S('q', at(2026, 10, 25), 30)], today).rows;
assert.equal(eq.find((r) => r.id === 'focus').change, 'بدون تغییر'); assert.equal(eq.find((r) => r.id === 'count').change, 'بدون تغییر');
ok('روز برابر: «بدون تغییر»');

// روز بدون داده / روز بدون جلسه‌ی قبل
const empty = buildComparison(sessions, addDays(today, -30));
assert.equal(empty.cur.count, 0); assert.equal(empty.rows.length, 3);
assert.equal(empty.rows[0].current, '۰ دقیقه'); assert.equal(empty.rows[1].current, '۰ جلسه'); assert.equal(empty.rows[2].current, 'جلسه‌ای نیست');
const onlyToday = buildComparison([S('z', at(2026, 10, 25), 25)], today).rows;
assert.equal(onlyToday.find((r) => r.id === 'avg').change, 'قابل مقایسه نیست');
assert.equal(onlyToday.find((r) => r.id === 'focus').change, '۲۵ دقیقه بیشتر');
ok('روز بدون داده: صفر/پیام کوتاه؛ میانگین بدون روز قبل قابل مقایسه نیست و آمار ساختگی نیست');

// روز آینده: هیچ جلسه‌ای ندارد
assert.equal(dayStats(sessions, addDays(today, 3)).count, 0);
ok('روز آینده آمار ندارد');
