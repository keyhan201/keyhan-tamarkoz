// اجرا: node tests/garden.test.mjs — قواعد رشد باغ
import assert from "node:assert/strict";
const store = {};
globalThis.chrome = { storage: { local: { get: async (k) => ({ [k]: store[k] === undefined ? undefined : JSON.parse(JSON.stringify(store[k])) }), set: async (o) => { for (const k in o) store[k] = JSON.parse(JSON.stringify(o[k])); } } } };
let chain = Promise.resolve();
Object.defineProperty(globalThis, "navigator", { configurable: true, value: { locks: { request: (_n, fn) => { const r = chain.then(fn); chain = r.catch(() => {}); return r; } } } });
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const t0 = 1_700_000_000_000;
const S = (id, min, extra = {}) => ({ id, startedAt: t0 + Number(String(id).replace(/\D/g, "") || 0) * 1e7, endedAt: t0 + Number(String(id).replace(/\D/g, "") || 0) * 1e7 + min * 60000, plannedMs: min * 60000, focusedMs: min * 60000, completed: true, source: "timer", ...extra });
const G = await import('../src/core/garden.js');

let g = G.gardenFromSessions([]);
assert.equal(g.flowers, 0); assert.equal(g.current.points, 0); assert.equal(g.current.stage.id, 'seed');
ok('بدون جلسه: بذر، صفر گل');

g = G.gardenFromSessions([S('1', 9), S('2', 25)]);
assert.equal(g.totalPoints, 25, 'جلسه‌ی کمتر از ۱۰ دقیقه رشد ندارد'); assert.equal(g.current.stage.id, 'sprout'); assert.equal(g.countedSessions, 1);
ok('جلسه‌ی کوتاه رشد ندارد؛ ۲۵ دقیقه = جوانه');

g = G.gardenFromSessions([S('1', 25), S('2', 25), S('3', 15)]);
assert.equal(g.current.points, 65); assert.equal(g.current.stage.id, 'sapling'); assert.equal(g.current.remaining, 35);
ok('۶۵ امتیاز = نهال، ۳۵ تا شکوفه');

g = G.gardenFromSessions([S('1', 60), S('2', 60), S('3', 30)]);
assert.equal(g.flowers, 1); assert.equal(g.current.points, 50); assert.equal(g.kinds.length, 1);
ok('هر ۱۰۰ امتیاز یک گل؛ باقی‌مانده به گیاه بعدی می‌رود');

g = G.gardenFromSessions([S('1', 600)]);
assert.equal(g.totalPoints, 120, 'سقف رشد هر جلسه'); ok('سقف ۱۲۰ امتیاز برای هر جلسه');

g = G.gardenFromSessions([S('1', 30, { source: 'manual' }), S('2', 30, { completed: false }), S('3', 30), S('3', 30)]);
assert.equal(g.totalPoints, 30); ok('جلسه‌ی دستی، ناقص و تکراری رشد نمی‌دهند');

g = G.gardenFromSessions(Array.from({ length: 12 }, (_, i) => S(String(i + 1), 50)));
assert.equal(g.flowers, 6); assert.deepEqual(g.kinds.slice(0, 6), ['tulip', 'daisy', 'sunflower', 'lavender', 'poppy', 'tulip']);
ok('نوع گل‌ها قطعی و چرخشی است');

assert.deepEqual(G.gardenFromSessions(null).current.points, 0); assert.equal(G.stageOf(NaN).id, 'seed');
ok('ورودی خراب بدون خطا');
