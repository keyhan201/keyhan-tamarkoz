// اجرا: node tests/mobilequotes.test.mjs — ۱۰۰ جمله‌ی پایان جلسه‌ی اندروید
import assert from 'node:assert/strict';
const { MOBILE_END_QUOTES, MOBILE_QUOTES } = await import('../src/data/quotesMobile.js');
const { QUOTES_BY_CATEGORY: D } = await import('../src/data/quotes.js');
const Q = await import('../src/core/quotes.js');
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);

assert.equal(MOBILE_END_QUOTES.length, 100); assert.equal(D.end.length, 60);
assert.deepEqual(MOBILE_END_QUOTES.slice(0, 60).map((q) => q.text), D.end, 'جمله‌های موجود دست‌نخورده‌اند');
ok('۱۰۰ جمله‌ی پایان: ۶۰ جمله‌ی موجود + ۴۰ جمله‌ی تازه');

const texts = MOBILE_END_QUOTES.map((q) => q.text);
const norm = (s) => s.replace(/[\s‌.،؛!؟?:«»"'…\-–]/g, '');
assert.equal(new Set(texts.map(norm)).size, 100);
const tokens = (s) => new Set(s.replace(/[.،؛!؟?:]/g, ' ').split(/\s+/).filter((w) => w.length > 1));
for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
  const a = tokens(texts[i]); const b = tokens(texts[j]);
  const inter = [...a].filter((w) => b.has(w)).length;
  assert.ok(inter / (a.size + b.size - inter || 1) < 0.7, `شبیه به هم: «${texts[i]}» / «${texts[j]}»`);
}
ok('بدون جمله‌ی تکراری یا بسیار مشابه');

for (const s of texts) {
  assert.ok(s.length >= 8 && s.length <= 90, `طول: ${s}`);
  assert.ok(/[\u0600-\u06FF]/.test(s) && !/[A-Za-z<>{}]/.test(s), `نویسه: ${s}`);
  assert.ok(!/\s{2,}|\.\.|^\s|\s$/.test(s), `فاصله: ${s}`);
  assert.ok(!/(حتماً|مجبوری|باید همین|تنبل|بی‌عرضه|تضمین)/.test(s), `لحن: ${s}`);
}
ok('هر جمله فارسی، کوتاه و بدون لحن دستوری/سرزنش‌گر');

let recent = []; const seen = [];
for (let i = 0; i < 80; i++) { const q = Q.pickQuote('end', recent, Math.random, MOBILE_QUOTES); seen.push(q.id); recent = Q.pushRecent(recent, q.id); }
for (let i = 1; i < seen.length; i++) assert.notEqual(seen[i], seen[i - 1]);
for (let i = 25; i < seen.length; i++) assert.ok(!seen.slice(i - 25, i).includes(seen[i]), 'تکرار در ۲۵ جمله‌ی اخیر');
ok('انتخاب: جمله‌ی ۲۵ بار اخیر تکرار نمی‌شود (با ۱۰۰ جمله)');

console.log('نمونه:', MOBILE_END_QUOTES.slice(60, 63).map((q) => q.text).join(' | '));
