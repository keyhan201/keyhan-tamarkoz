// اجرا: node tests/export.test.mjs
import assert from 'node:assert/strict';
const E = await import('../src/core/exportStats.js');
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const MIN = 60000;
const s = (id, d, h, m, minutes, extra = {}) => { const t = new Date(2026, 2, d, h, m).getTime(); return { id, startedAt: t, endedAt: t + minutes * MIN, plannedMs: minutes * MIN, focusedMs: minutes * MIN, completed: true, source: 'timer', ...extra }; };

assert.equal(E.sessionsToCsv([]), '\ufeff' + E.CSV_HEADER.join(',') + '\r\n');
ok('بدون جلسه: فقط سرستون (و BOM برای Excel)');

const csv = E.sessionsToCsv([s('b', 22, 9, 0, 30), s('a', 21, 8, 30, 25), s('bad', 21, 1, 1, 0, { focusedMs: 0 }), s('a', 21, 8, 30, 25)]);
const lines = csv.trim().split('\r\n');
assert.equal(lines.length, 3);
assert.equal(lines[1], 'a,timer,1405/01/01,2026-03-21,شنبه,08:30,08:55,25,25');
assert.equal(lines[2], 'b,timer,1405/01/02,2026-03-22,یکشنبه,09:00,09:30,30,30');
ok('CSV: مرتب بر اساس زمان، تاریخ شمسی و میلادی، نام روز، بدون جلسه‌ی نامعتبر/تکراری');

assert.equal(E.csvCell('=HYPERLINK("x")'), '"\'=HYPERLINK(""x"")"');
assert.equal(E.csvCell('+1'), "'+1"); assert.equal(E.csvCell('@a'), "'@a"); assert.equal(E.csvCell('a,b'), '"a,b"'); assert.equal(E.csvCell(null), '');
ok('ایمنی CSV: تزریق فرمول خنثی و نقل‌قول درست');

const legacy = { id: 'old', startedAt: new Date(2026, 2, 21, 20).getTime(), focusedMs: 10 * MIN, completed: true };
assert.match(E.sessionsToCsv([legacy]).trim().split('\r\n')[1], /,,10$/);
ok('جلسه‌ی قدیمی بدون زمان برنامه‌ریزی‌شده: ستون برنامه خالی (عدد ساختگی نیست)');

const j = JSON.parse(E.dailySummaryJson([s('a', 21, 8, 30, 25), s('c', 21, 10, 0, 25), legacy, s('b', 22, 9, 0, 30)], 1_800_000_000_000));
assert.equal(j.days.length, 2);
assert.deepEqual(j.days[0], { date_jalali: '1405/01/01', date_iso: '2026-03-21', weekday: 'شنبه', sessions: 3, focused_minutes: 60, planned_minutes: 50, sessions_without_plan: 1 });
assert.equal(j.days[1].planned_minutes, 30);
ok('JSON روزانه: جمع جلسه/تمرکز/برنامه‌ریزی‌شده و شمار جلسه‌های بدون برنامه');
