// اجرا: node tests/quotes.test.mjs  (مجموعه‌ی ۲۰۰ جمله و منطق انتخاب)
import assert from 'node:assert/strict';
const { QUOTES_BY_CATEGORY: D } = await import('../src/data/quotes.js');
const Q = await import('../src/core/quotes.js');
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);

const all = Object.values(D).flat();
assert.equal(all.length, 200);
assert.deepEqual(Object.keys(D), ['start', 'keep', 'end']);
assert.ok(Object.values(D).every((l) => l.length >= 50));
ok('دقیقاً ۲۰۰ جمله در سه دسته (شروع/ادامه/پایان)، هر دسته دست‌کم ۵۰ جمله');

const norm = (s) => s.replace(/[\s‌.،؛!؟?:«»"'…\-–]/g, '');
assert.equal(new Set(all.map(norm)).size, 200);
const tokens = (s) => new Set(s.replace(/[.،؛!؟?:]/g, ' ').split(/\s+/).filter((w) => w.length > 1));
for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) {
  const a = tokens(all[i]); const b = tokens(all[j]);
  const inter = [...a].filter((w) => b.has(w)).length;
  const jac = inter / (a.size + b.size - inter || 1);
  assert.ok(jac < 0.7, `شبیه به هم: «${all[i]}» / «${all[j]}»`);
}
ok('بدون جمله‌ی تکراری یا تغییر جزئیِ همدیگر (شباهت واژگانی < ۰٫۷)');

for (const s of all) {
  assert.ok(s.length >= 8 && s.length <= 90, `طول نامناسب: ${s}`);
  assert.ok(/[\u0600-\u06FF]/.test(s) && !/[A-Za-z<>{}]/.test(s), `نویسه‌ی نامجاز: ${s}`);
  assert.ok(!/\s{2,}|\.\.|^\s|\s$/.test(s), `فاصله/نقطه‌ی خراب: ${s}`);
  assert.ok(!/(حتماً|مجبوری|باید همین|تنبل|بی‌عرضه|تضمین)/.test(s), `لحن نامناسب: ${s}`);
}
ok('هر جمله فارسی، کوتاه (≤ ۹۰ نویسه) و بدون لحن دستوری/سرزنش‌گر یا وعده‌ی تضمینی');

assert.equal(Q.ALL_QUOTES.length, 200);
assert.equal(new Set(Q.ALL_QUOTES.map((q) => q.id)).size, 200);
ok('شناسه‌ی یکتا برای هر جمله');

// انتخاب: تکرار نشدن اخیرها
let recent = [];
const seen = [];
for (let i = 0; i < 60; i++) {
  const q = Q.pickQuote('end', recent);
  assert.equal(q.category, 'end');
  assert.ok(!recent.slice(-Q.RECENT_LIMIT).includes(q.id), 'تکرار در پنجره‌ی اخیر');
  recent = Q.pushRecent(recent, q.id); seen.push(q.id);
}
assert.ok(new Set(seen).size > 40);
ok('۶۰ انتخاب پیاپی: هیچ جمله‌ای در پنجره‌ی ۲۵تایی اخیر تکرار نشد و تنوع بالاست');

// تصادفی بودن و مرزهای rng
assert.equal(Q.pickQuote('start', [], () => 0).id, 'start-0');
assert.equal(Q.pickQuote('start', [], () => 0.999999).id, 'start-69');
assert.equal(Q.pickQuote('start', [], () => NaN).id, 'start-0');
assert.equal(Q.pickQuote('nope', []), null);
ok('مرزهای تصادفی‌ساز و دسته‌ی ناموجود');

// اگر اخیرها همه‌ی دسته را بپوشانند، باز هم جمله‌ای برمی‌گردد (دسته‌ی کوچک)
const tiny = [{ id: 't-0', category: 't', text: 'الف' }, { id: 't-1', category: 't', text: 'ب' }];
assert.equal(Q.pickQuote('t', ['t-0'], () => 0, tiny).id, 't-1');
assert.ok(Q.pickQuote('t', ['t-0', 't-1'], () => 0, tiny));
assert.equal(Q.pickQuote('t', undefined, () => 0, [{ id: 'only', category: 't', text: 'x' }]).id, 'only');
ok('دسته‌ی کوچک: اخیرها همه‌ی جمله‌ها را حذف نمی‌کنند');

assert.deepEqual(Q.pushRecent(['a', 'b'], 'a'), ['b', 'a']);
assert.equal(Q.pushRecent(Array.from({ length: 30 }, (_, i) => `x${i}`), 'new').length, Q.RECENT_LIMIT);
assert.deepEqual(Q.pushRecent('خراب', 'z'), ['z']);
ok('ردیف اخیرها: بدون تکرار، سقف‌دار و مقاوم در برابر داده‌ی خراب');

const now = 1_800_000_000_000;
assert.equal(Q.categoryFor({ status: 'running' }, now), 'keep');
assert.equal(Q.categoryFor({ status: 'paused' }, now), 'keep');
assert.equal(Q.categoryFor({ status: 'idle', lastResult: { at: now - 60_000 } }, now), 'end');
assert.equal(Q.categoryFor({ status: 'idle', lastResult: { at: now - 3 * 3600_000 } }, now), 'start');
assert.equal(Q.categoryFor({ status: 'idle', lastResult: null }, now), 'start');
assert.equal(Q.categoryFor(null, now), 'start');
ok('دسته بر اساس وضعیت تایمر (شروع/ادامه/پایان)');
