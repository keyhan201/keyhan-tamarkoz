// اجرا: node tests/break.test.mjs — تایمر استراحت (مستقل از تمرکز) و پایان آن
import assert from "node:assert/strict";
const store = {};
globalThis.chrome = { storage: { local: { get: async (k) => ({ [k]: store[k] === undefined ? undefined : JSON.parse(JSON.stringify(store[k])) }), set: async (o) => { for (const k in o) store[k] = JSON.parse(JSON.stringify(o[k])); } } } };
let chain = Promise.resolve();
Object.defineProperty(globalThis, "navigator", { configurable: true, value: { locks: { request: (_n, fn) => { const r = chain.then(fn); chain = r.catch(() => {}); return r; } } } });
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const t0 = 1_700_000_000_000;
const S = (id, min, extra = {}) => ({ id, startedAt: t0 + Number(String(id).replace(/\D/g, "") || 0) * 1e7, endedAt: t0 + Number(String(id).replace(/\D/g, "") || 0) * 1e7 + min * 60000, plannedMs: min * 60000, focusedMs: min * 60000, completed: true, source: "timer", ...extra });
const T = await import('../src/core/timerService.js');
const sessions = () => store.sessions || [];

assert.equal(await T.startBreak(0, t0), false); assert.equal(await T.startBreak(61, t0), false); assert.equal(await T.startBreak(2.5, t0), false);
ok('مدت استراحت فقط عدد صحیح ۱ تا ۶۰ است');

assert.equal(await T.startBreak(5, t0), true);
let t = await T.getTimer();
assert.equal(t.kind, 'break'); assert.equal(t.status, 'running'); assert.equal(t.durationSeconds, 300);
assert.equal(T.canInterrupt(t, t0 + 120000), true, 'استراحت را هر زمان می‌شود رد کرد');
assert.equal(await T.pauseTimer(t0 + 1000), false, 'استراحت مکث ندارد');
ok('استراحت جدا از تمرکز شروع می‌شود، رد‌کردنش آزاد است و مکث ندارد');

assert.equal(await T.completeTimer(t0 + 299000), null); t = await T.getTimer(); assert.equal(t.status, 'running');
assert.equal(await T.completeTimer(t0 + 300500), null, 'استراحت جلسه برنمی‌گرداند');
t = await T.getTimer();
assert.equal(t.status, 'idle'); assert.equal(t.kind, 'focus'); assert.equal(t.lastResult.kind, 'break'); assert.equal(t.lastResult.minutes, 5);
assert.equal(sessions().length, 0, 'استراحت هیچ جلسه‌ای ثبت نمی‌کند');
ok('پایان استراحت: idle، lastResult از نوع break، بدون ثبت جلسه');

assert.equal(await T.startTimer(25, t0 + 1e6), true);
assert.equal(await T.startBreak(5, t0 + 1e6 + 1000), false); assert.equal((await T.getTimer()).kind, 'focus');
ok('وسط تمرکز، استراحت شروع نمی‌شود');

await T.completeTimer(t0 + 1e6 + 25 * 60000 + 100);
assert.equal(sessions().length, 1); t = await T.getTimer(); assert.equal(t.lastResult.kind, 'focus');
await T.startBreak(10, t0 + 2e6); assert.equal(await T.cancelTimer(t0 + 2e6 + 30000), true);
assert.equal((await T.getTimer()).status, 'idle'); assert.equal(sessions().length, 1);
ok('تمرکز جلسه ثبت می‌کند؛ رد کردن استراحت چیزی ثبت یا حذف نمی‌کند');

const V = await import('../src/core/sessions.js');
await T.startBreak(5, t0 + 3e6);
const r = V.validateManual({ jy: 1405, jm: 1, jd: 1, start: '10:00', end: '10:30' }, { now: Date.now(), sessions: [], timer: await T.getTimer() });
assert.notEqual(r.field, 'start', 'استراحت با ثبت دستی هم‌پوشانی خطا نمی‌دهد');
ok('جلسه‌ی دستی با استراحت در حال اجرا تداخل ایجاد نمی‌کند');

// داده‌ی قدیمی بدون kind
const N = T.normalizeTimer({ status: 'running', durationSeconds: 60, startedAt: t0, endsAt: t0 + 60000, sessionId: 'x' });
assert.equal(N.kind, 'focus'); ok('تایمر قدیمی بدون kind به تمرکز مهاجرت می‌کند');
