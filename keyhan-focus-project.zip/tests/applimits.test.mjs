// اجرا: node tests/applimits.test.mjs — انتخاب برنامه‌ها و تصمیم هشدار
import assert from "node:assert/strict";
const store = {};
globalThis.chrome = { storage: { local: { get: async (k) => ({ [k]: store[k] === undefined ? undefined : JSON.parse(JSON.stringify(store[k])) }), set: async (o) => { for (const k in o) store[k] = JSON.parse(JSON.stringify(o[k])); } } } };
let chain = Promise.resolve();
Object.defineProperty(globalThis, "navigator", { configurable: true, value: { locks: { request: (_n, fn) => { const r = chain.then(fn); chain = r.catch(() => {}); return r; } } } });
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const t0 = 1_700_000_000_000;
const S = (id, min, extra = {}) => ({ id, startedAt: t0 + Number(String(id).replace(/\D/g, "") || 0) * 1e7, endedAt: t0 + Number(String(id).replace(/\D/g, "") || 0) * 1e7 + min * 60000, plannedMs: min * 60000, focusedMs: min * 60000, completed: true, source: "timer", ...extra });
const A = await import('../src/core/appLimits.js');

assert.deepEqual(A.normalizePackages(['com.a.b', 'com.a.b', 'bad', 'x..y', 5, null, A.SELF_PACKAGE, 'org.test.app']), ['com.a.b', 'org.test.app']);
assert.deepEqual(A.normalizePackages('x'), []);
assert.equal(A.normalizePackages(Array.from({ length: 50 }, (_, i) => 'com.app.p' + i)).length, A.MAX_LIMITED_APPS);
ok('فقط نام بسته‌ی معتبر، بدون تکرار و بدون خود اپ، با سقف');

assert.deepEqual(A.togglePackage(['com.a.b'], 'com.c.d'), ['com.a.b', 'com.c.d']);
assert.deepEqual(A.togglePackage(['com.a.b', 'com.c.d'], 'com.a.b'), ['com.c.d']);
ok('افزودن و برداشتن انتخاب');

const on = { limitEnabled: true, limitedApps: ['com.social.app'] };
const run = { status: 'running', kind: 'focus' };
const base = { timer: run, settings: on, foreground: 'com.social.app', now: 100000, lastWarnAt: 0 };
assert.equal(A.shouldWarn(base), true);
assert.equal(A.shouldWarn({ ...base, foreground: 'com.other.app' }), false);
assert.equal(A.shouldWarn({ ...base, foreground: A.SELF_PACKAGE }), false);
assert.equal(A.shouldWarn({ ...base, settings: { ...on, limitEnabled: false } }), false);
ok('هشدار فقط برای برنامه‌ی منتخب و وقتی قابلیت روشن است');

assert.equal(A.shouldWarn({ ...base, timer: { status: 'running', kind: 'break' } }), false);
assert.equal(A.shouldWarn({ ...base, timer: { status: 'paused', kind: 'focus' } }), false);
assert.equal(A.shouldWarn({ ...base, timer: { status: 'idle', kind: 'focus' } }), false);
ok('در استراحت، توقف و حالت آماده هشداری نیست');

assert.equal(A.shouldWarn({ ...base, lastWarnAt: 100000 - 5000 }), false);
assert.equal(A.shouldWarn({ ...base, lastWarnAt: 100000 - A.WARN_COOLDOWN_MS }), true);
ok('هشدار پشت‌سرهم تکرار نمی‌شود');

// ---- حالت محدودسازی ----
const blk = { timer: run, settings: { blockMode: true }, foreground: 'com.example.game', now: 100000, lastBounceAt: 0 };
assert.equal(A.shouldBounce(blk), true);
assert.equal(A.shouldBounce({ ...blk, settings: { blockMode: false } }), false);
assert.equal(A.shouldBounce({ ...blk, settings: {} }), false);
ok('برگرداندن فقط وقتی حالت محدودسازی روشن است');
assert.equal(A.shouldBounce({ ...blk, timer: { status: 'running', kind: 'break' } }), false);
assert.equal(A.shouldBounce({ ...blk, timer: { status: 'paused', kind: 'focus' } }), false);
assert.equal(A.shouldBounce({ ...blk, timer: { status: 'idle', kind: 'focus' } }), false);
ok('در استراحت، توقف و بین جلسه‌ها برگرداندنی نیست');
for (const pkg of ['com.android.settings', 'com.android.phone', 'com.android.dialer', 'com.google.android.dialer', 'com.android.emergency', 'com.android.systemui', 'com.google.android.permissioncontroller', A.SELF_PACKAGE]) {
  assert.equal(A.shouldBounce({ ...blk, foreground: pkg }), false, pkg);
}
assert.equal(A.shouldBounce({ ...blk, foreground: 'com.my.keyboard', safe: ['com.my.keyboard'] }), false);
ok('تماس، اضطراری، تنظیمات، سیستم و برنامه‌های ایمن پویا هرگز برگردانده نمی‌شوند');
assert.equal(A.shouldBounce({ ...blk, lastBounceAt: 100000 - 500 }), false);
assert.equal(A.shouldBounce({ ...blk, lastBounceAt: 100000 - A.BOUNCE_COOLDOWN_MS }), true);
ok('فاصله‌ی بین دو بار برگرداندن رعایت می‌شود');
