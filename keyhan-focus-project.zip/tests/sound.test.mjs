// اجرا: node tests/sound.test.mjs  (منطق تصمیم صدای پایان؛ پخش واقعی در مرورگر انجام می‌شود)
import assert from 'node:assert/strict';

const store = {};
globalThis.chrome = { storage: { local: { get: async (k) => ({ [k]: store[k] === undefined ? undefined : JSON.parse(JSON.stringify(store[k])) }), set: async (o) => { for (const k in o) store[k] = JSON.parse(JSON.stringify(o[k])); } } } };
let chain = Promise.resolve();
Object.defineProperty(globalThis, 'navigator', { configurable: true, value: { locks: { request: (_n, fn) => { const r = chain.then(fn); chain = r.catch(() => {}); return r; } } } });

const T = await import('../src/core/timerService.js');
const t0 = 1_700_000_000_000;
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const reset = () => { for (const k in store) delete store[k]; };

// اتمام به‌موقع با صدای روشن
reset(); store.settings = { soundEnabled: true, soundId: 'chime' };
await T.startTimer(5, t0);
await T.completeTimer(t0 + 5 * 60000 + 1500);
let t = await T.getTimer();
assert.equal(t.lastResult.sound, 'chime'); assert.equal(t.lastResult.sessionId.length > 0, true); assert.equal(store.sessions.length, 1);
ok('اتمام به‌موقع: صدای انتخاب‌شده تعیین می‌شود');

// تکرار پایان: نه جلسه‌ی دوم، نه صدای دوم
assert.equal(await T.completeTimer(t0 + 5 * 60000 + 2000), null);
assert.equal(store.sessions.length, 1); assert.equal((await T.getTimer()).lastResult.sound, 'chime');
ok('فراخوانی دوباره‌ی پایان چیزی ثبت یا پخش نمی‌کند');

// دو مدعی هم‌زمان
reset(); store.settings = { soundEnabled: true, soundId: 'ding' };
await T.startTimer(5, t0);
const r = await Promise.all([T.completeTimer(t0 + 300_500), T.completeTimer(t0 + 300_500)]);
assert.equal(r.filter(Boolean).length, 1); assert.equal(store.sessions.length, 1);
ok('دو مدعی هم‌زمان: یک جلسه و یک تصمیم صدا');

// صدا خاموش
reset(); store.settings = { soundEnabled: false, soundId: 'ding' };
await T.startTimer(5, t0); await T.completeTimer(t0 + 300_500);
assert.equal((await T.getTimer()).lastResult.sound, null); assert.equal(store.sessions.length, 1);
ok('صدای خاموش: جلسه ثبت می‌شود ولی صدایی تعیین نمی‌شود');

// بازیابی دیرهنگام (مرورگر بسته بود)
reset(); store.settings = { soundEnabled: true, soundId: 'ding' };
await T.startTimer(5, t0); await T.completeTimer(t0 + 300_000 + 3 * 3600_000);
t = await T.getTimer(); assert.equal(t.lastResult.sound, null); assert.equal(store.sessions.length, 1);
ok('بازیابی دیرهنگام: جلسه درست ثبت می‌شود، صدا نه');

// توقف و انصراف صدا ندارند
reset(); store.settings = { soundEnabled: true, soundId: 'ding' };
await T.startTimer(5, t0); await T.pauseTimer(t0 + 3000); await T.cancelTimer(t0 + 4000);
t = await T.getTimer(); assert.equal(t.lastResult, null); assert.equal((store.sessions || []).length, 0);
ok('توقف و انصراف: نه جلسه، نه صدا');

// صدای نامعتبر به پیش‌فرض برمی‌گردد
reset(); store.settings = { soundEnabled: true, soundId: 'nope' };
await T.startTimer(5, t0); await T.completeTimer(t0 + 300_100);
assert.equal((await T.getTimer()).lastResult.sound, 'ding');
ok('شناسه‌ی صدای نامعتبر → دینگ');

// اعلان بصری مستقل از صدا
reset(); store.settings = { soundEnabled: false, soundId: 'ding' };
await T.startTimer(5, t0); await T.completeTimer(t0 + 300_500);
t = await T.getTimer(); assert.equal(t.lastResult.sound, null); assert.equal(t.lastResult.notice, true);
ok('صدا خاموش: اعلان بصری همچنان مجاز است');

reset(); store.settings = { soundEnabled: true, soundId: 'ding' };
await T.startTimer(5, t0); await T.completeTimer(t0 + 300_000 + 3 * 3600_000);
assert.equal((await T.getTimer()).lastResult.notice, false);
ok('بازیابی دیرهنگام: اعلان بصری مجاز نیست');

reset(); await T.startTimer(5, t0); await T.pauseTimer(t0 + 3000); await T.cancelTimer(t0 + 4000);
assert.equal((await T.getTimer()).lastResult, null);
reset(); await T.startTimer(5, t0); await T.completeTimer(t0 + 300_100);
assert.equal(await T.completeTimer(t0 + 300_200), null); assert.equal((await T.getTimer()).lastResult.notice, true);
ok('توقف/انصراف: اعلان نیست؛ پایان دوباره‌ی همان جلسه چیزی تازه نمی‌سازد');
