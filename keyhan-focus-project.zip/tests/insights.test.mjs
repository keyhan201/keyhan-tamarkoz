// اجرا: node tests/insights.test.mjs  — در چند منطقه‌ی زمانی خودش را دوباره اجرا می‌کند.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';

if (!process.env.KT_CHILD) {
  for (const tz of ['Asia/Tehran', 'UTC', 'America/New_York', 'Europe/Berlin']) {
    const r = spawnSync(process.execPath, [new URL(import.meta.url).pathname], { env: { ...process.env, TZ: tz, KT_CHILD: '1' }, encoding: 'utf8' });
    process.stdout.write(r.stdout);
    if (r.status !== 0) { process.stderr.write(`TZ=${tz}\n${r.stderr}`); process.exit(1); }
    console.log(`  (TZ=${tz} موفق)`);
  }
  process.exit(0);
}

const I = await import('../src/core/insights.js');
const { jalaliToDate, weekdayIndex } = await import('../src/core/jalali.js');
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const MIN = 60000;
const mk = (id, y, mo, d, h, min, minutes, extra = {}) => {
  const startedAt = new Date(y, mo - 1, d, h, min).getTime();
  return { id, startedAt, endedAt: startedAt + minutes * MIN, plannedMs: minutes * MIN, focusedMs: minutes * MIN, completed: true, source: 'timer', ...extra };
};

// حالت خالی
let r = I.buildInsights([]);
assert.equal(r.hasData, false); assert.equal(r.longest, null); assert.equal(r.mostSessions, null); assert.equal(r.mostFocus, null);
assert.deepEqual(r.streaks, { current: 0, best: 0, bestFrom: null, bestTo: null });
ok('بدون داده: همه‌ی رکوردها null و زنجیره صفر (مقدار ساختگی نیست)');

// ۲۰۲۶-۰۳-۲۱ (۱ فروردین ۱۴۰۵) شنبه است
const list = [
  mk('a', 2026, 3, 21, 9, 0, 25), mk('b', 2026, 3, 21, 11, 0, 25), mk('c', 2026, 3, 21, 15, 0, 25),
  mk('d', 2026, 3, 22, 9, 0, 90),
  mk('e', 2026, 3, 24, 9, 0, 45), mk('f', 2026, 3, 25, 9, 0, 45), mk('g', 2026, 3, 26, 9, 0, 45), mk('h', 2026, 3, 27, 9, 0, 45),
];
r = I.buildInsights(list, new Date(2026, 2, 27, 20).getTime());
assert.equal(r.longest.focusedMs, 90 * MIN); assert.equal(r.longest.weekday, 'یکشنبه');
assert.equal(r.mostSessions.count, 3); assert.equal(r.mostSessions.weekday, 'شنبه');
assert.equal(r.mostFocus.focusedMs, 90 * MIN); assert.equal(r.mostFocus.weekday, 'یکشنبه');
ok('رکوردها: طولانی‌ترین جلسه، بیشترین جلسه و بیشترین تمرکز با نام روز شمسی');

assert.equal(r.streaks.best, 4); assert.equal(r.streaks.current, 4);
ok('زنجیره: بهترین و فعلی (امروز جلسه دارد)');

// امروز بدون جلسه: از دیروز می‌شمارد؛ دو روز خالی: صفر
assert.equal(I.buildInsights(list, new Date(2026, 2, 28, 8).getTime()).streaks.current, 4);
assert.equal(I.buildInsights(list, new Date(2026, 2, 29, 8).getTime()).streaks.current, 0);
assert.equal(I.buildInsights(list, new Date(2026, 2, 29, 8).getTime()).streaks.best, 4);
ok('زنجیره‌ی فعلی: روز جاری ناتمام حساب نمی‌شود، دو روز خالی آن را می‌شکند');

// زنجیره از روی تغییر ساعت تابستانی (۸ مارس و ۲۹ مارس ۲۰۲۶ در نیویورک/برلین) نشکند
const dst = [];
for (let d = 25; d <= 31; d++) dst.push(mk(`m${d}`, 2026, 3, d, 10, 0, 25));
for (let d = 1; d <= 3; d++) dst.push(mk(`p${d}`, 2026, 4, d, 10, 0, 25));
assert.equal(I.buildInsights(dst, new Date(2026, 3, 3, 23).getTime()).streaks.best, 10);
ok('زنجیره از مرز تغییر ساعت و پایان ماه میلادی بدون شکستن رد می‌شود');

// جلسه‌ی نامعتبر/ناقص/تکراری شمرده نمی‌شود
const dirty = [mk('x', 2026, 3, 21, 9, 0, 25), mk('x', 2026, 3, 21, 9, 0, 25), { id: 'bad', startedAt: NaN, focusedMs: 10 }, mk('no', 2026, 3, 22, 9, 0, 25, { completed: false }), mk('z', 2026, 3, 22, 9, 0, 0, { focusedMs: 0 })];
r = I.buildInsights(dirty);
assert.equal(r.dayMap.size, 1); assert.equal([...r.dayMap.values()][0].count, 1);
ok('جلسه‌ی تکراری، ناقص و نامعتبر شمرده نمی‌شود');

// برنامه‌ریزی‌شده در برابر واقعی
const legacy = { id: 'old', startedAt: new Date(2026, 2, 21, 20).getTime(), focusedMs: 10 * MIN, completed: true };
const partial = mk('p', 2026, 3, 21, 8, 0, 20, { plannedMs: 30 * MIN });
const day = I.buildDayMap([legacy, partial]).values().next().value;
assert.equal(day.plannedMs, 30 * MIN); assert.equal(day.plannedActualMs, 20 * MIN); assert.equal(day.unplanned, 1); assert.equal(day.focusedMs, 30 * MIN);
ok('برنامه‌ریزی‌شده/واقعی جدا نگه داشته می‌شود و جلسه‌ی قدیمی بدون برنامه علامت می‌خورد');

// شبکه‌ی ماه شمسی: ۱ فروردین ۱۴۰۵ شنبه است و ستون اول شنبه
assert.equal(weekdayIndex(jalaliToDate(1405, 1, 1)), 0);
let g = I.monthGrid(1405, 1, I.buildDayMap(list));
assert.equal(g.length, 31); assert.equal(g.weeks[0][0].jd, 1); assert.ok(g.weeks.every((w) => w.length === 7));
const cell = g.weeks.flat().find((c) => c && c.jd === 2);
assert.equal(cell.data.count, 3 - 2); // ۲ فروردین = یکشنبه ۲۲ مارس: یک جلسه
assert.equal(cell.level, 4);
ok('تقویم شمسی: ۱ فروردین در ستون شنبه، سطح فعالیت نسبت به بیشینه');

// ماه ۳۰ روزه‌ی اسفند در سال کبیسه، و چینش با افست غیرصفر
g = I.monthGrid(1403, 12, new Map());
assert.equal(g.length, 30);
assert.equal(g.weeks.flat().filter(Boolean).length, 30);
assert.ok(g.weeks.flat().filter(Boolean).every((c) => c.level === 0 && c.data === null));
ok('اسفند سال کبیسه ۳۰ روز است و ماه بدون داده خالی نمایش داده می‌شود');

assert.deepEqual(I.shiftMonth({ jy: 1405, jm: 1 }, -1), { jy: 1404, jm: 12 });
assert.deepEqual(I.shiftMonth({ jy: 1404, jm: 12 }, 1), { jy: 1405, jm: 1 });
assert.ok(I.compareMonth({ jy: 1405, jm: 2 }, { jy: 1405, jm: 1 }) > 0);
ok('پیمایش ماه شمسی از مرز سال');

// تفکیک روز هفته
const w = I.buildInsights(list).weekdays;
assert.equal(w.rows[0].name, 'شنبه'); assert.equal(w.rows[0].totalMs, 75 * MIN); assert.equal(w.topIndex, 1);
ok('تفکیک روز هفته از شنبه شروع می‌شود و روز پربازده مشخص است');
