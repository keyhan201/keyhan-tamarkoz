// اجرا: node tests/customsound.test.mjs  (اعتبارسنجی فایل صوتی کاربر؛ پخش واقعی فقط در مرورگر ممکن است)
import assert from 'node:assert/strict';
const store = {};
globalThis.chrome = { storage: { local: {
  get: async (k) => ({ [k]: store[k] === undefined ? undefined : JSON.parse(JSON.stringify(store[k])) }),
  set: async (o) => { for (const k in o) { if (JSON.stringify(o[k]).length > 1_000_000) throw new Error('QUOTA_BYTES quota exceeded'); store[k] = JSON.parse(JSON.stringify(o[k])); } },
  remove: async (k) => { delete store[k]; },
} } };
const S = await import('../src/core/customSound.js');
const Snd = await import('../src/core/sounds.js');
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const bytes = (...a) => Uint8Array.from([...a, ...Array(20).fill(0)]);
const str = (s) => [...s].map((c) => c.charCodeAt(0));

assert.equal(S.sniffFormat(bytes(...str('ID3'))), 'mp3');
assert.equal(S.sniffFormat(bytes(0xff, 0xfb, 0x90)), 'mp3');
assert.equal(S.sniffFormat(bytes(...str('RIFF'), 0, 0, 0, 0, ...str('WAVE'))), 'wav');
assert.equal(S.sniffFormat(bytes(...str('OggS'))), 'ogg');
assert.equal(S.sniffFormat(bytes(0, 0, 0, 24, ...str('ftyp'), ...str('M4A '))), 'm4a');
assert.equal(S.sniffFormat(bytes(0x1a, 0x45, 0xdf, 0xa3)), 'webm');
for (const bad of [bytes(...str('<html><script>')), bytes(...str('MZ')), bytes(0, 0, 0, 24, ...str('ftyp'), ...str('heic')), bytes(...str('GIF89a')), new Uint8Array(3)]) assert.equal(S.sniffFormat(bad), null);
ok('امضای فایل: mp3/wav/ogg/m4a/webm شناخته می‌شود؛ HTML، اجرایی، تصویر و فایل کوتاه نه');

let r = S.validateSoundFile({ size: 50_000, name: 'C:\\x\\زنگ.mp3' }, bytes(...str('ID3')));
assert.equal(r.ok, true); assert.equal(r.name, 'زنگ.mp3'); assert.equal(r.format.id, 'mp3');
assert.equal(S.validateSoundFile({ size: 0, name: 'a' }, bytes(...str('ID3'))).ok, false);
r = S.validateSoundFile({ size: S.MAX_SOUND_BYTES + 1, name: 'a.mp3' }, bytes(...str('ID3'))); assert.equal(r.ok, false); assert.match(r.error, /مگابایت/);
r = S.validateSoundFile({ size: 100, name: 'evil.mp3' }, bytes(...str('<svg>'))); assert.equal(r.ok, false); assert.match(r.error, /پشتیبانی/);
r = S.validateSoundFile({ size: 100, name: 'a.m4a' }, bytes(0, 0, 0, 24, ...str('ftyp'), ...str('M4A ')), S.SOUND_FORMATS.filter((f) => f.id !== 'm4a')); assert.equal(r.ok, false); assert.match(r.error, /M4A/);
ok('اعتبارسنجی: اندازه، فایل خالی، پسوند جعلی و قالب ناسازگار با مرورگر — خطای فارسی');

assert.equal(S.checkDuration(5).ok, true); assert.equal(S.checkDuration(S.MAX_SOUND_SECONDS).ok, true);
for (const d of [0, -1, NaN, Infinity, S.MAX_SOUND_SECONDS + 0.1]) assert.equal(S.checkDuration(d).ok, false);
ok('مدت: بیش از سقف، صفر و نامعلوم رد می‌شود');

const raw = new Uint8Array(5000).map((_, i) => i % 256);
assert.deepEqual(S.base64ToBytes(S.bytesToBase64(raw)), raw);
const big = new Uint8Array(S.MAX_SOUND_BYTES).map((_, i) => i % 251);
assert.deepEqual(S.base64ToBytes(S.bytesToBase64(big)), big);
ok('تبدیل base64 برای فایل تا سقف حجم بدون خطا و بدون تغییر');

const sv = await S.saveCustomSound({ name: 'زنگ من.mp3', mime: 'audio/mpeg', bytes: raw, duration: 3.2 });
assert.equal(sv.ok, true);
let got = await S.getCustomSound();
assert.equal(got.name, 'زنگ من.mp3'); assert.equal(got.mime, 'audio/mpeg'); assert.equal(got.duration, 3.2);
await S.removeCustomSound();
assert.equal(await S.getCustomSound(), null);
ok('ذخیره، خواندن و حذف صدای کاربر');

// داده‌ی دست‌کاری‌شده هیچ‌وقت معتبر نیست
for (const t of [
  { name: 'x', mime: 'text/html', data: 'QQ==', duration: 1 },
  { name: 'x', mime: 'audio/mpeg', data: '<script>', duration: 1 },
  { name: 'x', mime: 'audio/mpeg', data: 'QQ==', duration: 999 },
  { name: 'x', mime: 'audio/mpeg', data: 'A'.repeat(S.MAX_SOUND_BYTES * 2), duration: 1 },
  { name: 'x', mime: 'audio/mpeg', data: '', duration: 1 }, null, 'str',
]) assert.equal(S.validStoredSound(t), null);
store.customSound = { name: 'x', mime: 'application/x-evil', data: 'QQ==', duration: 1 };
assert.equal(await S.getCustomSound(), null);
ok('داده‌ی ذخیره‌شده‌ی نامعتبر یا دست‌کاری‌شده نادیده گرفته می‌شود');

store.customSound = null; // پر شدن حافظه
const huge = new Uint8Array(S.MAX_SOUND_BYTES).fill(7);
const fail = await S.saveCustomSound({ name: 'a', mime: 'audio/mpeg', bytes: huge, duration: 2 });
assert.equal(fail.ok, false); assert.match(fail.error, /فضای ذخیره‌سازی/);
ok('پر بودن حافظه: پیام روشن فارسی و بدون خرابی');

assert.equal(Snd.soundIdOf('custom'), 'custom'); assert.equal(Snd.soundIdOf('x'), 'ding'); assert.equal(Snd.soundIdOf(undefined), 'ding');
assert.equal(await Snd.playCustom(null), false); assert.equal(await Snd.playCustom({ mime: 'audio/mpeg', data: '!!', duration: 1 }), false);
ok('شناسه‌ی صدا و پخش صدای نامعتبر: false بدون استثنا');
