import { createElement as h } from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import PopupApp from '../src/popup/PopupApp.jsx';
import DashboardApp from '../src/dashboard/DashboardApp.jsx';
import InsightsTab from '../src/dashboard/components/stats/InsightsTab.jsx';
import { initTheme } from '../src/core/themes.js';
export { h, createRoot, act, PopupApp, DashboardApp, InsightsTab, initTheme };
