import test from 'node:test';
import assert from 'node:assert/strict';
import { WEEK_DAYS, weekdayIndex, weekdayName, startOfWeek, endOfWeek, jalaliToDate, jalaliMonthLength } from '../src/core/jalali.js';
import { addDays, startOfDay, dayStats } from '../src/core/dailyStats.js';
import { formatShortDay, formatFullDay } from '../src/core/format.js';
import { periodOf, buildSeries, chartRows, shiftAnchor, METRICS } from '../src/core/compare.js';

const saturday = new Date(2026, 2, 21).getTime();
const session = (ts, i) => ({ id: String(ts), startedAt: ts, focusedMs: (i + 1) * 60000, completed: true });

test('single immutable Saturday–Friday source and shared date labels', () => {
  assert.deepEqual(WEEK_DAYS, ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه']);
  assert.ok(Object.isFrozen(WEEK_DAYS));
  WEEK_DAYS.forEach((name, i) => {
    const ts = addDays(saturday, i);
    assert.equal(weekdayIndex(ts), i);
    assert.equal(weekdayName(ts), name);
    assert.equal(formatShortDay(ts), name);
    assert.ok(formatFullDay(ts).includes(name));
    assert.equal(startOfWeek(ts + 12 * 3600000), saturday);
    assert.equal(endOfWeek(ts), addDays(saturday, 7));
  });
});

test('all weekly anchors produce seven ordered dates across Nowruz, leap years and DST', () => {
  for (const year of [1399, 1400, 1403, 1404, 1405]) {
    for (const month of [1, 7, 12]) {
      for (let day = 1; day <= jalaliMonthLength(year, month); day++) {
        const anchor = jalaliToDate(year, month, day).getTime();
        const p = periodOf('week', anchor, anchor);
        assert.deepEqual(p.buckets.map(b => b.label), WEEK_DAYS);
        p.buckets.forEach((b, i) => {
          assert.equal(weekdayIndex(b.start), i);
          assert.equal(b.start, addDays(startOfWeek(anchor), i));
          assert.equal(b.end, addDays(b.start, 1));
          assert.equal(b.full, formatFullDay(b.start));
          assert.equal(b.future, b.start > anchor);
        });
        assert.equal(p.buckets[6].end, endOfWeek(anchor));
      }
    }
  }
});

test('chart rows, tooltip dates, table and summary retain real date/value associations', () => {
  const sessions = Array.from({ length: 14 }, (_, i) => session(addDays(saturday, i - 7), i));
  const series = buildSeries(sessions.reverse(), 'week', addDays(saturday, 6), addDays(saturday, 6));
  assert.equal(series.cur.all.count, 7);
  assert.equal(series.cur.all.totalMs, 77 * 60000);
  assert.equal(series.prev.all.totalMs, 28 * 60000);
  for (const metric of METRICS) {
    const { rows } = chartRows(series, metric.id);
    assert.deepEqual(rows.map(r => r.label), WEEK_DAYS);
    rows.forEach((r, i) => {
      assert.equal(r.full, formatFullDay(addDays(saturday, i)));
      assert.equal(r.prevFull, formatFullDay(addDays(saturday, i - 7)));
      assert.equal(r.curRaw, metric.id === 'count' ? 1 : i + 8);
      assert.equal(r.prevRaw, metric.id === 'count' ? 1 : i + 1);
    });
  }
});

test('partial and empty weeks retain all seven positions', () => {
  const today = addDays(saturday, 2);
  const series = buildSeries([session(today, 2)], 'week', today, today);
  assert.deepEqual(chartRows(series, 'total').rows.map(r => r.curRaw), [0, 0, 3, null, null, null, null]);
  assert.deepEqual(chartRows(buildSeries([], 'week', today, today), 'count').rows.map(r => r.curRaw), [0, 0, 0, null, null, null, null]);
});

test('Saturday boundaries include Friday but exclude next Saturday', () => {
  const end = endOfWeek(saturday);
  const series = buildSeries([session(saturday - 1, 0), session(saturday, 1), session(end - 1, 2), session(end, 3)], 'week', saturday, end);
  assert.equal(series.cur.all.count, 2);
  assert.equal(series.cur.buckets[0].totalMs, 2 * 60000);
  assert.equal(series.cur.buckets[6].totalMs, 3 * 60000);
});

test('weekly navigation is contiguous and daily navigation remains chronological', () => {
  const anchor = addDays(saturday, 3);
  assert.equal(endOfWeek(shiftAnchor('week', anchor, -1)), startOfWeek(anchor));
  assert.equal(startOfWeek(shiftAnchor('week', anchor, 1)), endOfWeek(anchor));
  assert.equal(weekdayIndex(addDays(saturday, -1)), 6);
  assert.equal(weekdayIndex(addDays(saturday, 1)), 1);
  assert.equal(dayStats([session(anchor, 0)], anchor).count, 1);
  assert.equal(dayStats([session(anchor, 0)], addDays(anchor, -1)).count, 0);
  const rolling = periodOf('day', anchor, anchor);
  assert.equal(rolling.buckets[0].start, addDays(anchor, -6));
  assert.equal(rolling.buckets[6].start, startOfDay(anchor));
});

test('monthly/yearly buckets retain Jalali calendar boundaries and totals', () => {
  const anchor = jalaliToDate(1405, 1, 12).getTime();
  const list = [session(jalaliToDate(1405, 1, 1).getTime(), 0), session(anchor, 1)];
  for (const range of ['month', 'year']) {
    const s = buildSeries(list, range, anchor, anchor);
    assert.equal(s.cur.all.count, 2);
    assert.equal(s.cur.all.totalMs, 180000);
    assert.equal(s.cur.buckets[0].start, jalaliToDate(1405, 1, 1).getTime());
    assert.equal(s.cur.buckets.length, range === 'month' ? 31 : 12);
    s.cur.buckets.slice(1).forEach((b, i) => assert.equal(b.start, s.cur.buckets[i].end));
  }
});

test('rolling 7-day chart rows start at Saturday for every ending weekday and keep real dates', () => {
  for (let end = 0; end < 7; end++) {
    const today = addDays(saturday, end + 14); // روز پایانی بازه، هر روز هفته یک‌بار
    const sessions = Array.from({ length: 14 }, (_, k) => session(addDays(today, k - 13), k));
    for (const metric of METRICS) {
      const series = buildSeries(sessions, 'day', today, today);
      const { rows } = chartRows(series, metric.id);
      assert.deepEqual(rows.map(r => r.label), WEEK_DAYS, `ending weekday ${end}`);
      rows.forEach((r, i) => {
        const bucket = series.cur.buckets.find(b => weekdayIndex(b.start) === i);
        assert.equal(r.full, formatFullDay(bucket.start));
        assert.equal(r.curRaw, metricValueFor(metric.id, sessions, bucket));
        const prev = series.prev.buckets.find(b => weekdayIndex(b.start) === i);
        assert.equal(r.prevFull, formatFullDay(prev.start));
      });
    }
  }
});

function metricValueFor(id, sessions, bucket) {
  const list = sessions.filter(s => s.startedAt >= bucket.start && s.startedAt < bucket.end);
  if (!list.length) return id === 'count' ? 0 : id === 'total' ? 0 : null;
  const ms = list.map(s => s.focusedMs);
  if (id === 'count') return list.length;
  if (id === 'total') return ms.reduce((a, b) => a + b, 0) / 60000;
  if (id === 'avg') return ms.reduce((a, b) => a + b, 0) / list.length / 60000;
  return Math.max(...ms) / 60000;
}

test('weekly rows stay Saturday-first and the week and rolling views never reorder dates across ranges', () => {
  const anchor = addDays(saturday, 9);
  const week = chartRows(buildSeries([], 'week', anchor, anchor), 'total').rows;
  assert.deepEqual(week.map(r => r.label), WEEK_DAYS);
  const month = chartRows(buildSeries([], 'month', anchor, anchor), 'total').rows;
  assert.ok(month.every((r, i) => i === 0 || month[i - 1].i < r.i), 'monthly stays chronological');
});
