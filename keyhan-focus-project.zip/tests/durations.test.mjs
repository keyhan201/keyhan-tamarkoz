// اجرا: node tests/durations.test.mjs  (اعتبارسنجی زمان‌های دلخواه و هم‌خوانی با پشتیبان)
import assert from 'node:assert/strict';
const D = await import('../src/core/durations.js');
const B = await import('../src/core/backup.js');
const { DEFAULT_SETTINGS } = await import('../src/core/constants.js');
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);

assert.equal(D.parseMinutes('۴۰'), 40); assert.equal(D.parseMinutes(' 40 '), 40);
for (const bad of ['', '0', '361', '-5', '25.5', '1e1', 'abc', '۲۵ دقیقه', null, undefined, '٠٠٠٠٠']) assert.equal(D.parseMinutes(bad), null, String(bad));
assert.equal(D.parseMinutes('360'), 360); assert.equal(D.parseMinutes('1'), 1);
ok('پارس دقیقه: ارقام فارسی، مرزها و ورودی نامعتبر');

let r = D.addCustomMinute([], '۴۰');
assert.deepEqual([r.ok, r.list, r.minutes], [true, [40], 40]);
r = D.addCustomMinute([40], '10');
assert.deepEqual(r.list, [10, 40]);
ok('افزودن: مقدار معتبر ذخیره و مرتب می‌شود');

r = D.addCustomMinute([40], '۴۰'); assert.equal(r.ok, false); assert.equal(r.duplicate, 40);
r = D.addCustomMinute([], '25'); assert.equal(r.ok, false); assert.equal(r.duplicate, 25);
ok('تکراری (حتی با زمان پیش‌فرض) ثبت نمی‌شود');

r = D.addCustomMinute([], '500'); assert.equal(r.ok, false); assert.match(r.error, /۳۶۰/);
ok('خارج از محدوده‌ی تایمر: خطای فارسی');

let full = [];
for (const v of [1, 2, 3, 4, 6, 7]) full = D.addCustomMinute(full, String(v)).list;
assert.equal(full.length, D.MAX_CUSTOM_TIMES);
r = D.addCustomMinute(full, '8'); assert.equal(r.ok, false);
ok('سقف تعداد زمان‌های ذخیره‌شده');

assert.deepEqual(D.removeCustomMinute([10, 40], 10), [40]);
assert.deepEqual(D.removeCustomMinute([10, 40], 99), [10, 40]);
assert.deepEqual(D.normalizeCustomMinutes([5, 40, 40, '12', 0, 400, 1.5, NaN, 20]), [20, 40]);
assert.deepEqual(D.normalizeCustomMinutes('x'), []);
ok('حذف و پاک‌سازی داده‌ی خراب');

// مهاجرت: تنظیمات قدیمی بدون customMinutes با پیش‌فرض ادغام می‌شود و چیزی از دست نمی‌رود
const old = { defaultMinutes: 45, theme: 'navy', soundId: 'chime' };
const merged = { ...DEFAULT_SETTINGS, ...old };
assert.deepEqual(merged.customMinutes, []); assert.equal(merged.defaultMinutes, 45); assert.equal(merged.theme, 'navy');
ok('مهاجرت: تنظیمات نسخه‌ی قبل بدون تغییر می‌مانند');

// پشتیبان: فهرست خراب پاک‌سازی می‌شود، فهرست سالم می‌ماند
const res = B.parseBackup(JSON.stringify({ settings: { customMinutes: [40, 40, 25, 999, 'x', 15, 20] } }));
assert.equal(res.ok, true); assert.deepEqual(res.data.settings.customMinutes, [20, 40]);
ok('بازیابی پشتیبان: customMinutes اعتبارسنجی می‌شود');
