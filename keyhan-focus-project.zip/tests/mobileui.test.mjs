// اجرا: node tests/mobileui.test.mjs — رابط موبایل (React) در jsdom: ناوبری، تایمر، استراحت، باغ، تنظیمات، نبود «کارهای روزانه»
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { JSDOM } from 'jsdom';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', { url: 'https://localhost/index.html', pretendToBeVisual: true });
const w = dom.window;
for (const k of ['window', 'document', 'localStorage', 'CustomEvent', 'HTMLElement', 'Event', 'KeyboardEvent', 'MouseEvent', 'MutationObserver', 'getComputedStyle', 'Node']) {
  Object.defineProperty(globalThis, k, { configurable: true, writable: true, value: k === 'window' ? w : w[k] });
}
w.matchMedia = w.matchMedia || (() => ({ matches: false, addListener() {}, removeListener() {} }));
w.Element.prototype.scrollIntoView = () => {};
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
w.ResizeObserver = globalThis.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };

const out = join(mkdtempSync(join(tmpdir(), 'kt-mui-')), 'bundle.mjs');
await build({ entryPoints: ['tests/mobile-entry.jsx'], bundle: true, format: 'esm', platform: 'node', outfile: out, jsx: 'automatic', loader: { '.css': 'empty', '.woff2': 'empty' }, logLevel: 'error', define: { 'process.env.NODE_ENV': '"development"' } });
const { h, createRoot, act, MobileApp } = await import(pathToFileURL(out).href);

let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const $ = (sel, root = w.document) => root.querySelector(sel);
const $$ = (sel, root = w.document) => [...root.querySelectorAll(sel)];
const btn = (text) => $$('button').find((e) => e.textContent.trim().includes(text));
const flush = () => act(async () => { await new Promise((r) => setTimeout(r, 40)); });
const read = (k) => JSON.parse(w.localStorage.getItem('kt:' + k) || 'null');
const seed = (k, v) => w.localStorage.setItem('kt:' + k, JSON.stringify(v));
const click = (el) => act(async () => { el.dispatchEvent(new w.MouseEvent('click', { bubbles: true })); });
const type = (el, v) => act(async () => { Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype, 'value').set.call(el, v); el.dispatchEvent(new w.Event('input', { bubbles: true })); });
const blur = (el) => act(async () => { el.dispatchEvent(new w.Event('blur', { bubbles: true })); el.dispatchEvent(new w.Event('focusout', { bubbles: true })); });
let root;
const mount = async () => { w.document.body.innerHTML = '<div id="root"></div>'; root = createRoot($('#root')); await act(async () => root.render(h(MobileApp))); await flush(); };
const unmount = async () => { await act(async () => root.unmount()); w.localStorage.clear(); };
const tab = (label) => click($$('.m-nav button').find((b) => b.textContent.trim() === label));

await mount();
assert.deepEqual($$('.m-nav button').map((b) => b.textContent.trim()), ['تمرکز', 'آمار', 'تنظیمات']);
assert.equal($$('.m-nav svg, .m-nav img, .m-nav i').length, 0, 'منوی ناوبری نباید آیکون داشته باشد');
ok('ناوبری فقط متن است (بدون آیکون) و فقط سه بخش دارد (باغ حذف شد)');

for (const t of ['تمرکز', 'آمار', 'تنظیمات']) {
  await tab(t); await flush();
  assert.ok(!w.document.body.textContent.includes('کارهای روزانه'), `«کارهای روزانه» در بخش ${t}`);
  assert.ok(!w.document.body.textContent.includes('باغ'), `«باغ» در بخش ${t}`);
  assert.equal($$('a[href*="tasks"]').length, 0);
}
ok('«کارهای روزانه» در هیچ بخشی نیست');

await tab('تمرکز'); await flush();
assert.ok($('.m-quote').textContent.trim().length > 6); assert.ok($('.orbit'));
await click(btn('شروع تمرکز')); await flush();
let t = read('timer'); assert.equal(t.status, 'running'); assert.equal(t.kind, 'focus');
assert.ok(btn('توقف موقت') && btn('انصراف از جلسه'), 'کنترل‌های ۱۰ ثانیه‌ی اول');
await click(btn('انصراف از جلسه')); await flush();
assert.equal(read('timer').status, 'idle'); assert.equal((read('sessions') || []).length, 0);
ok('شروع و انصراف در ۱۰ ثانیه‌ی اول، بدون ثبت جلسه');

// پایان تمرکز → پیشنهاد استراحت و جلسه‌ی جدید
const now = Date.now();
seed('settings', { breakMinutes: 7 });
seed('timer', { status: 'idle', kind: 'focus', durationSeconds: 1500, remainingSeconds: 1500, startedAt: null, endsAt: null, gracePeriodEndsAt: null, graceRemainingMs: null, sessionId: null, lastResult: { minutes: 25, at: now - 5000, sessionId: 's1', sound: null, notice: false, kind: 'focus' } });
await unmount(); seed('settings', { breakMinutes: 7 });
seed('timer', { status: 'idle', kind: 'focus', durationSeconds: 1500, remainingSeconds: 1500, startedAt: null, endsAt: null, gracePeriodEndsAt: null, graceRemainingMs: null, sessionId: null, lastResult: { minutes: 25, at: now - 5000, sessionId: 's1', sound: null, notice: false, kind: 'focus' } });
await mount();
assert.ok(btn('استراحت ۷ دقیقه‌ای'), 'دکمه‌ی استراحت با مدت تنظیم‌شده'); assert.ok(btn('شروع جلسه‌ی جدید')); assert.ok(btn('تمدید ۵ دقیقه‌ای'));
assert.ok(w.document.body.textContent.includes('۲۵ دقیقه ثبت شد'));
await click(btn('استراحت ۷ دقیقه‌ای')); await flush();
t = read('timer'); assert.equal(t.kind, 'break'); assert.equal(t.durationSeconds, 420);
assert.ok(w.document.body.textContent.includes('در حال استراحت')); assert.ok(btn('رد کردن استراحت') && btn('شروع جلسه‌ی جدید'));
assert.ok(!btn('توقف موقت'), 'استراحت مکث ندارد');
ok('بعد از پایان تمرکز: استراحت با مدت تنظیمات شروع می‌شود و وضعیت جدا دارد');
await click(btn('رد کردن استراحت')); await flush();
assert.equal(read('timer').status, 'idle'); ok('رد کردن استراحت');
await unmount();

// داده‌ی قدیمی (جلسه‌هایی که قبلاً به باغ رشد می‌دادند) سالم می‌ماند و آمار آن‌ها را نشان می‌دهد
const S = (i, m) => ({ id: 's' + i, startedAt: Date.now() - (10 - i) * 3600000, endedAt: Date.now() - (10 - i) * 3600000 + m * 60000, plannedMs: m * 60000, focusedMs: m * 60000, completed: true, source: 'timer' });
seed('sessions', [S(1, 60), S(2, 60), S(3, 30)]);
await mount(); await tab('آمار'); await flush();
assert.ok($('.tabs')); assert.equal(read('sessions').length, 3, 'داده‌ی قدیمی دست‌نخورده');
assert.ok(!w.document.body.textContent.includes('گل'), 'اثری از باغ و گل نباشد');
ok('آمار با داده‌ی قدیمی کار می‌کند و داده‌ها پاک نشده‌اند');
await unmount();

// ---- تنظیمات تو‌در‌تو ----
const link = (title) => $$('.m-link').find((b) => b.textContent.includes(title));
const open = async (title) => { assert.ok(link(title), `ردیف «${title}» پیدا نشد`); await click(link(title)); await flush(); };
const back = async () => { await click($$('button').find((b) => b.textContent.trim().startsWith('بازگشت'))); await flush(); };
const h1 = () => $('h1').textContent.trim();

await mount(); await tab('تنظیمات'); await flush();
assert.equal(h1(), 'تنظیمات');
assert.deepEqual($$('.m-link-title').map((e) => e.textContent.trim()), ['ظاهر و تم', 'جلسه و زمان‌ها', 'صدا و اعلان‌ها', 'فایل‌ها و پشتیبان‌گیری', 'دسترسی‌ها و محدودسازی برنامه‌ها']);
assert.equal($$('input, [role=switch], .btn').length, 0, 'صفحه‌ی اصلی تنظیمات فقط عنوان و وضعیت دارد');
assert.ok(link('جلسه و زمان‌ها').textContent.includes('استراحت ۵') && link('صدا و اعلان‌ها').textContent.includes('اعلان'));
assert.equal($$('.m-link svg, .m-link img').length, 0, 'آیکون در منو نیست');
ok('صفحه‌ی اصلی تنظیمات: پنج بخش با وضعیت کوتاه، بدون دکمه/مجوز/آیکون');

await open('جلسه و زمان‌ها');
const inp = $('input[aria-label="مدت استراحت به دقیقه"]');
assert.ok(inp); assert.equal(inp.value, '۵');
await type(inp, '۱۲'); await blur(inp); await flush(); assert.equal(read('settings').breakMinutes, 12);
await type(inp, '۹۹'); await blur(inp); await flush(); assert.equal(read('settings').breakMinutes, 12); assert.equal(inp.value, '۱۲');
const ext = $('input[aria-label="مدت تمدید جلسه به دقیقه"]');
await type(ext, '۱۵'); await blur(ext); await flush(); assert.equal(read('settings').extendMinutes, 15);
await type(ext, '۰'); await blur(ext); await flush(); assert.equal(read('settings').extendMinutes, 15);
ok('جلسه و زمان‌ها: استراحت و تمدید ذخیره می‌شوند و مقدار نامعتبر رد می‌شود');
await back(); assert.equal(h1(), 'تنظیمات'); assert.ok(link('جلسه و زمان‌ها').textContent.includes('استراحت ۱۲') && link('جلسه و زمان‌ها').textContent.includes('تمدید ۱۵'));
ok('بازگشت به تنظیمات اصلی و به‌روزشدن وضعیت کوتاه');

await open('ظاهر و تم');
assert.deepEqual($$('.m-link-title').map((e) => e.textContent.trim()), ['تم‌های آماده', 'ساخت و مدیریت تم شخصی']);
await open('تم‌های آماده'); assert.equal(h1(), 'تم‌های آماده');
assert.ok($('.dd, [aria-haspopup], button[aria-expanded]') || $$('.row').length >= 1); assert.ok(!btn('ساخت تم'), 'ساخت تم در صفحه‌ی خودش است');
await back(); assert.equal(h1(), 'ظاهر و تم');
await open('ساخت و مدیریت تم شخصی'); assert.ok(btn('ساخت تم'), 'دکمه‌ی ساخت تم');
await click(btn('ساخت تم')); await flush(); assert.ok($('[aria-label="ساخت تم شخصی"]'));
await back(); await back(); assert.equal(h1(), 'تنظیمات');
ok('ظاهر و تم: «تم‌های آماده» و «ساخت/مدیریت تم شخصی» در صفحه‌های داخلی جدا');

await open('صدا و اعلان‌ها'); assert.equal($$('.m-link-title').length, 2);
await open('صدای هشدار'); assert.ok($$('[role=switch]').length >= 1); await back();
assert.equal(h1(), 'صدا و اعلان‌ها');
await open('اعلان‌ها و پنجره‌ی پایان جلسه');
assert.ok($('button[aria-label="اعلان پایان جلسه"]')); const ov = $('button[aria-label="پنجره‌ی پایان جلسه روی برنامه‌ها"]');
assert.ok(ov); await click(ov); await flush(); assert.notEqual(read('settings').endOverlay, true, 'بدون مجوز، پنجره‌ی روی برنامه‌ها روشن نمی‌شود');
ok('صدا و اعلان‌ها: زیرصفحه‌ها؛ پنجره‌ی روی برنامه‌ها بدون مجوز فعال نمی‌شود');
await back(); await back();

await open('فایل‌ها و پشتیبان‌گیری');
assert.ok(btn('دریافت فایل') && btn('انتخاب فایل') && btn('حذف جلسه‌ها')); assert.ok(!w.document.body.textContent.includes('کارهای روزانه'));
await back(); ok('فایل‌ها و پشتیبان‌گیری: ورودی/خروجی/بازیابی در بخش جدا');

await open('دسترسی‌ها و محدودسازی برنامه‌ها');
assert.ok(btn('فعال‌سازی دسترسی‌های لازم'), 'یک دکمه‌ی اصلی'); assert.ok(link('وضعیت دسترسی‌ها') && link('محدودسازی برنامه‌ها'));
await click(btn('فعال‌سازی دسترسی‌های لازم')); await flush();
assert.ok(w.document.body.textContent.includes('مرحله‌ی ۱ از ۲: آمار استفاده از برنامه‌ها'));
await click(btn('ادامه')); await flush(); assert.ok(btn('تلاش دوباره'), 'بعد از رفتن به تنظیمات، امکان تلاش دوباره');
await click(btn('رد کردن')); await flush(); assert.ok(w.document.body.textContent.includes('مرحله‌ی ۲ از ۲: نمایش روی برنامه‌های دیگر'));
await click(btn('رد کردن')); await flush(); assert.ok(w.document.body.textContent.includes('این موارد فعال نشد'));
await click(btn('بستن')); await flush();
ok('فعال‌سازی دسترسی‌ها: یک نقطه‌ی شروع، مرحله‌به‌مرحله با راهنما، امکان رد کردن و تلاش دوباره');

await open('وضعیت دسترسی‌ها'); assert.equal($$('.row').length, 5); assert.ok(btn('فعال‌سازی'));
await back(); await open('محدودسازی برنامه‌ها');
assert.ok(w.document.body.textContent.includes('۱۰۰٪ نیست') && $('.m-search'));
const sw = $('button[aria-label="حالت محدودسازی"]'); assert.equal(sw.getAttribute('aria-checked'), 'false');
await click(sw); await flush(); assert.notEqual(read('settings').blockMode, true); assert.ok($$('[role=alert]').some((e) => e.textContent.includes('رضایت')));
await click($('.m-consent input')); await click(sw); await flush();
assert.notEqual(read('settings').blockMode, true, 'بدون مجوزها روشن نمی‌شود'); assert.ok($$('[role=alert]').some((e) => e.textContent.includes('مجوز')));
ok('وضعیت دسترسی‌ها و محدودسازی: بدون رضایت و مجوز حالت محدودسازی روشن نمی‌شود');
assert.equal(h1(), 'محدودسازی برنامه‌ها'); await back(); assert.equal(h1(), 'دسترسی‌ها و محدودسازی برنامه‌ها'); await back(); assert.equal(h1(), 'تنظیمات');
ok('بازگشت مرحله‌به‌مرحله تا تنظیمات اصلی');
await tab('تمرکز'); await tab('تنظیمات'); await flush(); assert.equal(h1(), 'تنظیمات'); ok('کلیک روی تب تنظیمات، به صفحه‌ی اصلی تنظیمات برمی‌گردد');
await unmount();

// خروج از حالت محدودسازی وسط تمرکز
seed('settings', { blockMode: true });
seed('timer', { status: 'running', kind: 'focus', durationSeconds: 1500, remainingSeconds: 1500, startedAt: Date.now() - 60000, endsAt: Date.now() + 1440000, gracePeriodEndsAt: Date.now() - 50000, graceRemainingMs: null, sessionId: 'z1', lastResult: null });
await mount();
assert.ok(btn('خاموش کردن حالت محدودسازی'), 'خروج وسط تمرکز همیشه در دسترس است');
await click(btn('خاموش کردن حالت محدودسازی')); await flush();
assert.equal(read('settings').blockMode, false); assert.ok(!btn('خاموش کردن حالت محدودسازی'));
ok('وسط تمرکز (بعد از ۱۰ ثانیه) خاموش‌کردن حالت محدودسازی ممکن است');
await unmount();
console.log('Mobile UI tests complete');
process.exit(0);
