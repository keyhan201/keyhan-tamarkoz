// اجرا: node tests/backup.test.mjs  (اعتبارسنجی و بازیابی فایل پشتیبان با storage شبیه‌سازی‌شده)
import assert from 'node:assert/strict';

const store = {};
globalThis.chrome = { storage: { local: { get: async (k) => ({ [k]: store[k] === undefined ? undefined : JSON.parse(JSON.stringify(store[k])) }), set: async (o) => { for (const k in o) store[k] = JSON.parse(JSON.stringify(o[k])); } } } };
let chain = Promise.resolve();
Object.defineProperty(globalThis, 'navigator', { configurable: true, value: { locks: { request: (_n, fn) => { const r = chain.then(fn); chain = r.catch(() => {}); return r; } } } });

const B = await import('../src/core/backup.js');
const T = await import('../src/core/timerService.js');
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const t0 = 1_700_000_000_000;
const S = (id, extra = {}) => ({ id, startedAt: t0, endedAt: t0 + 1500000, plannedMs: 1500000, focusedMs: 1500000, completed: true, source: 'timer', ...extra });

// بازیابی دقیقاً همان چیزی را که export می‌سازد (همان ساختار SettingsView.exportData)
const exported = {
  exportedAt: new Date().toISOString(),
  sessions: [S('a'), S('manual-1', { source: 'manual', createdAt: t0 }), S(42), S('old', { completed: false })],
  tasks: [{ id: 't1', text: 'نوشتن گزارش', done: false, createdAt: t0 }, { id: 't2', text: 'خرید', done: true, createdAt: t0 }],
  settings: { defaultMinutes: 45, notifications: false, badge: true, theme: 'violet', soundEnabled: false, soundId: 'chime' },
};
let r = B.parseBackup(JSON.stringify(exported, null, 2));
assert.equal(r.ok, true); assert.equal(r.summary.sessions, 4); assert.equal(r.summary.tasks, 2); assert.equal(r.summary.settings, true); assert.equal(r.summary.skipped, 0);
assert.deepEqual(r.data.sessions, exported.sessions, 'ساختار جلسه‌ها (شامل manual و partial قدیمی) دست‌نخورده می‌ماند');
assert.deepEqual(r.data.tasks, exported.tasks); assert.equal(r.data.settings.theme, 'violet'); assert.equal(r.data.settings.defaultMinutes, 45);
ok('فایل خروجی خود افزونه کامل و بدون تغییر ساختار پذیرفته می‌شود');

// نادرست‌ها
for (const [text, re] of [['', /خالی/], ['not json', /JSON/], ['[1,2]', /پشتیبان/], ['{"foo":1}', /پشتیبان/], ['{"sessions":5}', /جلسه/], ['{"tasks":{}}', /کار/], ['{"settings":[]}', /تنظیمات/], ['{"settings":{"foo":1}}', /داده‌ای/]]) {
  const x = B.parseBackup(text);
  assert.equal(x.ok, false, text); assert.match(x.error, re, text);
}
ok('فایل خالی، غیر JSON، ساختار نادرست یا بی‌ربط رد می‌شود');
assert.equal(B.parseBackup('{"sessions":[]}').ok, true, 'پشتیبان خالی (بدون جلسه) معتبر است');
assert.equal(B.parseBackup(' '.repeat(20)).ok, false);

// موارد خراب نادیده گرفته می‌شوند و تکراری‌ها حذف
r = B.parseBackup(JSON.stringify({
  sessions: [S('a'), S('a'), { id: 'x', startedAt: 'bad', focusedMs: 5 }, null, S('z', { focusedMs: -1 }), S('w', { endedAt: NaN })],
  tasks: [{ id: 1, text: ' ', done: false }, { id: 2, text: 'خوب', done: false }, { id: 2, text: 'تکرار', done: false }, { text: 'بدون id', done: false }],
  settings: { defaultMinutes: 9999, theme: 'nope', soundId: 'nope', notifications: 'yes', badge: false, extra: 1 },
}));
assert.equal(r.ok, true); assert.deepEqual(r.data.sessions.map((s) => s.id), ['a', 'w']); // endedAt:NaN در JSON به null تبدیل می‌شود (شکل قدیمی بدون پایان) assert.deepEqual(r.data.tasks.map((t) => t.id), [2]);
assert.equal(r.summary.skipped, 4 + 3);
assert.deepEqual(r.data.settings, { theme: 'main', soundId: 'ding', badge: false });
ok('جلسه/کار نامعتبر یا تکراری و تنظیم نامعتبر نادیده گرفته می‌شود');

// نوشتن در storage؛ تایمر دست‌نخورده
store.sessions = [S('keep-me')]; store.tasks = [{ id: 'old', text: 'قدیمی', done: false }];
store.settings = { defaultMinutes: 25, theme: 'main', futureKey: 'x' };
await T.startTimer(25, t0);
const timerBefore = JSON.stringify(store.timer);
const ex = B.parseBackup(JSON.stringify(exported));
await B.restoreBackup(ex.data);
assert.deepEqual(store.sessions, exported.sessions); assert.deepEqual(store.tasks, exported.tasks);
assert.equal(store.settings.theme, 'violet'); assert.equal(store.settings.defaultMinutes, 45); assert.equal(store.settings.futureKey, 'x');
assert.equal(JSON.stringify(store.timer), timerBefore, 'وضعیت تایمر تغییر نکرد');
ok('بازیابی: جلسه‌ها و کارها جایگزین، تنظیمات ادغام، تایمر دست‌نخورده');

// بخش غایب فایل، داده‌ی فعلی را پاک نمی‌کند
store.tasks = [{ id: 'mine', text: 'مال من', done: false }];
await B.restoreBackup(B.parseBackup(JSON.stringify({ sessions: [S('only')] })).data);
assert.deepEqual(store.sessions.map((s) => s.id), ['only']); assert.deepEqual(store.tasks.map((t) => t.id), ['mine']);
ok('کلیدی که در فایل نیست دست نمی‌خورد');

// رفت‌وبرگشت کامل
const before = { sessions: JSON.stringify(store.sessions), tasks: JSON.stringify(store.tasks) };
const again = B.parseBackup(JSON.stringify({ sessions: store.sessions, tasks: store.tasks, settings: store.settings }));
await B.restoreBackup(again.data);
assert.equal(JSON.stringify(store.sessions), before.sessions); assert.equal(JSON.stringify(store.tasks), before.tasks);
ok('خروجی گرفتن و بازیابی دوباره، داده را یکسان نگه می‌دارد');

console.log(`\nهمه‌ی ${n} بررسی موفق بود.`);
