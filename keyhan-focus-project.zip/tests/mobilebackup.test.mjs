// اجرا: node tests/mobilebackup.test.mjs — مهاجرت از پشتیبان افزونه (بدون «کارهای روزانه») و تنظیمات تازه
import assert from "node:assert/strict";
const store = {};
globalThis.chrome = { storage: { local: { get: async (k) => ({ [k]: store[k] === undefined ? undefined : JSON.parse(JSON.stringify(store[k])) }), set: async (o) => { for (const k in o) store[k] = JSON.parse(JSON.stringify(o[k])); } } } };
let chain = Promise.resolve();
Object.defineProperty(globalThis, "navigator", { configurable: true, value: { locks: { request: (_n, fn) => { const r = chain.then(fn); chain = r.catch(() => {}); return r; } } } });
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const t0 = 1_700_000_000_000;
const S = (id, min, extra = {}) => ({ id, startedAt: t0 + Number(String(id).replace(/\D/g, "") || 0) * 1e7, endedAt: t0 + Number(String(id).replace(/\D/g, "") || 0) * 1e7 + min * 60000, plannedMs: min * 60000, focusedMs: min * 60000, completed: true, source: "timer", ...extra });
const B = await import('../src/core/backup.js');
const ext = { exportedAt: 'x', sessions: [S('1', 25), S('2', 30, { source: 'manual' })], tasks: [{ id: 't', text: 'کار', done: false }, 'خراب'], settings: { defaultMinutes: 30, tasksEnabled: false, theme: 'navy', breakMinutes: 9, limitedApps: ['com.a.b', 'bad', 'com.a.b'], limitEnabled: true } };

let r = B.parseBackup(JSON.stringify(ext), { tasks: false });
assert.equal(r.ok, true); assert.equal(r.summary.sessions, 2); assert.equal(r.summary.tasks, 0); assert.equal(r.summary.skipped, 0); assert.equal('tasks' in r.data, false);
assert.deepEqual(r.data.sessions, ext.sessions);
assert.equal(r.data.settings.breakMinutes, 9); assert.deepEqual(r.data.settings.limitedApps, ['com.a.b']); assert.equal(r.data.settings.limitEnabled, true);
ok('پشتیبان افزونه: جلسه‌ها و تنظیمات وارد می‌شوند، کارها بدون خطا نادیده گرفته می‌شوند');

r = B.parseBackup(JSON.stringify({ tasks: [{ id: 't', text: 'x', done: false }] }), { tasks: false });
assert.equal(r.ok, false); ok('فایلی که فقط کار دارد، «داده‌ای برای بازیابی نیست»');

r = B.parseBackup(JSON.stringify({ tasks: 'خراب', sessions: [S('1', 10)] }), { tasks: false });
assert.equal(r.ok, true); ok('بخش tasks خراب مانعی ایجاد نمی‌کند');

r = B.parseBackup(JSON.stringify({ settings: { breakMinutes: 500, limitedApps: 'x', soundId: 'custom' } }), { tasks: false });
assert.equal(r.data.settings.breakMinutes, undefined); assert.deepEqual(r.data.settings.limitedApps, []); assert.equal(r.data.settings.soundId, 'ding');
ok('مدت استراحت و برنامه‌های نامعتبر اعتبارسنجی می‌شوند');

// رفتار افزونه تغییر نکرده
r = B.parseBackup(JSON.stringify(ext)); assert.equal(r.summary.tasks, 1); ok('پیش‌فرض (افزونه): کارها مثل قبل پردازش می‌شوند');

// بازیابی: کارها در ذخیره‌سازی نوشته نمی‌شوند
r = B.parseBackup(JSON.stringify(ext), { tasks: false }); await B.restoreBackup(r.data);
assert.equal(store.tasks, undefined); assert.equal(store.sessions.length, 2); assert.equal(store.settings.defaultMinutes, 30);
ok('بازیابی: کارها ذخیره نمی‌شوند');

r = B.parseBackup(JSON.stringify({ settings: { blockMode: true, endOverlay: true, extendMinutes: 12, defaultMinutes: 30 } }), { tasks: false });
assert.equal(r.data.settings.blockMode, undefined); assert.equal(r.data.settings.endOverlay, undefined); assert.equal(r.data.settings.extendMinutes, 12);
assert.equal(B.parseBackup(JSON.stringify({ settings: { extendMinutes: 99, defaultMinutes: 30 } })).data.settings.extendMinutes, undefined);
ok('حالت محدودسازی و پنجره‌ی روی برنامه‌ها هرگز از فایل پشتیبان فعال نمی‌شوند؛ مدت تمدید اعتبارسنجی می‌شود');
