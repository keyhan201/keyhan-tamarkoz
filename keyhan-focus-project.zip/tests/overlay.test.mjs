// اجرا: node tests/overlay.test.mjs  — تابع اعلان را مثل chrome.scripting در یک صفحه‌ی مجزا (jsdom) اجرا می‌کند.
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { showEndOverlay } from '../src/background/overlay.js';
import { OVERLAY_COLORS } from '../src/core/themes.js';

let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);

// مثل executeScript: فقط متن تابع به صفحه می‌رود، نه هیچ متغیر بیرونی
const run = (dom, opts) => dom.window.eval(`(${showEndOverlay.toString()})(${JSON.stringify(opts)})`);
const opts = (sessionId) => ({ sessionId, title: 'دیگه کار بسه', body: 'زمان تمرکزت تموم شد', button: 'باشه', colors: OVERLAY_COLORS.main });

// attachShadow بسته است؛ برای تست آن را باز می‌کنیم تا درون آن را ببینیم
const open = () => {
  const dom = new JSDOM('<!doctype html><body><p>صفحه‌ی سایت</p></body>', { runScripts: 'outside-only' });
  const orig = dom.window.Element.prototype.attachShadow;
  dom.window.Element.prototype.attachShadow = function (o) { return orig.call(this, { ...o, mode: 'open' }); };
  return dom;
};
const hostOf = (dom) => dom.window.document.getElementById('kt-end-overlay-host');

let dom = open();
assert.equal(run(dom, opts('s1')), 'shown');
const card = hostOf(dom).shadowRoot.querySelector('.card');
assert.equal(card.querySelector('h2').textContent, 'دیگه کار بسه');
assert.equal(card.querySelector('p').textContent, 'زمان تمرکزت تموم شد');
assert.equal(card.querySelector('button').textContent, 'باشه');
assert.match(hostOf(dom).style.cssText, /position: fixed/);
ok('متن دقیق «دیگه کار بسه» + متن تکمیلی + دکمه‌ی «باشه»، روی viewport ثابت و داخل Shadow DOM');

assert.equal(run(dom, opts('s1')), 'duplicate');
assert.equal(dom.window.document.querySelectorAll('#kt-end-overlay-host').length, 1);
ok('اجرای دوباره برای همان جلسه اعلان دوم نمی‌سازد');

card.querySelector('button').click();
assert.equal(hostOf(dom), null);
ok('دکمه‌ی «باشه» اعلان را می‌بندد');

run(dom, opts('s2'));
dom.window.document.dispatchEvent(new dom.window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
assert.equal(hostOf(dom), null);
ok('کلید Escape اعلان را می‌بندد');

run(dom, opts('s3')); dom.window.document.dispatchEvent(new dom.window.KeyboardEvent('keydown', { key: 'a' }));
assert.ok(hostOf(dom)); run(dom, opts('s4'));
assert.equal(dom.window.document.querySelectorAll('#kt-end-overlay-host').length, 1); assert.equal(hostOf(dom).dataset.session, 's4');
ok('کلید دیگر اثری ندارد؛ جلسه‌ی تازه جایگزین اعلان قبلی می‌شود');
