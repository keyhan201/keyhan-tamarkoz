// اجرا: node tests/timer.test.mjs  (منطق هسته با storage و قفل شبیه‌سازی‌شده)
import assert from 'node:assert/strict';

const store = {};
globalThis.chrome = { storage: { local: { get: async (k) => ({ [k]: store[k] === undefined ? undefined : JSON.parse(JSON.stringify(store[k])) }), set: async (o) => { for (const k in o) store[k] = JSON.parse(JSON.stringify(o[k])); } } } };
let chain = Promise.resolve(); // قفل ساده مثل Web Locks
Object.defineProperty(globalThis, 'navigator', { configurable: true, value: { locks: { request: (_n, fn) => { const r = chain.then(fn); chain = r.catch(() => {}); return r; } } } });

const T = await import('../src/core/timerService.js');
const F = await import('../src/core/format.js');
const sessions = () => store.sessions || [];
const t0 = 1_700_000_000_000;
let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);

// ۱: حالت آماده
let t = await T.getTimer();
assert.equal(t.status, 'idle'); assert.equal(T.canInterrupt(t, t0), false); ok('آماده: هیچ کنترل توقف/انصرافی نیست');

// ۳–۴: شروع و دسترسی در چند ثانیه‌ی اول
await T.startTimer(20, t0); t = await T.getTimer();
assert.equal(t.status, 'running'); assert.equal(t.durationSeconds, 1200); assert.equal(t.gracePeriodEndsAt, t0 + 10000);
assert.equal(T.canInterrupt(t, t0 + 3000), true); ok('شروع؛ توقف/انصراف در ۳ ثانیه‌ی اول ممکن است');

// ۵: توقف در ثانیه‌ی پنجم
assert.equal(await T.pauseTimer(t0 + 5000), true); t = await T.getTimer();
assert.equal(t.status, 'paused'); assert.equal(t.remainingSeconds, 1195);
assert.equal(F.clock(T.remainingMsOf(t)), '۱۹:۵۵'); assert.ok(!JSON.stringify(store.timer).includes('null,"remainingSeconds"'));
ok('توقف در ثانیه‌ی ۵: وضعیت و زمان باقی‌مانده معتبر ذخیره شد');

// ۱۶: توقف طولانی هم NaN نمی‌دهد و پنجره منجمد می‌ماند
assert.equal(T.canInterrupt(t, t0 + 3_600_000), true); assert.ok(!F.clock(T.remainingMsOf(t)).includes('NaN')); ok('حالت توقف‌یافته: بدون NaN، پنجره منجمد');

// ۶: انصراف از توقف → idle، بدون جلسه
assert.equal(await T.cancelTimer(t0 + 3_600_000), true); t = await T.getTimer();
assert.equal(t.status, 'idle'); assert.equal(t.sessionId, null); assert.equal(sessions().length, 0); ok('انصراف: idle، sessionId پاک، جلسه‌ای ثبت نشد');

// ۷–۸: شروع دوباره و انصراف در ثانیه‌ی هشتم
await T.startTimer(20, t0 + 10_000_000);
assert.equal(await T.cancelTimer(t0 + 10_000_000 + 8000), true); assert.equal(sessions().length, 0); ok('انصراف در ثانیه‌ی ۸ بدون ثبت جلسه');

// ۹–۱۲: دقیقاً ۱۰ ثانیه
const s = t0 + 20_000_000; await T.startTimer(20, s); t = await T.getTimer();
assert.equal(T.canInterrupt(t, s + 9999), true); assert.equal(T.canInterrupt(t, s + 10000), false);
assert.equal(await T.pauseTimer(s + 10000), false); assert.equal(await T.cancelTimer(s + 10001), false);
assert.equal((await T.getTimer()).status, 'running'); ok('در ۱۰.۰۰۰ ثانیه توقف و انصراف ممکن نیست (رویدادها بی‌اثر)');
assert.equal(T.canInterrupt(await T.getTimer(), s + 3_600_000), false); ok('بازشدن دوباره‌ی پاپ‌آپ بعد از ۱۰ ثانیه: کنترل‌ها برنمی‌گردند');

// ۱۳–۱۵: خواب سیستم؛ دو مدعی هم‌زمان پایان جلسه
const after = s + 1200 * 1000 + 5 * 60000;
const [a, b] = await Promise.all([T.completeTimer(after), T.completeTimer(after)]);
assert.equal([a, b].filter(Boolean).length, 1); assert.equal(sessions().length, 1);
t = await T.getTimer(); assert.equal(t.status, 'idle'); assert.equal(t.lastResult.minutes, 20);
assert.equal(await T.completeTimer(after + 1), null); assert.equal(sessions().length, 1); ok('پایان بعد از خواب سیستم؛ فقط یک جلسه ثبت شد');

// ۱۷: داده‌ی خراب / قدیمی
for (const bad of [
  { status: 'paused', durationMs: 1_200_000, remainingMs: null, startedAt: t0 },
  { status: 'paused', durationSeconds: 1200, remainingSeconds: NaN, startedAt: t0 },
  { status: 'paused', durationSeconds: 1200, remainingSeconds: 'x', startedAt: t0 },
  { status: 'running', durationSeconds: 1200, startedAt: t0, endsAt: null },
  { status: 'running' }, null, undefined, 'garbage', {},
]) {
  const x = T.normalizeTimer(bad); const txt = F.clock(T.remainingMsOf(x, t0 + 1000));
  assert.ok(!/NaN|undefined|null/.test(txt + JSON.stringify(x).replace(/"\w+":null/g, '')));
}
assert.equal(T.normalizeTimer({ status: 'paused', durationMs: 1_200_000, remainingMs: null, startedAt: t0 }).remainingSeconds, 1200);
for (const v of [NaN, undefined, null, Infinity, -5, 'a']) assert.equal(F.clock(v), '۰۰:۰۰');
ok('داده‌ی خراب/قدیمی و ورودی‌های نامعتبر: هرگز NaN:NaN نمی‌شود');

// مهاجرت از نسخه‌ی قبلی (بر پایه‌ی میلی‌ثانیه)
const m = T.normalizeTimer({ status: 'running', id: t0, durationMs: 1_500_000, startedAt: t0, endsAt: t0 + 1_500_000 });
assert.equal(m.durationSeconds, 1500); assert.equal(m.sessionId, String(t0)); ok('مهاجرت از ساختار قدیمی');

console.log(`\nهمه‌ی ${n} بررسی موفق بود.`);
