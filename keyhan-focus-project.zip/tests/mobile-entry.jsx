import { createElement as h } from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import MobileApp from '../src/mobile/MobileApp.jsx';
export { h, createRoot, act, MobileApp };
