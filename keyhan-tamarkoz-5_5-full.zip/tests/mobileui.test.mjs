// اجرا: node tests/mobileui.test.mjs — رابط موبایل (React) در jsdom: ناوبری، تایمر، استراحت، باغ، تنظیمات، نبود «کارهای روزانه»
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { JSDOM } from 'jsdom';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', { url: 'https://localhost/index.html', pretendToBeVisual: true });
const w = dom.window;
for (const k of ['window', 'document', 'localStorage', 'CustomEvent', 'HTMLElement', 'Event', 'KeyboardEvent', 'MouseEvent', 'MutationObserver', 'getComputedStyle', 'Node']) {
  Object.defineProperty(globalThis, k, { configurable: true, writable: true, value: k === 'window' ? w : w[k] });
}
w.matchMedia = w.matchMedia || (() => ({ matches: false, addListener() {}, removeListener() {} }));
w.Element.prototype.scrollIntoView = () => {};
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
w.ResizeObserver = globalThis.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };

const out = join(mkdtempSync(join(tmpdir(), 'kt-mui-')), 'bundle.mjs');
await build({ entryPoints: ['tests/mobile-entry.jsx'], bundle: true, format: 'esm', platform: 'node', outfile: out, jsx: 'automatic', loader: { '.css': 'empty', '.woff2': 'empty' }, logLevel: 'error', define: { 'process.env.NODE_ENV': '"development"' } });
const { h, createRoot, act, MobileApp } = await import(pathToFileURL(out).href);

let n = 0;
const ok = (name) => console.log(`✓ ${++n}. ${name}`);
const $ = (sel, root = w.document) => root.querySelector(sel);
const $$ = (sel, root = w.document) => [...root.querySelectorAll(sel)];
const btn = (text) => $$('button').find((e) => e.textContent.trim().includes(text));
const flush = () => act(async () => { await new Promise((r) => setTimeout(r, 40)); });
const read = (k) => JSON.parse(w.localStorage.getItem('kt:' + k) || 'null');
const seed = (k, v) => w.localStorage.setItem('kt:' + k, JSON.stringify(v));
const click = (el) => act(async () => { el.dispatchEvent(new w.MouseEvent('click', { bubbles: true })); });
const type = (el, v) => act(async () => { Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype, 'value').set.call(el, v); el.dispatchEvent(new w.Event('input', { bubbles: true })); });
const blur = (el) => act(async () => { el.dispatchEvent(new w.Event('blur', { bubbles: true })); el.dispatchEvent(new w.Event('focusout', { bubbles: true })); });
let root;
const mount = async () => { w.document.body.innerHTML = '<div id="root"></div>'; root = createRoot($('#root')); await act(async () => root.render(h(MobileApp))); await flush(); };
const unmount = async () => { await act(async () => root.unmount()); w.localStorage.clear(); };
const tab = (label) => click($$('.m-nav button').find((b) => b.textContent.trim() === label));

await mount();
assert.deepEqual($$('.m-nav button').map((b) => b.textContent.trim()), ['تمرکز', 'باغ', 'آمار', 'تنظیمات']);
assert.equal($$('.m-nav svg, .m-nav img, .m-nav i').length, 0, 'منوی ناوبری نباید آیکون داشته باشد');
ok('ناوبری فقط متن است (بدون آیکون) و چهار بخش دارد');

for (const t of ['تمرکز', 'باغ', 'آمار', 'تنظیمات']) {
  await tab(t); await flush();
  assert.ok(!w.document.body.textContent.includes('کارهای روزانه'), `«کارهای روزانه» در بخش ${t}`);
  assert.equal($$('a[href*="tasks"]').length, 0);
}
ok('«کارهای روزانه» در هیچ بخشی نیست');

await tab('تمرکز'); await flush();
assert.ok($('.m-quote').textContent.trim().length > 6); assert.ok($('.orbit'));
await click(btn('شروع تمرکز')); await flush();
let t = read('timer'); assert.equal(t.status, 'running'); assert.equal(t.kind, 'focus');
assert.ok(btn('توقف موقت') && btn('انصراف از جلسه'), 'کنترل‌های ۱۰ ثانیه‌ی اول');
await click(btn('انصراف از جلسه')); await flush();
assert.equal(read('timer').status, 'idle'); assert.equal((read('sessions') || []).length, 0);
ok('شروع و انصراف در ۱۰ ثانیه‌ی اول، بدون ثبت جلسه');

// پایان تمرکز → پیشنهاد استراحت و جلسه‌ی جدید
const now = Date.now();
seed('settings', { breakMinutes: 7 });
seed('timer', { status: 'idle', kind: 'focus', durationSeconds: 1500, remainingSeconds: 1500, startedAt: null, endsAt: null, gracePeriodEndsAt: null, graceRemainingMs: null, sessionId: null, lastResult: { minutes: 25, at: now - 5000, sessionId: 's1', sound: null, notice: false, kind: 'focus' } });
await unmount(); seed('settings', { breakMinutes: 7 });
seed('timer', { status: 'idle', kind: 'focus', durationSeconds: 1500, remainingSeconds: 1500, startedAt: null, endsAt: null, gracePeriodEndsAt: null, graceRemainingMs: null, sessionId: null, lastResult: { minutes: 25, at: now - 5000, sessionId: 's1', sound: null, notice: false, kind: 'focus' } });
await mount();
assert.ok(btn('استراحت ۷ دقیقه‌ای'), 'دکمه‌ی استراحت با مدت تنظیم‌شده'); assert.ok(btn('شروع جلسه‌ی جدید')); assert.ok(btn('تمدید ۵ دقیقه‌ای'));
assert.ok(w.document.body.textContent.includes('۲۵ دقیقه ثبت شد'));
await click(btn('استراحت ۷ دقیقه‌ای')); await flush();
t = read('timer'); assert.equal(t.kind, 'break'); assert.equal(t.durationSeconds, 420);
assert.ok(w.document.body.textContent.includes('در حال استراحت')); assert.ok(btn('رد کردن استراحت') && btn('شروع جلسه‌ی جدید'));
assert.ok(!btn('توقف موقت'), 'استراحت مکث ندارد');
ok('بعد از پایان تمرکز: استراحت با مدت تنظیمات شروع می‌شود و وضعیت جدا دارد');
await click(btn('رد کردن استراحت')); await flush();
assert.equal(read('timer').status, 'idle'); ok('رد کردن استراحت');
await unmount();

// باغ
const S = (i, m) => ({ id: 's' + i, startedAt: 1.7e12 + i * 1e7, endedAt: 1.7e12 + i * 1e7 + m * 60000, plannedMs: m * 60000, focusedMs: m * 60000, completed: true, source: 'timer' });
seed('sessions', [S(1, 60), S(2, 60), S(3, 30), { ...S(4, 90), source: 'manual' }]);
await mount(); await tab('باغ'); await flush();
assert.equal($$('svg.plant').length, 0, 'تصویر گیاه/گل نمایش داده نشود'); assert.equal($$('.m-flowers').length, 0);
assert.ok(w.document.body.textContent.includes('گل‌های شکوفاشده (۱)')); assert.equal($('.m-bar').getAttribute('aria-valuenow'), '50');
assert.ok(w.document.body.textContent.includes('فعلاً غیرفعال'));
ok('باغ: تصویر گل‌ها غیرفعال، ولی پیشرفت و تعداد گل‌ها (۱ گل، ۵۰ امتیاز؛ جلسه‌ی دستی شمرده نشد) حفظ شده');
await unmount();
await mount(); await tab('باغ'); await flush();
assert.ok(w.document.body.textContent.includes('هنوز گلی نشکفته')); ok('باغ خالی: حالت بدون داده');

// تنظیمات
await tab('تنظیمات'); await flush();
const inp = $('input[aria-label="مدت استراحت به دقیقه"]');
assert.ok(inp, 'فیلد مدت استراحت'); assert.equal(inp.value, '۵');
await type(inp, '۱۲'); await blur(inp); await flush();
assert.equal(read('settings').breakMinutes, 12);
await type(inp, '۹۹'); await blur(inp); await flush();
assert.equal(read('settings').breakMinutes, 12); assert.equal(inp.value, '۱۲');
ok('تنظیم مدت استراحت: ذخیره و رد مقدار خارج از ۱ تا ۶۰');
assert.ok(!w.document.body.textContent.includes('کارهای روزانه'));
await click(btn('مدیریت')); await flush();
assert.ok(w.document.body.textContent.includes('محدودیت برنامه‌ها') && w.document.body.textContent.includes('مسدودسازی قطعی نیست'));
assert.ok($('.m-search')); await click(btn('بازگشت')); await flush();
assert.ok(w.document.body.textContent.includes('مدت استراحت'));
ok('صفحه‌ی محدودیت برنامه‌ها با توضیح صادقانه باز و بسته می‌شود');
const ext = $('input[aria-label="مدت تمدید جلسه به دقیقه"]');
assert.ok(ext); assert.equal(ext.value, '۵'); await type(ext, '۱۵'); await blur(ext); await flush();
assert.equal(read('settings').extendMinutes, 15); await type(ext, '۰'); await blur(ext); await flush(); assert.equal(read('settings').extendMinutes, 15);
ok('مدت تمدید جلسه: ذخیره و رد مقدار نامعتبر');
const ov = $('button[aria-label="پنجره‌ی پایان جلسه روی برنامه‌ها"]');
assert.ok(ov); assert.equal(ov.getAttribute('aria-checked'), 'false');
await click(ov); await flush(); assert.notEqual(read('settings').endOverlay, true, 'بدون مجوز، پنجره‌ی روی برنامه‌ها روشن نمی‌شود');
ok('پنجره‌ی پایان جلسه بدون مجوز فعال نمی‌شود');

await click(btn('مدیریت')); await flush();
const sw = $('button[aria-label="حالت محدودسازی"]');
assert.ok(sw); assert.equal(sw.getAttribute('aria-checked'), 'false');
assert.ok(w.document.body.textContent.includes('۱۰۰٪ نیست'), 'محدودیت اندروید صادقانه گفته شود');
await click(sw); await flush();
assert.notEqual(read('settings').blockMode, true, 'بدون رضایت و مجوز روشن نمی‌شود');
assert.ok($$('[role=alert]').some((e) => e.textContent.includes('رضایت')));
await click($('.m-consent input')); await click(sw); await flush();
assert.notEqual(read('settings').blockMode, true, 'بدون مجوزها (خارج از اندروید) روشن نمی‌شود');
assert.ok($$('[role=alert]').some((e) => e.textContent.includes('مجوز')));
ok('حالت محدودسازی بدون رضایت صریح و هر دو مجوز فعال نمی‌شود');
seed('settings', { ...read('settings'), blockMode: true }); await unmount(); seed('settings', { blockMode: true });
seed('timer', { status: 'running', kind: 'focus', durationSeconds: 1500, remainingSeconds: 1500, startedAt: Date.now() - 60000, endsAt: Date.now() + 1440000, gracePeriodEndsAt: Date.now() - 50000, graceRemainingMs: null, sessionId: 'z1', lastResult: null });
await mount();
assert.ok(btn('خاموش کردن حالت محدودسازی'), 'خروج وسط تمرکز همیشه در دسترس است');
await click(btn('خاموش کردن حالت محدودسازی')); await flush();
assert.equal(read('settings').blockMode, false); assert.ok(!btn('خاموش کردن حالت محدودسازی'));
ok('وسط تمرکز (بعد از ۱۰ ثانیه) خاموش‌کردن حالت محدودسازی ممکن است');
await tab('آمار'); await flush(); assert.ok($('.tabs')); ok('آمار رندر می‌شود');
await unmount();
console.log('Mobile UI tests complete');
process.exit(0);
