package com.keyhan.tamarkoz;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * منطق تایمر سمت native؛ همان ساختار JSON ی را می‌خواند/می‌نویسد که src/core/timerService.js می‌سازد.
 * زمان همیشه از timestamp ذخیره‌شده (startedAt/endsAt) می‌آید، نه شمارنده‌ی درون‌حافظه.
 */
public final class TimerEngine {
    public static final long STOP_WINDOW_MS = 10_000L;
    public static final long LATE_LIMIT_MS = 20_000L; // مثل SOUND_MAX_DELAY_MS در JS

    public static final class Result {
        public String kind;      // focus | break
        public int minutes;
        public String sessionId;
        public String sound;     // null = بی‌صدا
        public boolean notice;
    }

    private TimerEngine() {}

    static JSONObject obj(Kv kv, String key) {
        String raw = kv.get(key);
        if (raw == null) return null;
        try { return new JSONObject(raw); } catch (JSONException e) { return null; }
    }

    static JSONArray arr(Kv kv, String key) {
        String raw = kv.get(key);
        if (raw == null) return new JSONArray();
        try { return new JSONArray(raw); } catch (JSONException e) { return new JSONArray(); }
    }

    public static JSONObject settings(Kv kv) {
        JSONObject s = obj(kv, "settings");
        return s == null ? new JSONObject() : s;
    }

    static int clampInt(JSONObject s, String key, int def, int min, int max) {
        Object v = s.opt(key);
        if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            if (d == Math.floor(d) && d >= min && d <= max) return (int) d;
        }
        return def;
    }

    public static int defaultMinutes(Kv kv) { return clampInt(settings(kv), "defaultMinutes", 25, 1, 360); }
    public static int breakMinutes(Kv kv) { return clampInt(settings(kv), "breakMinutes", 5, 1, 60); }
    public static int extendMinutes(Kv kv) { return clampInt(settings(kv), "extendMinutes", 5, 1, 60); }

    /** تغییر یک کلید در تنظیمات (مثلاً خاموش‌کردن حالت محدودسازی از اعلان). */
    public static void setSetting(Kv kv, String key, Object value) {
        try {
            JSONObject s = settings(kv);
            s.put(key, value);
            kv.put("settings", s.toString());
        } catch (JSONException ignored) { }
    }

    static String soundId(JSONObject settings) {
        String id = settings.optString("soundId", "ding");
        switch (id) {
            case "ding": case "chime": case "soft": case "drop": case "custom": return id;
            default: return "ding";
        }
    }

    static JSONObject idle(Kv kv, JSONObject lastResult) throws JSONException {
        int m = defaultMinutes(kv);
        JSONObject o = new JSONObject();
        o.put("status", "idle");
        o.put("kind", "focus");
        o.put("durationSeconds", m * 60);
        o.put("remainingSeconds", m * 60);
        o.put("startedAt", JSONObject.NULL);
        o.put("endsAt", JSONObject.NULL);
        o.put("gracePeriodEndsAt", JSONObject.NULL);
        o.put("graceRemainingMs", JSONObject.NULL);
        o.put("sessionId", JSONObject.NULL);
        o.put("lastResult", lastResult == null ? JSONObject.NULL : lastResult);
        return o;
    }

    private static boolean start(Kv kv, String kind, int minutes, long now) {
        try {
            long dur = minutes * 60L;
            JSONObject o = new JSONObject();
            boolean brk = "break".equals(kind);
            o.put("status", "running");
            o.put("kind", kind);
            o.put("durationSeconds", dur);
            o.put("remainingSeconds", dur);
            o.put("startedAt", now);
            o.put("endsAt", now + dur * 1000L);
            o.put("gracePeriodEndsAt", brk ? now : now + STOP_WINDOW_MS);
            o.put("graceRemainingMs", JSONObject.NULL);
            o.put("sessionId", (brk ? "break-" : "") + now + "-n" + Long.toString(now % 99991, 36));
            o.put("lastResult", JSONObject.NULL);
            kv.put("timer", o.toString());
            return true;
        } catch (JSONException e) {
            return false;
        }
    }

    public static boolean startFocus(Kv kv, int minutes, long now) {
        if (minutes < 1 || minutes > 360) return false;
        return start(kv, "focus", minutes, now);
    }

    /** وسط تمرکزِ در حال اجرا/متوقف، استراحت شروع نمی‌شود (مثل JS). */
    public static boolean startBreak(Kv kv, int minutes, long now) {
        if (minutes < 1 || minutes > 60) return false;
        JSONObject t = obj(kv, "timer");
        if (t != null && !"break".equals(t.optString("kind"))) {
            String st = t.optString("status");
            if ("running".equals(st) || "paused".equals(st)) return false;
        }
        return start(kv, "break", minutes, now);
    }

    /** پایان تایمر در حال اجرا (اگر زمانش رسیده). هر جلسه با sessionId فقط یک بار ثبت می‌شود. */
    public static Result finish(Kv kv, long now) {
        try {
            JSONObject t = obj(kv, "timer");
            if (t == null || !"running".equals(t.optString("status"))) return null;
            long endsAt = t.optLong("endsAt", 0);
            if (endsAt <= 0 || now < endsAt) return null;
            boolean brk = "break".equals(t.optString("kind"));
            long startedAt = t.optLong("startedAt", 0);
            long dur = t.optLong("durationSeconds", 0);
            if (startedAt <= 0 || dur <= 0) return null;
            Object rawId = t.opt("sessionId");
            String sid = rawId == null || rawId == JSONObject.NULL || String.valueOf(rawId).isEmpty() ? String.valueOf(startedAt) : String.valueOf(rawId);
            JSONObject settings = settings(kv);
            boolean onTime = now - endsAt <= LATE_LIMIT_MS;
            boolean recorded = true;
            if (!brk) {
                JSONArray sessions = arr(kv, "sessions");
                for (int i = 0; i < sessions.length(); i++) {
                    JSONObject s = sessions.optJSONObject(i);
                    if (s != null && sid.equals(String.valueOf(s.opt("id")))) { recorded = false; break; }
                }
                if (recorded) {
                    JSONObject s = new JSONObject();
                    s.put("id", sid);
                    s.put("startedAt", startedAt);
                    s.put("endedAt", endsAt);
                    s.put("plannedMs", dur * 1000L);
                    s.put("focusedMs", dur * 1000L);
                    s.put("completed", true);
                    s.put("source", "timer");
                    sessions.put(s);
                    kv.put("sessions", sessions.toString());
                }
            }
            int minutes = (int) Math.round(dur / 60.0);
            String sound = recorded && onTime && settings.optBoolean("soundEnabled", true) ? soundId(settings) : null;
            JSONObject last = new JSONObject();
            last.put("minutes", minutes);
            last.put("at", endsAt);
            last.put("sessionId", sid);
            last.put("sound", sound == null ? JSONObject.NULL : sound);
            last.put("notice", recorded && onTime);
            last.put("kind", brk ? "break" : "focus");
            kv.put("timer", idle(kv, last).toString());
            return fromLastResult(last);
        } catch (JSONException e) {
            return null;
        }
    }

    public static Result fromLastResult(JSONObject last) {
        Result r = new Result();
        r.kind = "break".equals(last.optString("kind")) ? "break" : "focus";
        r.minutes = last.optInt("minutes", 0);
        r.sessionId = last.optString("sessionId", null);
        String snd = last.isNull("sound") ? null : last.optString("sound", null);
        r.sound = snd;
        r.notice = last.optBoolean("notice", false);
        return r;
    }
}
