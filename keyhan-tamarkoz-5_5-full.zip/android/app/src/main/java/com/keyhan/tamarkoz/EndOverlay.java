package com.keyhan.tamarkoz;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * پنجره‌ی کوچک پایان جلسه روی برنامه‌های دیگر (TYPE_APPLICATION_OVERLAY). با «اعلان شناور» (heads-up) فرق دارد:
 * اعلان را سیستم نشان می‌دهد؛ این پنجره را خود اپ می‌کشد و فقط با مجوز جدای «نمایش روی برنامه‌های دیگر» و تنظیم اختیاری کاربر ساخته می‌شود.
 */
final class EndOverlay {
    private static View current;
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final long AUTO_DISMISS_MS = 30_000L;

    private EndOverlay() {}

    private static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    static void show(Context ctx, TimerEngine.Result r) {
        final Context app = ctx.getApplicationContext();
        if (!Settings.canDrawOverlays(app)) return;
        final boolean brk = "break".equals(r.kind);
        H.post(() -> {
            try {
                dismissNow(app);
                WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
                LinearLayout root = new LinearLayout(app);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                root.setPadding(dp(app, 18), dp(app, 16), dp(app, 18), dp(app, 14));
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Color.parseColor("#0D1124"));
                bg.setCornerRadius(dp(app, 20));
                bg.setStroke(dp(app, 1), Color.parseColor("#3A4166"));
                root.setBackground(bg);

                TextView title = new TextView(app);
                title.setText(brk ? "استراحت تمام شد" : "تمرکزت تموم شد");
                title.setTextColor(Color.parseColor("#E9EBF7"));
                title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                root.addView(title);

                LinearLayout row = new LinearLayout(app);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                rowLp.topMargin = dp(app, 12);
                root.addView(row, rowLp);

                if (!brk) addButton(app, row, "استراحت", TimerService.ACTION_REST);
                addButton(app, row, brk ? "شروع جلسه‌ی جدید" : "تمدید جلسه", brk ? TimerService.ACTION_NEW : TimerService.ACTION_EXTEND);
                Button close = new Button(app);
                close.setText("بستن");
                close.setOnClickListener(v -> dismissNow(app));
                row.addView(close, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

                int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : legacyType();
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                        (int) (app.getResources().getDisplayMetrics().widthPixels * 0.92f),
                        WindowManager.LayoutParams.WRAP_CONTENT, type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                        PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                lp.y = dp(app, 48);
                wm.addView(root, lp);
                current = root;
                H.postDelayed(() -> dismissNow(app), AUTO_DISMISS_MS);
            } catch (Exception ignored) { /* مجوز نبود یا سیستم اجازه نداد؛ اعلان شناور همچنان هست */ }
        });
    }

    @SuppressWarnings("deprecation")
    private static int legacyType() { return WindowManager.LayoutParams.TYPE_PHONE; }

    private static void addButton(Context app, LinearLayout row, String text, String action) {
        Button b = new Button(app);
        b.setText(text);
        b.setOnClickListener(v -> {
            TimerService.start(app, action, null);
            dismissNow(app);
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMarginEnd(dp(app, 8));
        row.addView(b, lp);
    }

    static void dismiss(Context ctx) {
        final Context app = ctx.getApplicationContext();
        H.post(() -> dismissNow(app));
    }

    private static void dismissNow(Context app) {
        if (current == null) return;
        try {
            ((WindowManager) app.getSystemService(Context.WINDOW_SERVICE)).removeView(current);
        } catch (Exception ignored) { }
        current = null;
    }
}
