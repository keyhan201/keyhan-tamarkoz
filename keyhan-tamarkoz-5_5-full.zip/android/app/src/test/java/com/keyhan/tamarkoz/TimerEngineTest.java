package com.keyhan.tamarkoz;

import static org.junit.Assert.*;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class TimerEngineTest {
    static class MapKv implements Kv {
        final Map<String, String> m = new HashMap<>();
        public String get(String k) { return m.get(k); }
        public void put(String k, String v) { m.put(k, v); }
    }

    private MapKv kv() {
        MapKv k = new MapKv();
        k.put("settings", "{\"defaultMinutes\":25,\"breakMinutes\":7,\"soundEnabled\":true,\"soundId\":\"chime\"}");
        return k;
    }

    @Test public void focusFinishRecordsSessionOnceAndSetsLastResult() throws Exception {
        MapKv k = kv();
        long t0 = 1_000_000L;
        assertTrue(TimerEngine.startFocus(k, 25, t0));
        assertNull("before end", TimerEngine.finish(k, t0 + 24 * 60_000L));
        TimerEngine.Result r = TimerEngine.finish(k, t0 + 25 * 60_000L + 500);
        assertNotNull(r);
        assertEquals("focus", r.kind);
        assertEquals(25, r.minutes);
        assertEquals("chime", r.sound);
        assertTrue(r.notice);
        JSONArray s = new JSONArray(k.get("sessions"));
        assertEquals(1, s.length());
        assertEquals("timer", s.getJSONObject(0).getString("source"));
        assertNull("second call is idempotent", TimerEngine.finish(k, t0 + 26 * 60_000L));
        assertEquals(1, new JSONArray(k.get("sessions")).length());
        assertEquals("idle", new JSONObject(k.get("timer")).getString("status"));
    }

    @Test public void lateFinishIsRecordedButSilent() throws Exception {
        MapKv k = kv();
        TimerEngine.startFocus(k, 5, 0L);
        TimerEngine.Result r = TimerEngine.finish(k, 5 * 60_000L + 60_000L);
        assertNotNull(r);
        assertNull(r.sound);
        assertFalse(r.notice);
        assertEquals(1, new JSONArray(k.get("sessions")).length());
    }

    @Test public void breakNeverRecordsSessionAndCannotStartDuringFocus() throws Exception {
        MapKv k = kv();
        TimerEngine.startFocus(k, 25, 10L);
        assertFalse(TimerEngine.startBreak(k, 5, 20L));
        MapKv k2 = kv();
        assertTrue(TimerEngine.startBreak(k2, 5, 0L));
        TimerEngine.Result r = TimerEngine.finish(k2, 5 * 60_000L);
        assertNotNull(r);
        assertEquals("break", r.kind);
        assertNull(k2.get("sessions"));
    }

    @Test public void breakMinutesComeFromSettingsWithBounds() {
        MapKv k = kv();
        assertEquals(7, TimerEngine.breakMinutes(k));
        k.put("settings", "{\"breakMinutes\":999}");
        assertEquals(5, TimerEngine.breakMinutes(k));
        assertFalse(TimerEngine.startBreak(k, 0, 0));
        assertFalse(TimerEngine.startBreak(k, 61, 0));
    }

    @Test public void limitDecisionMatchesRules() throws Exception {
        JSONObject running = new JSONObject("{\"status\":\"running\",\"kind\":\"focus\"}");
        JSONObject brk = new JSONObject("{\"status\":\"running\",\"kind\":\"break\"}");
        JSONObject s = new JSONObject("{\"limitEnabled\":true,\"limitedApps\":[\"com.example.social\"]}");
        String self = "com.keyhan.tamarkoz";
        assertTrue(LimitMonitor.shouldWarn(running, s, "com.example.social", 100_000, 0, self));
        assertFalse(LimitMonitor.shouldWarn(brk, s, "com.example.social", 100_000, 0, self));
        assertFalse(LimitMonitor.shouldWarn(running, s, "com.example.other", 100_000, 0, self));
        assertFalse(LimitMonitor.shouldWarn(running, s, "com.example.social", 100_000, 90_000, self));
        assertFalse(LimitMonitor.shouldWarn(running, new JSONObject("{\"limitEnabled\":false,\"limitedApps\":[\"com.example.social\"]}"), "com.example.social", 100_000, 0, self));
    }

    @Test public void extendMinutesAndSettingWrite() throws Exception {
        MapKv k = kv();
        assertEquals(5, TimerEngine.extendMinutes(k));
        TimerEngine.setSetting(k, "extendMinutes", 15);
        assertEquals(15, TimerEngine.extendMinutes(k));
        TimerEngine.setSetting(k, "extendMinutes", 0);
        assertEquals(5, TimerEngine.extendMinutes(k));
        TimerEngine.setSetting(k, "blockMode", false);
        assertFalse(TimerEngine.settings(k).getBoolean("blockMode"));
        assertEquals("chime", TimerEngine.settings(k).getString("soundId"));
    }

    @Test public void extendIsANewSessionAndNeverDuplicatesTheFinishedOne() throws Exception {
        MapKv k = kv();
        TimerEngine.startFocus(k, 25, 0L);
        TimerEngine.Result first = TimerEngine.finish(k, 25 * 60_000L);
        assertNotNull(first);
        assertTrue(TimerEngine.startFocus(k, TimerEngine.extendMinutes(k), 25 * 60_000L + 1000));
        JSONObject t = new JSONObject(k.get("timer"));
        assertEquals("running", t.getString("status"));
        assertEquals(300, t.getInt("durationSeconds"));
        assertNotEquals(first.sessionId, t.getString("sessionId"));
        assertEquals(1, new JSONArray(k.get("sessions")).length());
        assertNull("finish of the old session id again is a no-op", TimerEngine.finish(k, 25 * 60_000L + 500));
    }

    @Test public void bounceOnlyInFocusForUnsafeAppsAndNeverForSafeOnes() throws Exception {
        JSONObject running = new JSONObject("{\"status\":\"running\",\"kind\":\"focus\"}");
        JSONObject brk = new JSONObject("{\"status\":\"running\",\"kind\":\"break\"}");
        JSONObject on = new JSONObject("{\"blockMode\":true}");
        JSONObject off = new JSONObject("{\"blockMode\":false}");
        String self = "com.keyhan.tamarkoz";
        java.util.Set<String> none = new java.util.HashSet<>();
        assertTrue(LimitMonitor.shouldBounce(running, on, "com.example.game", 100_000, 0, self, none));
        assertFalse(LimitMonitor.shouldBounce(running, off, "com.example.game", 100_000, 0, self, none));
        assertFalse(LimitMonitor.shouldBounce(brk, on, "com.example.game", 100_000, 0, self, none));
        assertFalse(LimitMonitor.shouldBounce(running, on, self, 100_000, 0, self, none));
        assertFalse(LimitMonitor.shouldBounce(running, on, "com.android.settings", 100_000, 0, self, none));
        assertFalse(LimitMonitor.shouldBounce(running, on, "com.google.android.dialer", 100_000, 0, self, none));
        assertFalse(LimitMonitor.shouldBounce(running, on, "com.android.emergency", 100_000, 0, self, none));
        assertFalse(LimitMonitor.shouldBounce(running, on, "com.custom.keyboard", 100_000, 0, self, new java.util.HashSet<>(java.util.Arrays.asList("com.custom.keyboard"))));
        assertFalse(LimitMonitor.shouldBounce(running, on, "com.example.game", 100_000, 99_000, self, none));
    }
}
