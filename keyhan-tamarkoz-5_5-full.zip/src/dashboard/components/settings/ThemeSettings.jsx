import { useState } from 'react';
import Dropdown from '../../../shared/Dropdown.jsx';
import Icon from '../../../shared/Icon.jsx';
import { THEMES, themeIdOf } from '../../../core/themes.js';
import { MAX_CUSTOM_THEMES, MAX_THEME_NAME, deriveVars, isHex, newCustomId, normalizeCustomThemes, validateCustomTheme } from '../../../core/themeColors.js';
import { toFa } from '../../../core/format.js';

const START = { name: '', accent: '#f1d28b', bg: '#0d1124', ink: '#e9ebf7' };

function Swatch({ id, custom }) {
  if (custom) return <span className="theme-swatch" style={deriveVars(custom)} aria-hidden="true"><i /><i /><i /></span>;
  return <span className="theme-swatch" data-theme={id} aria-hidden="true"><i /><i /><i /></span>;
}

/** انتخاب تم از منوی بازشونده + ساخت، ذخیره و حذف تم شخصی (فقط سه رنگ معتبر). */
export default function ThemeSettings({ s, patch, Row }) {
  const customs = normalizeCustomThemes(s.customThemes);
  const theme = themeIdOf(s.theme, customs);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(START);
  const [err, setErr] = useState(null); // { field, error }
  const [done, setDone] = useState('');
  const [confirmId, setConfirmId] = useState(null);

  const byValue = new Map([
    ...THEMES.map((t) => [t.id, { id: t.id, custom: null }]),
    ...customs.map((c) => [c.id, { id: c.id, custom: c }]),
  ]);
  const options = [
    ...THEMES.map((t) => ({ value: t.id, label: t.label, group: 'تم‌های آماده' })),
    ...customs.map((c) => ({ value: c.id, label: c.name, group: 'تم‌های شخصی' })),
  ];
  const show = (o) => {
    const info = byValue.get(o.value);
    return (<span className="dd-opt-main"><Swatch id={info.id} custom={info.custom} /><span>{o.label}</span></span>);
  };

  const set = (k) => (e) => { setDraft((d) => ({ ...d, [k]: e.target.value })); setErr(null); setDone(''); };
  const previewOk = isHex(draft.accent) && isHex(draft.bg) && isHex(draft.ink);

  const save = () => {
    if (customs.length >= MAX_CUSTOM_THEMES) {
      setErr({ field: 'name', error: `حداکثر ${toFa(MAX_CUSTOM_THEMES)} تم شخصی می‌توانید نگه دارید. یکی را حذف کنید.` });
      return;
    }
    const v = validateCustomTheme(draft);
    if (!v.ok) { setErr(v); return; }
    const id = newCustomId();
    patch({ customThemes: [...customs, { id, ...v.theme }], theme: id });
    setEditing(false);
    setDraft(START);
    setDone(`تم «${v.theme.name}» ذخیره و اعمال شد.`);
  };

  const remove = (id) => {
    patch({ customThemes: customs.filter((c) => c.id !== id), ...(theme === id ? { theme: 'main' } : {}) });
    setConfirmId(null);
  };

  return (
    <>
      <Row title="تم" hint="روی پنجره‌ی افزونه و همه‌ی بخش‌های صفحه‌ی کامل اعمال می‌شود.">
        <Dropdown label="تم" value={theme} options={options} onChange={(v) => patch({ theme: v })} renderOption={show} renderValue={show} />
      </Row>

      <Row title="تم شخصی" hint="رنگ تأکیدی، پس‌زمینه و متن را خودتان انتخاب کنید. تم‌های آماده تغییر نمی‌کنند.">
        <button className="btn" onClick={() => { setEditing((v) => !v); setErr(null); setDone(''); }} aria-expanded={editing}>
          <Icon name="plus" size={17} /> {editing ? 'بستن' : 'ساخت تم'}
        </button>
      </Row>
      {done && <p className="okmsg" role="status">{done}</p>}

      {editing && (
        <div className="panel" role="group" aria-label="ساخت تم شخصی">
          <label className="fld">
            <span>نام تم</span>
            <input className="text-input" value={draft.name} maxLength={MAX_THEME_NAME} onChange={set('name')} aria-invalid={err && err.field === 'name'} />
          </label>
          <div className="color-row">
            {[['accent', 'رنگ تأکیدی'], ['bg', 'پس‌زمینه'], ['ink', 'متن']].map(([k, label]) => (
              <label className="color-field" key={k}>
                <span>{label}</span>
                <input type="color" value={isHex(draft[k]) ? draft[k] : '#000000'} onChange={set(k)} aria-invalid={err && err.field === k} />
                <code>{draft[k]}</code>
              </label>
            ))}
          </div>
          {previewOk && (
            <div className="theme-preview" style={deriveVars(draft)} aria-label="پیش‌نمایش تم">
              <span className="pv-card">نمونه متن</span>
              <span className="pv-btn">دکمه</span>
              <span className="pv-mute">متن کم‌رنگ</span>
            </div>
          )}
          {err && <p className="err" role="alert">{err.error}</p>}
          <div className="confirm">
            <button className="btn solid" onClick={save}>ذخیره و اعمال</button>
            <button className="btn" onClick={() => { setEditing(false); setErr(null); }}>انصراف</button>
          </div>
        </div>
      )}

      {customs.length > 0 && (
        <ul className="custom-list" aria-label="تم‌های شخصی ذخیره‌شده">
          {customs.map((c) => (
            <li key={c.id}>
              <span className="dd-opt-main"><Swatch id={c.id} custom={c} /><span>{c.name}</span></span>
              {confirmId === c.id ? (
                <span className="confirm">
                  <button className="btn danger small" onClick={() => remove(c.id)}>بله، حذف شود</button>
                  <button className="btn small" onClick={() => setConfirmId(null)}>انصراف</button>
                </span>
              ) : (
                <span className="confirm">
                  {theme !== c.id && <button className="btn small" onClick={() => patch({ theme: c.id })}>انتخاب</button>}
                  <button className="icon-btn" onClick={() => setConfirmId(c.id)} aria-label={`حذف تم ${c.name}`} title="حذف"><Icon name="trash" size={17} /></button>
                </span>
              )}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
