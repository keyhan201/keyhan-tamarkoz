import { useEffect, useMemo, useRef, useState } from 'react';
import { App as CapApp } from '@capacitor/app';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { DEFAULT_SETTINGS, KEYS, MAX_BREAK_MINUTES, MAX_MINUTES, MIN_BREAK_MINUTES, MIN_MINUTES, PRESETS } from '../core/constants.js';
import { fromFa, toFa, clock, duration } from '../core/format.js';
import { addCustomMinute, normalizeCustomMinutes, parseMinutes, removeCustomMinute } from '../core/durations.js';
import { cancelTimer, pauseTimer, resumeTimer, startBreak, startTimer } from '../core/timerService.js';
import { MAX_BACKUP_BYTES, parseBackup, restoreBackup } from '../core/backup.js';
import { dailySummaryJson, sessionsToCsv } from '../core/exportStats.js';
import { categoryFor, pickQuote, pushRecent } from '../core/quotes.js';
import { gardenFromSessions, FLOWER_KINDS, GARDEN_FLOWERS_ENABLED, POINTS_PER_FLOWER, MIN_GROWTH_MINUTES } from '../core/garden.js';
import { MAX_LIMITED_APPS, normalizePackages, togglePackage } from '../core/appLimits.js';
import { getItem, setItem } from '../core/storage.js';
import { MOBILE_QUOTES } from '../data/quotesMobile.js';
import { useSettings, useStoredValue } from '../hooks/useStoredValue.js';
import { useTimer } from '../hooks/useTimer.js';
import { useQuote } from '../hooks/useQuote.js';
import OrbitTimer from '../popup/components/OrbitTimer.jsx';
import StatsView from '../dashboard/components/StatsView.jsx';
import ThemeSettings from '../dashboard/components/settings/ThemeSettings.jsx';
import SoundSettings from '../dashboard/components/settings/SoundSettings.jsx';
import { downloadText } from '../shared/download.js';
import { getPermissions, isNative, listApps, openSetting } from './native.js';

const EMPTY = [];
const TABS = [
  { id: 'focus', label: 'تمرکز' },
  { id: 'garden', label: 'باغ' },
  { id: 'stats', label: 'آمار' },
  { id: 'settings', label: 'تنظیمات' },
];

function Switch({ checked, onChange, label }) {
  return (
    <button role="switch" aria-checked={checked} aria-label={label} className="switch" onClick={() => onChange(!checked)}>
      <span />
    </button>
  );
}
function Row({ title, hint, children }) {
  return (
    <div className="row">
      <div>
        <div className="row-title">{title}</div>
        {hint && <div className="row-hint">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

/* ---------------- تمرکز ---------------- */
function DurationSheet({ minutes, saved, onChange, onSaveList, onClose }) {
  const [custom, setCustom] = useState('');
  const [error, setError] = useState('');
  const list = normalizeCustomMinutes(saved);
  const typedBad = custom.trim() !== '' && parseMinutes(custom) === null;
  const pick = (m) => { setCustom(''); setError(''); onChange(m); };
  const add = () => {
    const r = addCustomMinute(list, custom);
    if (!r.ok) { if (r.duplicate) pick(r.duplicate); else setError(r.error); return; }
    onSaveList(r.list); pick(r.minutes);
  };
  return (
    <>
      <div className="m-scrim" onClick={onClose} />
      <section className="m-sheet" role="dialog" aria-modal="true" aria-label="مدت تمرکز">
        <h2>مدت تمرکز</h2>
        <div className="m-presets" role="group" aria-label="زمان‌های آماده">
          {PRESETS.map((m) => (
            <button key={m} className={'m-preset' + (custom === '' && m === minutes ? ' on' : '')} onClick={() => { pick(m); onClose(); }}>{toFa(m)} دقیقه</button>
          ))}
          {list.map((m) => (
            <span key={m} className={'m-preset saved' + (custom === '' && m === minutes ? ' on' : '')}>
              <button onClick={() => { pick(m); onClose(); }}>{toFa(m)} دقیقه</button>
              <button className="m-x" aria-label={`حذف زمان ${toFa(m)} دقیقه`} onClick={() => { onSaveList(removeCustomMinute(list, m)); }}>حذف</button>
            </span>
          ))}
        </div>
        <label htmlFor="m-custom">افزودن زمان دلخواه (دقیقه)</label>
        <div className={'m-field' + (typedBad || error ? ' bad' : '')}>
          <input id="m-custom" inputMode="numeric" autoComplete="off" maxLength={4} value={custom}
            onChange={(e) => { setCustom(e.target.value); setError(''); const n = parseMinutes(e.target.value); if (n) onChange(n); }}
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } }} />
          <button className="btn small" disabled={custom.trim() === '' || typedBad} onClick={add}>ذخیره</button>
        </div>
        <p className="m-hint" role={typedBad || error ? 'alert' : undefined}>
          {typedBad ? `عددی صحیح بین ${toFa(MIN_MINUTES)} تا ${toFa(MAX_MINUTES)} وارد کنید.` : error || '\u00a0'}
        </p>
        <button className="btn solid wide" onClick={onClose}>تأیید</button>
      </section>
    </>
  );
}

function FocusScreen() {
  const { timer, ready, remainingMs, progress, now, interruptible } = useTimer();
  const [settings, patch] = useSettings();
  const [sheet, setSheet] = useState(false);
  const [perm, setPerm] = useState(null);
  useEffect(() => { getPermissions().then(setPerm); const h = CapApp.addListener('resume', () => getPermissions().then(setPerm)); return () => { h.then((x) => x.remove()); }; }, []);
  const category = ready ? categoryFor(timer, now) : 'start';
  const quote = useQuote(ready && settings.showQuotes, category, timer.sessionId || (timer.lastResult && timer.lastResult.sessionId) || '', MOBILE_QUOTES);
  if (!ready) return <div className="m-screen" />;

  const minutes = Number.isFinite(settings.defaultMinutes) ? settings.defaultMinutes : 25;
  const breakMin = Number.isInteger(settings.breakMinutes) ? settings.breakMinutes : 5;
  const extendMin = Number.isInteger(settings.extendMinutes) ? settings.extendMinutes : 5;
  const idle = timer.status === 'idle';
  const isBreak = timer.kind === 'break';
  const running = timer.status === 'running';
  const last = timer.lastResult && now - timer.lastResult.at < 60 * 60 * 1000 ? timer.lastResult : null;
  const shownMs = idle ? minutes * 60000 : remainingMs;

  let status = 'آماده‌ی تمرکز';
  if (!idle && isBreak) status = 'در حال استراحت';
  else if (running) status = 'در حال تمرکز';
  else if (timer.status === 'paused') status = 'متوقف شد';
  else if (last && last.kind === 'break') status = 'استراحت تمام شد';
  else if (last) status = `تمرکز تمام شد؛ ${toFa(last.minutes)} دقیقه ثبت شد`;

  const begin = () => startTimer(minutes);
  return (
    <div className="m-screen m-focus">
      <p className="m-status" aria-live="polite">{status}</p>
      <OrbitTimer remainingMs={shownMs} progress={progress} active={running} />

      {idle && (
        <button className="m-chip" onClick={() => setSheet(true)} aria-label="تغییر مدت تمرکز">{toFa(minutes)} دقیقه</button>
      )}

      <div className="m-controls">
        {idle && last && last.kind !== 'break' && (
          <button className="btn wide" onClick={() => startBreak(breakMin)}>استراحت {toFa(breakMin)} دقیقه‌ای</button>
        )}
        {idle && last && last.kind !== 'break' && (
          <button className="btn wide" onClick={() => startTimer(extendMin)}>تمدید {toFa(extendMin)} دقیقه‌ای</button>
        )}
        {idle && <button className="btn solid wide big" onClick={begin}>{last ? 'شروع جلسه‌ی جدید' : 'شروع تمرکز'}</button>}
        {!idle && isBreak && (
          <>
            <button className="btn solid wide" onClick={() => cancelTimer().then(() => startTimer(minutes))}>شروع جلسه‌ی جدید</button>
            <button className="btn wide" onClick={() => cancelTimer()}>رد کردن استراحت</button>
          </>
        )}
        {!idle && !isBreak && interruptible && (
          <>
            <button className="btn solid wide big" onClick={() => (running ? pauseTimer() : resumeTimer())}>{running ? 'توقف موقت' : 'ادامه'}</button>
            <button className="btn wide" onClick={() => cancelTimer()}>انصراف از جلسه</button>
          </>
        )}
        {!idle && !isBreak && !interruptible && <p className="m-hint">بعد از ۱۰ ثانیه‌ی اول، جلسه تا پایان ادامه پیدا می‌کند.</p>}
        {!idle && !isBreak && settings.blockMode && (
          <button className="btn wide danger" onClick={() => patch({ blockMode: false })}>خاموش کردن حالت محدودسازی</button>
        )}
      </div>

      {perm && !perm.notifications && settings.notifications && (
        <div className="m-hint" role="status">
          برای اعلام پایان جلسه به اجازه‌ی اعلان نیاز داریم.{' '}
          <button className="btn small" onClick={() => openSetting('requestNotifications')}>اجازه دادن</button>
        </div>
      )}

      {settings.showQuotes && <p className="m-quote" aria-live="polite">{quote ? quote.text : '\u00a0'}</p>}

      {sheet && (
        <DurationSheet minutes={minutes} saved={settings.customMinutes} onChange={(m) => patch({ defaultMinutes: m })}
          onSaveList={(l) => patch(normalizeCustomMinutes(settings.customMinutes).includes(minutes) && !l.includes(minutes) ? { customMinutes: l, defaultMinutes: DEFAULT_SETTINGS.defaultMinutes } : { customMinutes: l })}
          onClose={() => setSheet(false)} />
      )}
    </div>
  );
}

/* ---------------- باغ ---------------- */
export function PlantSvg({ stage, color = '#e5738a', size = 160 }) {
  const stem = 'var(--star)';
  return (
    <svg className="plant" width={size} height={size} viewBox="0 0 120 120" role="img" aria-label={`گیاه: ${stage}`}>
      <ellipse cx="60" cy="108" rx="34" ry="7" fill="var(--night-3)" />
      {stage === 'seed' && <ellipse cx="60" cy="100" rx="9" ry="6" fill="var(--mute)" />}
      {stage === 'sprout' && (<><path d="M60 102V76" stroke={stem} strokeWidth="4" strokeLinecap="round" /><path d="M60 82c-14 0-20-8-20-16 12 0 20 6 20 16zM60 78c12 0 18-8 18-15-11 0-18 6-18 15z" fill={stem} /></>)}
      {stage === 'sapling' && (<><path d="M60 104V48" stroke={stem} strokeWidth="5" strokeLinecap="round" /><path d="M60 88c-18 0-26-9-26-19 15 0 26 7 26 19zM60 74c16 0 24-8 24-18-14 0-24 7-24 18zM60 58c-12 0-18-6-18-14 10 0 18 5 18 14z" fill={stem} /></>)}
      {stage === 'flower' && (<><path d="M60 104V54" stroke={stem} strokeWidth="5" strokeLinecap="round" /><path d="M60 90c-16 0-24-8-24-17 14 0 24 6 24 17z" fill={stem} />{[0, 72, 144, 216, 288].map((a) => (<ellipse key={a} cx="60" cy="36" rx="9" ry="15" fill={color} transform={`rotate(${a} 60 50)`} />))}<circle cx="60" cy="50" r="8" fill="var(--on-star)" opacity=".75" /></>)}
    </svg>
  );
}

function GardenScreen() {
  const [sessions, , ready] = useStoredValue(KEYS.sessions, EMPTY);
  const g = useMemo(() => gardenFromSessions(sessions), [sessions]);
  if (!ready) return <div className="m-screen" />;
  const shown = g.kinds.slice(-60);
  const c = g.current;
  return (
    <div className="m-screen m-garden">
      <h1>باغ من</h1>
      <div className="m-plant-card">
        {GARDEN_FLOWERS_ENABLED && <PlantSvg stage={c.stage.id} />}
        <p className="m-plant-stage">{c.stage.label}</p>
        <div className="m-bar" role="progressbar" aria-valuemin={0} aria-valuemax={POINTS_PER_FLOWER} aria-valuenow={c.points} aria-label="رشد گیاه"><i style={{ width: `${Math.round(c.progress * 100)}%` }} /></div>
        <p className="m-hint">{toFa(c.points)} از {toFa(POINTS_PER_FLOWER)} · {toFa(c.remaining)} دقیقه‌ی تمرکز دیگر تا شکوفه‌شدن</p>
      </div>
      <p className="m-rules">
        هر جلسه‌ی تمرکزِ کامل‌شده (دست‌کم {toFa(MIN_GROWTH_MINUTES)} دقیقه) به اندازه‌ی دقیقه‌هایش گیاه را رشد می‌دهد. استراحت، جلسه‌ی انصرافی و جلسه‌ی دستی رشدی ندارند.
      </p>
      <h2 className="sub">گل‌های شکوفاشده ({toFa(g.flowers)})</h2>
      {g.flowers === 0 ? (
        <p className="empty">هنوز گلی نشکفته؛ با اولین جلسه‌های کامل، باغت شروع می‌شود.</p>
      ) : !GARDEN_FLOWERS_ENABLED ? (
        <p className="m-hint">نمایش تصویری گل‌ها فعلاً غیرفعال است؛ پیشرفت و تعداد گل‌هایت ثبت می‌شود و بعداً نمایش داده خواهد شد.</p>
      ) : (
        <>
          <ul className="m-flowers">
            {shown.map((k, i) => {
              const kind = FLOWER_KINDS.find((f) => f.id === k);
              return <li key={i} title={kind.label}><PlantSvg stage="flower" color={kind.color} size={64} /></li>;
            })}
          </ul>
          {g.flowers > shown.length && <p className="m-hint">و {toFa(g.flowers - shown.length)} گل دیگر</p>}
        </>
      )}
    </div>
  );
}

/* ---------------- محدودیت برنامه‌ها ---------------- */
function LimitsScreen({ onBack }) {
  const [s, patch] = useSettings();
  const [apps, setApps] = useState(null);
  const [perm, setPerm] = useState(null);
  const [q, setQ] = useState('');
  const [consent, setConsent] = useState(false);
  const [blockMsg, setBlockMsg] = useState('');
  const selected = normalizePackages(s.limitedApps);
  const reload = () => getPermissions().then(setPerm);
  useEffect(() => { reload(); listApps().then((a) => setApps(a)); }, []);
  useEffect(() => { const h = CapApp.addListener('resume', reload); return () => { h.then((x) => x.remove()); }; }, []);

  const list = (apps || []).filter((a) => !q.trim() || a.label.toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <div className="m-screen">
      <button className="btn small" onClick={onBack}>بازگشت</button>
      <h1>محدودیت برنامه‌ها</h1>
      <p className="m-rules">
        فقط برنامه‌هایی که خودت انتخاب می‌کنی بررسی می‌شوند. وقتی تمرکز در حال اجراست و یکی از آن‌ها جلوی صفحه بیاید، یک هشدار می‌گیری. اندروید به برنامه‌های عادی اجازه‌ی بستن یا قفل‌کردن برنامه‌های دیگر را نمی‌دهد، پس این قابلیت مسدودسازی قطعی نیست. هیچ داده‌ای از دستگاه خارج نمی‌شود.
      </p>
      <div className="rows">
        <Row title="هشدار هنگام استفاده از برنامه‌های منتخب" hint="فقط در حین جلسه‌ی تمرکز (نه استراحت) فعال است.">
          <Switch checked={s.limitEnabled} onChange={(v) => patch({ limitEnabled: v })} label="فعال‌سازی محدودیت برنامه‌ها" />
        </Row>
        <Row title="دسترسی به آمار استفاده" hint={perm && perm.usageAccess ? 'فعال است.' : 'لازم است تا بدانیم کدام برنامه جلوی صفحه است. فقط نام برنامه‌ی جلوی صفحه، روی همین گوشی و فقط هنگام تمرکز بررسی می‌شود.'}>
          {perm && perm.usageAccess ? <span className="m-ok">فعال</span> : <button className="btn" onClick={() => openSetting('openUsageAccess')}>باز کردن تنظیمات</button>}
        </Row>
        <Row title="بازگرداندن خودکار به اپ تمرکز" hint="اختیاری. نیاز به مجوز «نمایش روی برنامه‌های دیگر» دارد؛ بدون آن فقط هشدار اعلان می‌آید.">
          <Switch checked={s.limitBringBack} onChange={(v) => patch({ limitBringBack: v })} label="بازگرداندن خودکار" />
        </Row>
        {s.limitBringBack && !(perm && perm.overlay) && (
          <Row title="مجوز نمایش روی برنامه‌های دیگر" hint="برای بازگرداندن خودکار لازم است.">
            <button className="btn" onClick={() => openSetting('openOverlay')}>باز کردن تنظیمات</button>
          </Row>
        )}
      </div>
      <h2 className="sub">حالت محدودسازی (سخت‌گیرانه)</h2>
      <p className="m-rules">
        اختیاری و پیش‌فرض خاموش. هنگام جلسه‌ی تمرکز، هر برنامه‌ای (به‌جز تماس، تنظیمات، صفحه‌ی اصلی، کیبورد و نوار سیستم) که جلوی صفحه بیاید، فوراً به این اپ برمی‌گردد. این مسدودسازی ۱۰۰٪ نیست: اندروید به اپ عادی اجازه‌ی قفل‌کردن گوشی نمی‌دهد (برای آن مدیریت دستگاه لازم است)؛ فقط برمی‌گرداند و تا لحظه‌ای که خودت بخواهی فعال می‌ماند. در استراحت و بین جلسه‌ها اعمال نمی‌شود.
      </p>
      <div className="rows">
        <Row title="مجوز آمار استفاده" hint="لازم است تا برنامه‌ی جلوی صفحه تشخیص داده شود.">
          {perm && perm.usageAccess ? <span className="m-ok">فعال</span> : <button className="btn" onClick={() => openSetting('openUsageAccess')}>باز کردن تنظیمات</button>}
        </Row>
        <Row title="مجوز نمایش روی برنامه‌های دیگر" hint="لازم است تا اپ بتواند از پس‌زمینه جلو بیاید.">
          {perm && perm.overlay ? <span className="m-ok">فعال</span> : <button className="btn" onClick={() => openSetting('openOverlay')}>باز کردن تنظیمات</button>}
        </Row>
        {!s.blockMode && (
          <label className="m-consent">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            <span>می‌دانم که در حین تمرکز استفاده از برنامه‌های دیگر ناممکن یا دشوار می‌شود و هر زمان می‌توانم از همین صفحه، از صفحه‌ی تمرکز یا از دکمه‌ی اعلان آن را خاموش کنم.</span>
          </label>
        )}
        <Row title="فعال‌سازی حالت محدودسازی" hint={s.blockMode ? 'فعال است؛ هر زمان خاموشش کن.' : 'خاموش'}>
          <Switch checked={s.blockMode} label="حالت محدودسازی" onChange={(v) => {
            if (!v) { setBlockMsg(''); patch({ blockMode: false }); return; }
            if (!consent) { setBlockMsg('ابتدا گزینه‌ی رضایت را تأیید کن.'); return; }
            if (!(perm && perm.usageAccess && perm.overlay)) { setBlockMsg('هر دو مجوز بالا باید فعال باشند.'); return; }
            setBlockMsg(''); patch({ blockMode: true });
          }} />
        </Row>
        {s.blockMode && perm && !(perm.usageAccess && perm.overlay) && (
          <p className="m-hint" role="alert">یکی از مجوزها خاموش شده؛ تا فعال‌شدنش فقط هشدار اعلان می‌آید.</p>
        )}
        {blockMsg && <p className="m-hint" role="alert">{blockMsg}</p>}
      </div>
      <h2 className="sub">برنامه‌های منتخب ({toFa(selected.length)} از {toFa(MAX_LIMITED_APPS)})</h2>
      <input className="m-search" placeholder="جست‌وجوی برنامه" aria-label="جست‌وجوی برنامه" value={q} onChange={(e) => setQ(e.target.value)} />
      {apps === null ? <p className="empty">در حال بارگذاری…</p> : list.length === 0 ? (
        <p className="empty">{isNative() ? 'برنامه‌ای پیدا نشد.' : 'فهرست برنامه‌ها فقط در اپ اندروید در دسترس است.'}</p>
      ) : (
        <ul className="m-apps">
          {list.map((a) => (
            <li key={a.package}>
              <label>
                <input type="checkbox" checked={selected.includes(a.package)} onChange={() => patch({ limitedApps: togglePackage(selected, a.package) })} />
                <span>{a.label}</span>
              </label>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ---------------- تنظیمات ---------------- */
async function shareFile(name, text, mime) {
  if (!isNative()) { downloadText(name, text, mime); return; }
  const { uri } = await Filesystem.writeFile({ path: name, data: text, directory: Directory.Cache, encoding: Encoding.UTF8 });
  await Share.share({ title: name, url: uri, dialogTitle: 'ذخیره یا ارسال فایل' });
}

function SettingsScreen({ openLimits }) {
  const [s, patch, ready] = useSettings();
  const [minutes, setMinutes] = useState('');
  const [breakText, setBreakText] = useState('');
  const [extendText, setExtendText] = useState('');
  const [perm, setPerm] = useState(null);
  const [confirm, setConfirm] = useState(false);
  const [restore, setRestore] = useState(null);
  const [fileMsg, setFileMsg] = useState('');
  const fileInput = useRef(null);
  useEffect(() => setMinutes(toFa(s.defaultMinutes)), [s.defaultMinutes]);
  useEffect(() => setBreakText(toFa(s.breakMinutes)), [s.breakMinutes]);
  useEffect(() => setExtendText(toFa(s.extendMinutes)), [s.extendMinutes]);
  useEffect(() => { getPermissions().then(setPerm); const h = CapApp.addListener('resume', () => getPermissions().then(setPerm)); return () => { h.then((x) => x.remove()); }; }, []);
  if (!ready) return null;

  const commit = (text, min, max, key, setText) => {
    const n = parseInt(fromFa(text), 10);
    if (Number.isInteger(n) && n >= min && n <= max) patch({ [key]: n });
    else setText(toFa(s[key]));
  };
  const exportData = async () => {
    const data = { exportedAt: new Date().toISOString(), sessions: await getItem(KEYS.sessions, []), settings: s };
    await shareFile('keyhan-tamarkoz-backup.json', JSON.stringify(data, null, 2), 'application/json');
  };
  const pickBackup = async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > MAX_BACKUP_BYTES) { setRestore({ step: 'error', message: 'حجم فایل بیش از حد مجاز است.' }); return; }
    const res = parseBackup(await file.text(), { tasks: false });
    setRestore(res.ok ? { step: 'confirm', data: res.data, summary: res.summary } : { step: 'error', message: res.error });
  };
  const summaryText = (m) => `${toFa(m.sessions)} جلسه${m.settings ? ' و تنظیمات' : ''}` + (m.skipped ? ` (${toFa(m.skipped)} مورد نامعتبر نادیده گرفته شد)` : '');
  const sessionsNow = async () => getItem(KEYS.sessions, []);

  return (
    <div className="m-screen">
      <h1>تنظیمات</h1>
      <h2 className="sub first">ظاهر</h2>
      <div className="rows"><ThemeSettings s={s} patch={patch} Row={Row} /></div>

      <h2 className="sub">مدت‌ها</h2>
      <div className="rows">
        <Row title="مدت پیش‌فرض تمرکز" hint={`${toFa(MIN_MINUTES)} تا ${toFa(MAX_MINUTES)} دقیقه`}>
          <div className="mini-field">
            <input inputMode="numeric" value={minutes} aria-label="مدت پیش‌فرض به دقیقه" onChange={(e) => setMinutes(e.target.value)}
              onBlur={() => commit(minutes, MIN_MINUTES, MAX_MINUTES, 'defaultMinutes', setMinutes)} onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()} />
            <span>دقیقه</span>
          </div>
        </Row>
        <Row title="مدت استراحت" hint={`${toFa(MIN_BREAK_MINUTES)} تا ${toFa(MAX_BREAK_MINUTES)} دقیقه؛ پیش‌فرض ${toFa(5)}`}>
          <div className="mini-field">
            <input inputMode="numeric" value={breakText} aria-label="مدت استراحت به دقیقه" onChange={(e) => setBreakText(e.target.value)}
              onBlur={() => commit(breakText, MIN_BREAK_MINUTES, MAX_BREAK_MINUTES, 'breakMinutes', setBreakText)} onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()} />
            <span>دقیقه</span>
          </div>
        </Row>
        <Row title="مدت تمدید جلسه" hint={`با دکمه‌ی «تمدید جلسه»؛ ${toFa(MIN_BREAK_MINUTES)} تا ${toFa(MAX_BREAK_MINUTES)} دقیقه`}>
          <div className="mini-field">
            <input inputMode="numeric" value={extendText} aria-label="مدت تمدید جلسه به دقیقه" onChange={(e) => setExtendText(e.target.value)}
              onBlur={() => commit(extendText, MIN_BREAK_MINUTES, MAX_BREAK_MINUTES, 'extendMinutes', setExtendText)} onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()} />
            <span>دقیقه</span>
          </div>
        </Row>
        <Row title="جمله‌های انگیزشی" hint="زیر تایمر و در اعلان پایان جلسه نشان داده می‌شوند.">
          <Switch checked={s.showQuotes} onChange={(v) => patch({ showQuotes: v })} label="نمایش جمله‌های انگیزشی" />
        </Row>
      </div>

      <h2 className="sub">اعلان و صدا</h2>
      <div className="rows">
        <Row title="اعلان پایان جلسه و استراحت" hint="با دکمه‌های «استراحت» و «شروع جلسه‌ی جدید».">
          <Switch checked={s.notifications} onChange={(v) => patch({ notifications: v })} label="اعلان پایان جلسه" />
        </Row>
        {perm && !perm.notifications && (
          <Row title="مجوز اعلان خاموش است" hint="بدون آن اعلان‌ها نمایش داده نمی‌شوند.">
            <button className="btn" onClick={() => openSetting('requestNotifications')}>اجازه دادن</button>
          </Row>
        )}
        {perm && perm.notifications && perm.headsUp === false && (
          <Row title="اعلان شناور خاموش است" hint="اهمیت کانال «پایان جلسه» روی «بالا» نیست؛ برای دیدن اعلان در بالای صفحه آن را روی «نمایش شناور» بگذار.">
            <button className="btn" onClick={() => openSetting('openChannelSettings')}>باز کردن تنظیمات</button>
          </Row>
        )}
        <Row title="پنجره‌ی پایان جلسه روی برنامه‌های دیگر" hint="اختیاری و جدا از اعلان شناور: یک پنجره‌ی کوچک با دکمه‌های استراحت، تمدید و بستن روی هر برنامه‌ای نشان می‌دهد. نیاز به مجوز «نمایش روی برنامه‌های دیگر» دارد و تضمینی برای همه‌ی گوشی‌ها نیست.">
          <Switch checked={s.endOverlay && !!(perm && perm.overlay)} onChange={(v) => { if (v && !(perm && perm.overlay)) openSetting('openOverlay'); else patch({ endOverlay: v }); }} label="پنجره‌ی پایان جلسه روی برنامه‌ها" />
        </Row>
        {perm && !perm.exactAlarm && (
          <Row title="زنگ دقیق خاموش است" hint="بدون آن ممکن است پایان جلسه چند دقیقه دیر اعلام شود.">
            <button className="btn" onClick={() => openSetting('openExactAlarm')}>باز کردن تنظیمات</button>
          </Row>
        )}
        {perm && !perm.battery && (
          <Row title="بهینه‌سازی باتری" hint="در برخی گوشی‌ها سیستم برنامه را در پس‌زمینه می‌بندد؛ استثنا قرار دادن کمک می‌کند.">
            <button className="btn" onClick={() => openSetting('openBattery')}>باز کردن تنظیمات</button>
          </Row>
        )}
        <SoundSettings s={s} patch={patch} Row={Row} Switch={Switch} />
      </div>

      <h2 className="sub">تمرکز بر برنامه‌ها</h2>
      <div className="rows">
        <Row title="محدودیت برنامه‌های منتخب" hint={s.limitEnabled ? `فعال · ${toFa(normalizePackages(s.limitedApps).length)} برنامه` : 'خاموش'}>
          <button className="btn" onClick={openLimits}>مدیریت</button>
        </Row>
      </div>

      <h2 className="sub">داده‌ها</h2>
      <div className="rows">
        <Row title="دریافت نسخه‌ی پشتیبان" hint="جلسه‌ها و تنظیمات در یک فایل JSON.">
          <button className="btn" onClick={exportData}>دریافت فایل</button>
        </Row>
        <Row title="خروجی آمار" hint="CSV برای Excel یا جمع روزانه JSON.">
          <div className="confirm">
            <button className="btn" onClick={async () => shareFile('keyhan-tamarkoz-sessions.csv', sessionsToCsv(await sessionsNow()), 'text/csv')}>CSV</button>
            <button className="btn" onClick={async () => shareFile('keyhan-tamarkoz-daily.json', dailySummaryJson(await sessionsNow()), 'application/json')}>JSON</button>
          </div>
        </Row>
        <Row title="بازیابی از فایل پشتیبان" hint="فایل JSON همین اپ یا افزونه‌ی کیهان تمرکز؛ بخش‌هایی که در این اپ نیست نادیده گرفته می‌شود.">
          <input ref={fileInput} type="file" accept=".json,application/json" hidden onChange={pickBackup} />
          <button className="btn" onClick={() => fileInput.current && fileInput.current.click()}>انتخاب فایل</button>
        </Row>
        {restore && restore.step === 'confirm' && (
          <div role="status"><Row title="بازیابی انجام شود؟" hint={`این فایل شامل ${summaryText(restore.summary)} است. جلسه‌های فعلی با محتوای فایل جایگزین می‌شوند.`}>
            <div className="confirm">
              <button className="btn danger" onClick={async () => { try { await restoreBackup(restore.data); setRestore({ step: 'done', summary: restore.summary }); } catch { setRestore({ step: 'error', message: 'بازیابی انجام نشد.' }); } }}>بله</button>
              <button className="btn" onClick={() => setRestore(null)}>انصراف</button>
            </div></Row></div>
        )}
        {restore && restore.step === 'done' && <div role="status"><Row title="بازیابی انجام شد" hint={`${summaryText(restore.summary)} بازیابی شد.`}><button className="btn" onClick={() => setRestore(null)}>بستن</button></Row></div>}
        {restore && restore.step === 'error' && <div role="alert"><Row title="بازیابی انجام نشد" hint={restore.message}><button className="btn" onClick={() => setRestore(null)}>بستن</button></Row></div>}
        <Row title="حذف همه‌ی جلسه‌ها" hint="آمار و باغ برای همیشه پاک می‌شوند.">
          {confirm ? (
            <div className="confirm">
              <button className="btn danger" onClick={async () => { await setItem(KEYS.sessions, []); setConfirm(false); setFileMsg('جلسه‌ها حذف شد.'); }}>بله</button>
              <button className="btn" onClick={() => setConfirm(false)}>انصراف</button>
            </div>
          ) : <button className="btn danger" onClick={() => setConfirm(true)}>حذف جلسه‌ها</button>}
        </Row>
      </div>
      {fileMsg && <p className="m-hint" role="status">{fileMsg}</p>}
    </div>
  );
}

/* ---------------- پوسته ---------------- */
export default function MobileApp() {
  const [tab, setTab] = useState('focus');
  const [limits, setLimits] = useState(false);
  const stateRef = useRef({ tab, limits });
  stateRef.current = { tab, limits };

  useEffect(() => {
    const h = CapApp.addListener('backButton', () => {
      const { tab: t, limits: l } = stateRef.current;
      if (l) setLimits(false);
      else if (t !== 'focus') setTab('focus');
      else CapApp.minimizeApp();
    });
    return () => { h.then((x) => x.remove()); };
  }, []);

  const body = limits ? <LimitsScreen onBack={() => setLimits(false)} />
    : tab === 'focus' ? <FocusScreen />
    : tab === 'garden' ? <GardenScreen />
    : tab === 'stats' ? <div className="m-screen"><StatsView /></div>
    : <SettingsScreen openLimits={() => setLimits(true)} />;

  return (
    <div className="m-app">
      <main className="m-main">{body}</main>
      <nav className="m-nav" aria-label="بخش‌ها">
        {TABS.map((t) => (
          <button key={t.id} aria-current={!limits && t.id === tab ? 'page' : undefined} onClick={() => { setLimits(false); setTab(t.id); }}>{t.label}</button>
        ))}
      </nav>
    </div>
  );
}
